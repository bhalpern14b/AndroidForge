package com.example.transcription

import com.example.audio.PitchDetector
import com.example.model.Accidental
import com.example.model.AudioPitchFrame
import com.example.model.ChordNotation
import com.example.model.ClefType
import com.example.model.DynamicMarking
import com.example.model.InstrumentTrack
import com.example.model.InstrumentType
import com.example.model.Measure
import com.example.model.MusicalNote
import com.example.model.NoteDuration
import com.example.model.SongScore
import com.example.model.TheoryTutorial
import com.example.model.VocalNuance
import com.example.model.VocalOrnament
import java.util.UUID

object TranscriptionEngine {

    fun transcribeFromPitchFrames(
        frames: List<AudioPitchFrame>,
        title: String = "Live Vocal & Instrumental Transcription",
        bpm: Int = 120,
        isBeginnerMode: Boolean = false
    ): SongScore {
        if (frames.isEmpty()) {
            return getPreloadedDemoScore(0, isBeginnerMode)
        }

        val quantizedNotes = mutableListOf<MusicalNote>()
        var currentBeat = 0.0f

        var clusterStartMidi = -1
        var clusterPitchName = ""
        var clusterFreq = 0f
        var clusterCount = 0
        var hasVibratoInCluster = false
        var prevMidi = -1

        for (frame in frames) {
            if (frame.vibratoDetected) hasVibratoInCluster = true

            if (clusterStartMidi == -1) {
                clusterStartMidi = frame.midiPitch
                clusterPitchName = frame.noteName
                clusterFreq = frame.frequencyHz
                clusterCount = 1
            } else if (Math.abs(frame.midiPitch - clusterStartMidi) <= 1) {
                clusterCount++
            } else {
                val duration = when {
                    clusterCount <= 4 -> NoteDuration.SIXTEENTH
                    clusterCount <= 8 -> NoteDuration.EIGHTH
                    clusterCount <= 16 -> NoteDuration.QUARTER
                    else -> NoteDuration.HALF
                }

                // Detect vocal ornament (scoop, vibrato, pitch bend)
                val ornament = when {
                    hasVibratoInCluster && duration.beats >= 1.0f -> VocalOrnament.VIBRATO
                    prevMidi != -1 && clusterStartMidi - prevMidi >= 3 -> VocalOrnament.SCOOP
                    prevMidi != -1 && prevMidi - clusterStartMidi >= 3 -> VocalOrnament.FALL
                    frame.pitchBendDetected -> VocalOrnament.BEND_UP
                    else -> VocalOrnament.NONE
                }

                val nuance = VocalNuance(
                    ornament = ornament,
                    vibratoRateHz = if (ornament == VocalOrnament.VIBRATO) 5.4f else 0f,
                    vibratoDepthCents = if (ornament == VocalOrnament.VIBRATO) 18f else 0f,
                    dynamicMarking = if (frame.amplitudeDb > -12f) DynamicMarking.F else DynamicMarking.MF
                )

                quantizedNotes.add(
                    createNoteFromMidi(
                        midi = clusterStartMidi,
                        pitchName = clusterPitchName,
                        freq = clusterFreq,
                        duration = duration,
                        startBeat = currentBeat,
                        nuance = nuance
                    )
                )
                currentBeat += duration.beats
                prevMidi = clusterStartMidi
                clusterStartMidi = frame.midiPitch
                clusterPitchName = frame.noteName
                clusterFreq = frame.frequencyHz
                clusterCount = 1
                hasVibratoInCluster = false
            }
        }

        if (clusterCount > 0 && clusterStartMidi > 0) {
            quantizedNotes.add(
                createNoteFromMidi(
                    midi = clusterStartMidi,
                    pitchName = clusterPitchName,
                    freq = clusterFreq,
                    duration = NoteDuration.QUARTER,
                    startBeat = currentBeat,
                    nuance = VocalNuance(ornament = VocalOrnament.VIBRATO, vibratoRateHz = 5.2f, vibratoDepthCents = 15f)
                )
            )
        }

        return generateMultiInstrumentScore(
            title = title,
            leadNotes = quantizedNotes,
            bpm = bpm,
            isBeginnerMode = isBeginnerMode
        )
    }

    private fun createNoteFromMidi(
        midi: Int,
        pitchName: String,
        freq: Float,
        duration: NoteDuration,
        startBeat: Float,
        nuance: VocalNuance? = null
    ): MusicalNote {
        val noteNameOnly = pitchName.filter { it.isLetter() || it == '#' }
        val accidental = when {
            noteNameOnly.contains("#") -> Accidental.SHARP
            noteNameOnly.contains("b") -> Accidental.FLAT
            else -> Accidental.NONE
        }

        val (strNum, fret) = midiToGuitarFret(midi)

        return MusicalNote(
            pitchName = pitchName,
            midiNote = midi,
            frequencyHz = freq,
            duration = duration,
            startBeat = startBeat,
            stringNumber = strNum,
            fretNumber = fret,
            accidental = accidental,
            fingerHint = if (fret == 0) null else ((fret % 4) + 1),
            vocalNuance = nuance
        )
    }

    fun midiToGuitarFret(midi: Int): Pair<Int, Int> {
        val stringOpenMidi = listOf(64, 59, 55, 50, 45, 40) // 1st (high E) to 6th (low E)
        for ((idx, openMidi) in stringOpenMidi.withIndex()) {
            if (midi >= openMidi && midi <= openMidi + 17) {
                return Pair(idx + 1, midi - openMidi)
            }
        }
        return Pair(1, (midi - 64).coerceIn(0, 19))
    }

    fun generateMultiInstrumentScore(
        title: String,
        leadNotes: List<MusicalNote>,
        bpm: Int = 120,
        isBeginnerMode: Boolean = false
    ): SongScore {
        val totalBeats = maxOf(16.0f, (leadNotes.lastOrNull()?.let { it.startBeat + it.duration.beats } ?: 16.0f))
        val measureCount = (totalBeats / 4.0f).toInt().coerceAtLeast(4)

        // Standard 4-chord progression in C Major: I (C) - V (G) - vi (Am) - IV (F)
        val chordProgression = listOf(
            ChordNotation(
                chordName = "C",
                rootNote = "C",
                quality = "Major",
                startBeat = 0f,
                durationBeats = 4f,
                guitarFrets = listOf(-1, 3, 2, 0, 1, 0),
                pianoMidiKeys = listOf(60, 64, 67),
                romanNumeral = "I",
                theoryExplanation = "Tonic Chord (Home): Establishes the tonal center and peaceful stability in C Major."
            ),
            ChordNotation(
                chordName = "G",
                rootNote = "G",
                quality = "Major",
                startBeat = 4f,
                durationBeats = 4f,
                guitarFrets = listOf(3, 2, 0, 0, 0, 3),
                pianoMidiKeys = listOf(55, 59, 62),
                romanNumeral = "V",
                theoryExplanation = "Dominant Chord: Creates strong harmonic tension that naturally pulls forward."
            ),
            ChordNotation(
                chordName = "Am",
                rootNote = "A",
                quality = "Minor",
                startBeat = 8f,
                durationBeats = 4f,
                guitarFrets = listOf(-1, 0, 2, 2, 1, 0),
                pianoMidiKeys = listOf(57, 60, 64),
                romanNumeral = "vi",
                theoryExplanation = "Submediant Chord (Relative Minor): Introduces an emotional, melancholic color."
            ),
            ChordNotation(
                chordName = "F",
                rootNote = "F",
                quality = "Major",
                startBeat = 12f,
                durationBeats = 4f,
                guitarFrets = listOf(1, 3, 3, 2, 1, 1),
                pianoMidiKeys = listOf(53, 57, 60),
                romanNumeral = "IV",
                theoryExplanation = "Subdominant Chord: Provides uplifting warmth that bridges back to the tonic."
            )
        )

        val pianoMeasures = mutableListOf<Measure>()
        val guitarMeasures = mutableListOf<Measure>()
        val bassMeasures = mutableListOf<Measure>()
        val drumMeasures = mutableListOf<Measure>()
        val violinMeasures = mutableListOf<Measure>()

        for (m in 0 until measureCount) {
            val chord = chordProgression[m % chordProgression.size]
            val mStart = m * 4.0f

            // Piano: Treble melody + left hand chords
            val pNotes = mutableListOf<MusicalNote>()
            pNotes.add(MusicalNote("C4", chord.pianoMidiKeys[0], duration = NoteDuration.HALF, startBeat = mStart))
            pNotes.add(MusicalNote("E4", chord.pianoMidiKeys.getOrElse(1) { 64 }, duration = NoteDuration.HALF, startBeat = mStart))
            pNotes.add(MusicalNote("G4", chord.pianoMidiKeys.getOrElse(2) { 67 }, duration = NoteDuration.HALF, startBeat = mStart + 2f))
            pNotes.add(MusicalNote("C5", chord.pianoMidiKeys[0] + 12, duration = NoteDuration.HALF, startBeat = mStart + 2f))
            pianoMeasures.add(Measure(m + 1, pNotes, chord, DynamicMarking.MF))

            // Guitar: 4 strum beats per measure
            val gNotes = mutableListOf<MusicalNote>()
            for (b in 0..3) {
                val (str, fret) = midiToGuitarFret(chord.pianoMidiKeys[0])
                gNotes.add(
                    MusicalNote(
                        pitchName = chord.chordName,
                        midiNote = chord.pianoMidiKeys[0],
                        duration = NoteDuration.QUARTER,
                        startBeat = mStart + b.toFloat(),
                        stringNumber = str,
                        fretNumber = fret
                    )
                )
            }
            guitarMeasures.add(Measure(m + 1, gNotes, chord, DynamicMarking.MF))

            // Bass: Root on beat 1 & 2, Fifth on beat 3 & 4
            val bNotes = mutableListOf<MusicalNote>()
            val rootMidi = (chord.pianoMidiKeys[0] - 24).coerceAtLeast(36)
            val fifthMidi = rootMidi + 7
            bNotes.add(MusicalNote(chord.rootNote + "2", rootMidi, duration = NoteDuration.HALF, startBeat = mStart))
            bNotes.add(MusicalNote("5th", fifthMidi, duration = NoteDuration.HALF, startBeat = mStart + 2f))
            bassMeasures.add(Measure(m + 1, bNotes, chord, DynamicMarking.MF))

            // Drums: Rock kick, snare, hi-hat
            val dNotes = mutableListOf<MusicalNote>()
            dNotes.add(MusicalNote("Kick", 36, duration = NoteDuration.QUARTER, startBeat = mStart))
            dNotes.add(MusicalNote("Snare", 38, duration = NoteDuration.QUARTER, startBeat = mStart + 1f))
            dNotes.add(MusicalNote("Kick", 36, duration = NoteDuration.QUARTER, startBeat = mStart + 2f))
            dNotes.add(MusicalNote("Snare", 38, duration = NoteDuration.QUARTER, startBeat = mStart + 3f))
            for (eighth in 0..7) {
                dNotes.add(MusicalNote("HiHat", 42, duration = NoteDuration.EIGHTH, startBeat = mStart + eighth * 0.5f))
            }
            drumMeasures.add(Measure(m + 1, dNotes, null, DynamicMarking.F))

            // Violin: Sustained counter-melody with vibrato and expression
            val vNotes = mutableListOf<MusicalNote>()
            val vMidi = chord.pianoMidiKeys.last() + 12
            vNotes.add(
                MusicalNote(
                    pitchName = "Vio",
                    midiNote = vMidi,
                    duration = NoteDuration.WHOLE,
                    startBeat = mStart,
                    vocalNuance = VocalNuance(ornament = VocalOrnament.VIBRATO, vibratoRateHz = 5.6f, vibratoDepthCents = 16f, expressionLabel = "espr.")
                )
            )
            violinMeasures.add(Measure(m + 1, vNotes, chord, DynamicMarking.P))
        }

        // Lead Vocal track with nuanced singing performance
        val vocalMeasures = mutableListOf<Measure>()
        for (m in 0 until measureCount) {
            val mStart = m * 4.0f
            val mEnd = mStart + 4.0f
            val mNotes = leadNotes.filter { it.startBeat >= mStart && it.startBeat < mEnd }
            vocalMeasures.add(Measure(m + 1, mNotes, chordProgression[m % chordProgression.size], DynamicMarking.MF))
        }

        val tracks = listOf(
            InstrumentTrack(UUID.randomUUID().toString(), InstrumentType.VOCALS, "Lead Vocals", ClefType.TREBLE, vocalMeasures, volume = 0.95f),
            InstrumentTrack(UUID.randomUUID().toString(), InstrumentType.PIANO, "Grand Piano", ClefType.GRAND_STAFF, pianoMeasures, volume = 0.85f),
            InstrumentTrack(UUID.randomUUID().toString(), InstrumentType.GUITAR, "Acoustic Guitar", ClefType.TREBLE, guitarMeasures, volume = 0.8f),
            InstrumentTrack(UUID.randomUUID().toString(), InstrumentType.BASS, "Electric Bass", ClefType.BASS, bassMeasures, volume = 0.9f),
            InstrumentTrack(UUID.randomUUID().toString(), InstrumentType.DRUMS, "Drum Kit", ClefType.PERCUSSION, drumMeasures, volume = 0.75f),
            InstrumentTrack(UUID.randomUUID().toString(), InstrumentType.VIOLIN, "Violin Solo", ClefType.TREBLE, violinMeasures, volume = 0.7f)
        )

        return SongScore(
            id = UUID.randomUUID().toString(),
            title = title,
            artist = "Harmoniq Studio Arrangement",
            bpm = bpm,
            keySignature = "C Major",
            tracks = tracks,
            chords = chordProgression,
            audioDurationMs = (measureCount * 4 * (60_000f / bpm)).toLong(),
            isBeginnerMode = isBeginnerMode,
            scaleName = "C Major (Ionian)",
            scaleNotes = listOf("C", "D", "E", "F", "G", "A", "B")
        )
    }

    fun getPreloadedDemoScore(index: Int = 0, isBeginnerMode: Boolean = false): SongScore {
        return when (index % 3) {
            0 -> createAcousticMoonlightScore(isBeginnerMode)
            1 -> createJazzVocalBalladScore(isBeginnerMode)
            else -> createElectricRockAnthemScore(isBeginnerMode)
        }
    }

    private fun createAcousticMoonlightScore(isBeginnerMode: Boolean): SongScore {
        val leadNotes = listOf(
            MusicalNote(
                pitchName = "E4", midiNote = 64, duration = NoteDuration.QUARTER, startBeat = 0f, lyricSyllable = "In",
                vocalNuance = VocalNuance(ornament = VocalOrnament.SCOOP, dynamicMarking = DynamicMarking.MP, expressionLabel = "dolce")
            ),
            MusicalNote(
                pitchName = "G4", midiNote = 67, duration = NoteDuration.QUARTER, startBeat = 1f, lyricSyllable = "the",
                vocalNuance = VocalNuance(ornament = VocalOrnament.NONE, dynamicMarking = DynamicMarking.MF)
            ),
            MusicalNote(
                pitchName = "A4", midiNote = 69, duration = NoteDuration.HALF, startBeat = 2f, lyricSyllable = "night",
                vocalNuance = VocalNuance(ornament = VocalOrnament.VIBRATO, vibratoRateHz = 5.2f, vibratoDepthCents = 18f, dynamicMarking = DynamicMarking.F)
            ),
            MusicalNote(
                pitchName = "B4", midiNote = 71, duration = NoteDuration.QUARTER, startBeat = 4f, lyricSyllable = "soft",
                vocalNuance = VocalNuance(ornament = VocalOrnament.GLISSANDO, glissandoTargetMidi = 69, dynamicMarking = DynamicMarking.MF)
            ),
            MusicalNote(
                pitchName = "A4", midiNote = 69, duration = NoteDuration.QUARTER, startBeat = 5f, lyricSyllable = "winds",
                vocalNuance = VocalNuance(ornament = VocalOrnament.BEND_DOWN, pitchBendCents = -15f)
            ),
            MusicalNote(
                pitchName = "G4", midiNote = 67, duration = NoteDuration.HALF, startBeat = 6f, lyricSyllable = "blow",
                vocalNuance = VocalNuance(ornament = VocalOrnament.VIBRATO, vibratoRateHz = 5.5f, vibratoDepthCents = 14f)
            ),
            MusicalNote(
                pitchName = "C5", midiNote = 72, duration = NoteDuration.HALF, startBeat = 8f, lyricSyllable = "stars",
                vocalNuance = VocalNuance(ornament = VocalOrnament.SCOOP, dynamicMarking = DynamicMarking.FF)
            ),
            MusicalNote(
                pitchName = "B4", midiNote = 71, duration = NoteDuration.QUARTER, startBeat = 10f, lyricSyllable = "will"
            ),
            MusicalNote(
                pitchName = "A4", midiNote = 69, duration = NoteDuration.QUARTER, startBeat = 11f, lyricSyllable = "shine"
            ),
            MusicalNote(
                pitchName = "G4", midiNote = 67, duration = NoteDuration.WHOLE, startBeat = 12f, lyricSyllable = "bright",
                vocalNuance = VocalNuance(ornament = VocalOrnament.VIBRATO, vibratoRateHz = 5.8f, vibratoDepthCents = 22f, dynamicMarking = DynamicMarking.P)
            )
        )
        return generateMultiInstrumentScore(
            title = "Moonlight Acoustic Harmony",
            leadNotes = leadNotes,
            bpm = 108,
            isBeginnerMode = isBeginnerMode
        )
    }

    private fun createJazzVocalBalladScore(isBeginnerMode: Boolean): SongScore {
        val leadNotes = listOf(
            MusicalNote(
                pitchName = "D4", midiNote = 62, duration = NoteDuration.EIGHTH, startBeat = 0f, lyricSyllable = "Au-",
                vocalNuance = VocalNuance(ornament = VocalOrnament.GRACE_NOTE)
            ),
            MusicalNote(
                pitchName = "F4", midiNote = 65, duration = NoteDuration.EIGHTH, startBeat = 0.5f, lyricSyllable = "tumn"
            ),
            MusicalNote(
                pitchName = "A4", midiNote = 69, duration = NoteDuration.QUARTER, startBeat = 1f, lyricSyllable = "leaves"
            ),
            MusicalNote(
                pitchName = "C5", midiNote = 72, duration = NoteDuration.HALF, startBeat = 2f, lyricSyllable = "fall",
                vocalNuance = VocalNuance(ornament = VocalOrnament.VIBRATO, vibratoRateHz = 4.8f, vibratoDepthCents = 24f)
            ),
            MusicalNote(
                pitchName = "B4", midiNote = 71, duration = NoteDuration.DOTTED_QUARTER, startBeat = 4f, lyricSyllable = "slow-",
                vocalNuance = VocalNuance(ornament = VocalOrnament.FALL)
            ),
            MusicalNote(
                pitchName = "G4", midiNote = 67, duration = NoteDuration.EIGHTH, startBeat = 5.5f, lyricSyllable = "ly"
            ),
            MusicalNote(
                pitchName = "E4", midiNote = 64, duration = NoteDuration.HALF, startBeat = 6f, lyricSyllable = "down"
            ),
            MusicalNote(
                pitchName = "A4", midiNote = 69, duration = NoteDuration.HALF, startBeat = 8f, lyricSyllable = "sweet"
            ),
            MusicalNote(
                pitchName = "F4", midiNote = 65, duration = NoteDuration.HALF, startBeat = 10f, lyricSyllable = "song"
            ),
            MusicalNote(
                pitchName = "D4", midiNote = 62, duration = NoteDuration.WHOLE, startBeat = 12f, lyricSyllable = "here",
                vocalNuance = VocalNuance(ornament = VocalOrnament.VIBRATO, vibratoRateHz = 5.1f, vibratoDepthCents = 19f)
            )
        )
        return generateMultiInstrumentScore(
            title = "Autumn Leaves Vocal Ballad",
            leadNotes = leadNotes,
            bpm = 92,
            isBeginnerMode = isBeginnerMode
        )
    }

    private fun createElectricRockAnthemScore(isBeginnerMode: Boolean): SongScore {
        val leadNotes = listOf(
            MusicalNote("A4", 69, duration = NoteDuration.QUARTER, startBeat = 0f),
            MusicalNote("A4", 69, duration = NoteDuration.QUARTER, startBeat = 1f),
            MusicalNote("C5", 72, duration = NoteDuration.QUARTER, startBeat = 2f),
            MusicalNote("D5", 74, duration = NoteDuration.QUARTER, startBeat = 3f),
            MusicalNote("E5", 76, duration = NoteDuration.HALF, startBeat = 4f,
                vocalNuance = VocalNuance(ornament = VocalOrnament.BEND_UP, pitchBendCents = 35f)),
            MusicalNote("D5", 74, duration = NoteDuration.HALF, startBeat = 6f),
            MusicalNote("C5", 72, duration = NoteDuration.QUARTER, startBeat = 8f),
            MusicalNote("A4", 69, duration = NoteDuration.DOTTED_HALF, startBeat = 9f),
            MusicalNote("G4", 67, duration = NoteDuration.WHOLE, startBeat = 12f,
                vocalNuance = VocalNuance(ornament = VocalOrnament.VIBRATO, vibratoRateHz = 6.2f, vibratoDepthCents = 25f))
        )
        return generateMultiInstrumentScore(
            title = "Neon Skyline Rock Arrangement",
            leadNotes = leadNotes,
            bpm = 132,
            isBeginnerMode = isBeginnerMode
        )
    }

    /**
     * Beginner Practice Mode Music Theory Tutorials
     */
    fun getBeginnerTheoryTutorials(): List<TheoryTutorial> {
        return listOf(
            TheoryTutorial(
                id = "tut-1",
                title = "The Magic 'I - V - vi - IV' Progression",
                category = "Chord Progression",
                summary = "The most popular chord progression in modern music history, found in hundreds of hits.",
                detailedExplanation = "In the key of C Major, this progression uses C (I) -> G (V) -> Am (vi) -> F (IV). The I chord brings home stability, the V creates anticipation, the vi introduces emotion, and the IV resolves smoothly back home.",
                exampleChordsOrNotes = listOf("C (I)", "G (V)", "Am (vi)", "F (IV)"),
                audioDemoMidi = listOf(60, 55, 57, 53),
                badgeColor = 0xFF06B6D4
            ),
            TheoryTutorial(
                id = "tut-2",
                title = "The C Major Scale (Ionian Mode)",
                category = "Scales",
                summary = "The foundation of Western harmony containing all natural white keys: C, D, E, F, G, A, B.",
                detailedExplanation = "Formula: Whole - Whole - Half - Whole - Whole - Whole - Half steps. Notice the half-steps between E-F and B-C. All melodies in this piece derive from these 7 notes.",
                exampleChordsOrNotes = listOf("C", "D", "E", "F", "G", "A", "B", "C"),
                audioDemoMidi = listOf(60, 62, 64, 65, 67, 69, 71, 72),
                badgeColor = 0xFF10B981
            ),
            TheoryTutorial(
                id = "tut-3",
                title = "Vocal Vibrato & Expressive Pitch Nuances",
                category = "Vocal Performance",
                summary = "How pro vocalists add warmth and emotional depth through subtle pitch oscillations.",
                detailedExplanation = "Vibrato is a natural pulsation of pitch occurring at 4.5 to 6.5 Hz with a depth of 15-25 cents. It appears on held notes (wavy lines ~~~). Scoops (rising into a note) add soulful character.",
                exampleChordsOrNotes = listOf("Vibrato (~)", "Scoop (⤴)", "Glissando (gliss.)", "Pitch Bend"),
                audioDemoMidi = listOf(67, 69, 72),
                badgeColor = 0xFF8B5CF6
            ),
            TheoryTutorial(
                id = "tut-4",
                title = "How to Read Tablature & Fret Numbers",
                category = "Guitar & Bass",
                summary = "Quick guide to reading guitar tabs alongside standard musical staff notation.",
                detailedExplanation = "Tabs have 6 horizontal lines representing the 6 strings (top line is high E, bottom is low E). Numbers indicate which fret to press down. '0' means open string. Letter chords above show hand shape.",
                exampleChordsOrNotes = listOf("E (1st)", "B (2nd)", "G (3rd)", "D (4th)", "A (5th)", "E (6th)"),
                audioDemoMidi = listOf(40, 45, 50, 55, 59, 64),
                badgeColor = 0xFFF59E0B
            )
        )
    }
}
