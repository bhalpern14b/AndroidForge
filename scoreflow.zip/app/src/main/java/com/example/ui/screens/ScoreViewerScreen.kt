package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.InstrumentType
import com.example.ui.HarmoniqViewModel
import com.example.ui.components.BeginnerTutorialModal
import com.example.ui.components.DrumNotationView
import com.example.ui.components.GuitarTabView
import com.example.ui.components.MultiTrackMixer
import com.example.ui.components.PianoRollView
import com.example.ui.components.SheetMusicCanvas
import com.example.ui.theme.BassColor
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DrumsColor
import com.example.ui.theme.EmeraldTune
import com.example.ui.theme.GuitarColor
import com.example.ui.theme.PianoColor
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ViolinColor
import com.example.ui.theme.VocalColor

import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.IosShare
import com.example.model.ChordDiagramDictionary
import com.example.ui.components.ChordDiagramBox
import com.example.ui.components.ChordDiagramModal
import com.example.ui.components.DigitalMetronomeCard
import com.example.ui.components.ExportMenuModal

@Composable
fun ScoreViewerScreen(
    viewModel: HarmoniqViewModel,
    modifier: Modifier = Modifier
) {
    val score by viewModel.currentScore.collectAsState()
    val selectedTrackId by viewModel.selectedTrackId.collectAsState()
    val isPlaying by viewModel.audioSynthesizer.isPlaying.collectAsState()
    val playheadBeat by viewModel.audioSynthesizer.currentPlayheadBeat.collectAsState()
    val isBeginnerMode by viewModel.isBeginnerMode.collectAsState()
    val showTutorials by viewModel.showTutorialModal.collectAsState()
    val activePianoKeys by viewModel.activePianoKeys.collectAsState()
    val transposeSemitones by viewModel.transposeSemitones.collectAsState()
    val capoFret by viewModel.guitarCapoFret.collectAsState()
    val metronomeConfig by viewModel.digitalMetronome.config.collectAsState()

    var showMixerDrawer by remember { mutableStateOf(false) }
    var showMetronomeCard by remember { mutableStateOf(false) }
    var showExportModal by remember { mutableStateOf(false) }
    var showChordDiagramModal by remember { mutableStateOf(false) }
    var selectedChordForDiagram by remember { mutableStateOf("C") }
    var exportStatusMessage by remember { mutableStateOf<String?>(null) }

    val activeTrack = score.tracks.find { it.trackId == selectedTrackId }
        ?: score.tracks.firstOrNull() ?: return

    if (showChordDiagramModal) {
        ChordDiagramModal(
            activeSongChords = score.chords.map { it.chordName },
            initialSelectedChord = selectedChordForDiagram,
            capoFret = capoFret,
            onPlayGuitarStrum = { midis -> viewModel.previewChords(midis) },
            onPlayPianoChord = { midis -> viewModel.previewChords(midis) },
            onDismiss = { showChordDiagramModal = false }
        )
    }

    if (showExportModal) {
        ExportMenuModal(
            score = score,
            activeTrack = activeTrack,
            onDismiss = { showExportModal = false },
            onStatusMessage = { exportStatusMessage = it }
        )
    }

    if (showTutorials) {
        BeginnerTutorialModal(
            tutorials = viewModel.theoryTutorials,
            onPlayTutorialAudio = { midis -> viewModel.previewChords(midis) },
            onDismiss = { viewModel.setShowTutorialModal(false) }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            // Score Header & Practice Mode Switch
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioSurface),
                shape = RoundedCornerShape(18.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = score.title,
                                color = TextPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${score.keySignature} • ${score.bpm} BPM • ${score.scaleName}",
                                color = CyanAccent,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Chord Diagrams Button
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { showChordDiagramModal = true },
                                color = GuitarColor.copy(alpha = 0.2f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, GuitarColor.copy(alpha = 0.5f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.GridOn,
                                        contentDescription = "Chords",
                                        tint = GuitarColor,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "CHORDS",
                                        color = GuitarColor,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // Export Button (PDF / MIDI / MusicXML)
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { showExportModal = true },
                                color = CyanAccent
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FileDownload,
                                        contentDescription = "Export",
                                        tint = Color(0xFF090D16),
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "EXPORT",
                                        color = Color(0xFF090D16),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // Metronome Toggle Button
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { showMetronomeCard = !showMetronomeCard },
                                color = if (metronomeConfig.isRunning) CyanAccent else StudioSurfaceVariant,
                                border = if (metronomeConfig.isRunning) null else androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Speed,
                                        contentDescription = "Metronome",
                                        tint = if (metronomeConfig.isRunning) Color(0xFF090D16) else TextPrimary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (metronomeConfig.isRunning) "${metronomeConfig.bpm} BPM" else "CLICK",
                                        color = if (metronomeConfig.isRunning) Color(0xFF090D16) else TextPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // Beginner / Professional Mode Toggle
                            Surface(
                                color = if (isBeginnerMode) EmeraldTune.copy(alpha = 0.15f) else StudioSurfaceVariant,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .clickable { viewModel.toggleBeginnerMode() }
                                        .padding(horizontal = 9.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (isBeginnerMode) "BEGINNER" else "PRO",
                                        color = if (isBeginnerMode) EmeraldTune else TextSecondary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    exportStatusMessage?.let { status ->
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            color = EmeraldTune.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "✓ $status",
                                color = EmeraldTune,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }

                    // Beginner Theory Assistant Bar
                    if (isBeginnerMode) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { viewModel.setShowTutorialModal(true) },
                            color = Color(0xFF0F172A),
                            border = androidx.compose.foundation.BorderStroke(1.dp, CyanAccent.copy(alpha = 0.4f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.School, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Interactive Theory Guide: Learn I-V-vi-IV & Scales",
                                        color = TextPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                                Text("VIEW", color = CyanAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Configurable Digital Metronome Card (Integrated practice tool)
        if (showMetronomeCard || metronomeConfig.isRunning) {
            item {
                DigitalMetronomeCard(
                    metronome = viewModel.digitalMetronome,
                    config = metronomeConfig,
                    onBpmChanged = { bpm -> viewModel.setBpm(bpm) }
                )
            }
        }

        // Instrument Tabs Row
        item {
            Text(
                text = "Select Instrument Sheet / Tabs:",
                color = TextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                score.tracks.forEach { track ->
                    val isSelected = track.trackId == selectedTrackId
                    val instColor = when (track.instrument) {
                        InstrumentType.PIANO -> PianoColor
                        InstrumentType.GUITAR -> GuitarColor
                        InstrumentType.BASS -> BassColor
                        InstrumentType.DRUMS -> DrumsColor
                        InstrumentType.VIOLIN -> ViolinColor
                        InstrumentType.VOCALS -> VocalColor
                    }

                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { viewModel.setSelectedTrack(track.trackId) },
                        color = if (isSelected) instColor.copy(alpha = 0.2f) else StudioSurface,
                        border = androidx.compose.foundation.BorderStroke(
                            width = if (isSelected) 1.5.dp else 1.dp,
                            color = if (isSelected) instColor else Color(0xFF334155)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(instColor, CircleShape)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = track.instrument.displayName,
                                color = if (isSelected) TextPrimary else TextSecondary,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }

        // Guitar Capo Setting Bar (Interactive Capo setting for Guitarist)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioSurface),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (capoFret > 0) GuitarColor.copy(alpha = 0.6f) else Color(0xFF334155))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Tune, contentDescription = "Capo", tint = GuitarColor, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Guitar Capo Setting",
                                color = TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = if (capoFret == 0) "Open (No Capo)" else "Fret $capoFret (+${capoFret} Semitones)",
                            color = if (capoFret > 0) GuitarColor else TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        (0..7).forEach { fret ->
                            val isFretSelected = capoFret == fret
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { viewModel.setCapo(fret) },
                                color = if (isFretSelected) GuitarColor else StudioSurfaceVariant,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = if (fret == 0) "Open" else "Fret $fret",
                                    color = if (isFretSelected) Color(0xFF090D16) else TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Song Chord Progression Ribbon & Interactive Diagrams
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioSurface),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.GridOn, contentDescription = "Chords", tint = CyanAccent, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Song Chords & Diagrams",
                                color = TextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Text(
                            text = "Tap to hear & view diagram",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        score.chords.forEach { chordItem ->
                            val chordBase = chordItem.chordName.substringBefore("(").substringBefore("/").trim()
                            val isCurrentSelected = selectedChordForDiagram == chordBase

                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable {
                                        selectedChordForDiagram = chordBase
                                        viewModel.previewChords(chordItem.pianoMidiKeys)
                                    },
                                color = if (isCurrentSelected) CyanAccent.copy(alpha = 0.2f) else StudioSurfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(
                                    width = if (isCurrentSelected) 1.5.dp else 1.dp,
                                    color = if (isCurrentSelected) CyanAccent else Color(0xFF334155)
                                ),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = chordItem.chordName,
                                        color = if (isCurrentSelected) CyanAccent else TextPrimary,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = chordItem.romanNumeral,
                                        color = TextSecondary,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }

                    // Display the interactive Chord Diagram for the currently selected chord
                    val chordDiagramInfo = ChordDiagramDictionary.getChord(selectedChordForDiagram)
                    Spacer(modifier = Modifier.height(12.dp))
                    ChordDiagramBox(
                        chord = chordDiagramInfo,
                        capoFret = capoFret,
                        onPlayGuitarStrum = { viewModel.previewChords(chordDiagramInfo.pianoMidis) },
                        onPlayPianoChord = { viewModel.previewChords(chordDiagramInfo.pianoMidis) }
                    )
                }
            }
        }

        // Main Sheet Music / Tab Notation Display
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioSurface),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${activeTrack.name} Notation",
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = if (activeTrack.instrument == InstrumentType.GUITAR) "Tablature (6-String)" else if (activeTrack.instrument.isPercussion) "Drum Beats" else "Standard Staff",
                            color = CyanAccent,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Notation View Switch based on Instrument
                    when (activeTrack.instrument) {
                        InstrumentType.GUITAR -> {
                            GuitarTabView(
                                score = score,
                                track = activeTrack,
                                currentPlayheadBeat = playheadBeat,
                                isBeginnerMode = isBeginnerMode,
                                onNoteTapped = { note -> viewModel.previewNote(note, InstrumentType.GUITAR) },
                                capoFret = capoFret
                            )
                        }
                        InstrumentType.DRUMS -> {
                            DrumNotationView(
                                score = score,
                                track = activeTrack,
                                currentPlayheadBeat = playheadBeat,
                                onDrumTapped = { note -> viewModel.previewNote(note, InstrumentType.DRUMS) }
                            )
                        }
                        else -> {
                            // Piano, Bass, Violin, Vocals
                            SheetMusicCanvas(
                                score = score,
                                track = activeTrack,
                                currentPlayheadBeat = playheadBeat,
                                isBeginnerMode = isBeginnerMode,
                                onNoteTapped = { note -> viewModel.previewNote(note, activeTrack.instrument) }
                            )
                        }
                    }
                }
            }
        }

        // Arrangement Master Playback Controls
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioSurface),
                shape = RoundedCornerShape(18.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Play All Instruments Simultaneously Button
                        Button(
                            onClick = {
                                if (isPlaying) viewModel.pausePlayback() else viewModel.startPlayback()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isPlaying) Color(0xFFEF4444) else CyanAccent
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) "Pause" else "Play",
                                tint = if (isPlaying) Color.White else Color(0xFF090D16)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isPlaying) "PAUSE ARRANGEMENT" else "PLAY ALL INSTRUMENTS",
                                color = if (isPlaying) Color.White else Color(0xFF090D16),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }

                        // Stop Button
                        IconButton(onClick = { viewModel.stopPlayback() }) {
                            Icon(imageVector = Icons.Default.Stop, contentDescription = "Stop", tint = TextSecondary)
                        }

                        // Toggle Multi-Track Mixer Drawer
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { showMixerDrawer = !showMixerDrawer },
                            color = StudioSurfaceVariant
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(imageVector = Icons.Default.GraphicEq, contentDescription = "Mixer", tint = CyanAccent, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("MIXER", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Icon(
                                    imageVector = if (showMixerDrawer) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                    contentDescription = null,
                                    tint = TextSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Transposition & Tempo Controls
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Tempo (BPM)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Speed, contentDescription = "Tempo", tint = TextSecondary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("BPM: ${score.bpm}", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            IconButton(onClick = { viewModel.setBpm(score.bpm - 5) }, modifier = Modifier.size(28.dp)) {
                                Icon(imageVector = Icons.Default.Remove, contentDescription = "Slower", tint = TextSecondary, modifier = Modifier.size(16.dp))
                            }
                            IconButton(onClick = { viewModel.setBpm(score.bpm + 5) }, modifier = Modifier.size(28.dp)) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = "Faster", tint = TextSecondary, modifier = Modifier.size(16.dp))
                            }
                        }

                        // Transpose Semitones
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Transpose: ${if (transposeSemitones > 0) "+$transposeSemitones" else transposeSemitones}", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            IconButton(onClick = { viewModel.transpose(-1) }, modifier = Modifier.size(28.dp)) {
                                Icon(imageVector = Icons.Default.Remove, contentDescription = "Down", tint = TextSecondary, modifier = Modifier.size(16.dp))
                            }
                            IconButton(onClick = { viewModel.transpose(1) }, modifier = Modifier.size(28.dp)) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = "Up", tint = TextSecondary, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }

        // Collapsible Multi-Track Arrangement Mixer
        item {
            AnimatedVisibility(visible = showMixerDrawer) {
                MultiTrackMixer(
                    tracks = score.tracks,
                    selectedTrackId = selectedTrackId,
                    onSelectTrack = { viewModel.setSelectedTrack(it) },
                    onTrackVolumeChanged = { id, vol -> viewModel.updateTrackVolume(id, vol) },
                    onToggleMute = { id -> viewModel.toggleTrackMute(id) },
                    onToggleSolo = { id -> viewModel.toggleTrackSolo(id) }
                )
            }
        }

        // Interactive Piano Roll at bottom
        item {
            PianoRollView(
                activeMidiNotes = activePianoKeys,
                isBeginnerMode = isBeginnerMode,
                onKeyTapped = { midi, name -> viewModel.previewPianoKey(midi, name) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
