package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.example.model.MusicalNote
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.PianoColor
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun PianoRollView(
    activeMidiNotes: List<Int>,
    isBeginnerMode: Boolean,
    onKeyTapped: (Int, String) -> Unit,
    modifier: Modifier = Modifier
) {
    // 2-Octave Keyboard: C4 (60) to B5 (83)
    val startMidi = 60
    val totalKeys = 24
    val scrollState = rememberScrollState()

    val whiteKeyNames = listOf("C", "D", "E", "F", "G", "A", "B")
    val blackKeyOffsets = mapOf(
        0 to "C#", // offset after C
        1 to "D#", // offset after D
        3 to "F#", // offset after F
        4 to "G#", // offset after G
        5 to "A#"  // offset after A
    )

    Column(modifier = modifier) {
        // Piano Roll Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Interactive Piano Roll (C4 - B5)",
                color = PianoColor,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            if (isBeginnerMode) {
                Text(
                    text = " • Note Letters Active",
                    color = CyanAccent,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // 2-Octave Keyboard Layout
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .horizontalScroll(scrollState)
                .background(StudioSurface, RoundedCornerShape(8.dp))
                .padding(4.dp)
        ) {
            val keyWidth = 36.dp
            val blackKeyWidth = 24.dp
            val blackKeyHeight = 75.dp

            // 1. Draw White Keys
            Row {
                for (octave in 0..1) {
                    for ((wIdx, noteName) in whiteKeyNames.withIndex()) {
                        val currentOctave = 4 + octave
                        val midi = calculateWhiteKeyMidi(wIdx, currentOctave)
                        val isPressed = activeMidiNotes.contains(midi)

                        Box(
                            modifier = Modifier
                                .width(keyWidth)
                                .height(120.dp)
                                .background(
                                    if (isPressed) CyanAccent.copy(alpha = 0.85f) else Color.White,
                                    RoundedCornerShape(bottomStart = 4.dp, bottomEnd = 4.dp)
                                )
                                .border(1.dp, Color(0xFF94A3B8), RoundedCornerShape(bottomStart = 4.dp, bottomEnd = 4.dp))
                                .clickable { onKeyTapped(midi, "$noteName$currentOctave") },
                            contentAlignment = Alignment.BottomCenter
                        ) {
                            if (isBeginnerMode || isPressed) {
                                Text(
                                    text = "$noteName$currentOctave",
                                    color = if (isPressed) Color.White else Color(0xFF1E293B),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(bottom = 6.dp)
                                )
                            }
                        }
                    }
                }
            }

            // 2. Draw Black Keys overlaid on top
            for (octave in 0..1) {
                val octaveOffset = (octave * 7 * 36).dp
                for ((wIndex, bName) in blackKeyOffsets) {
                    val currentOctave = 4 + octave
                    val midi = calculateBlackKeyMidi(wIndex, currentOctave)
                    val isPressed = activeMidiNotes.contains(midi)
                    val leftOffset = octaveOffset + (wIndex * 36).dp + 24.dp

                    Box(
                        modifier = Modifier
                            .offset(x = leftOffset)
                            .width(blackKeyWidth)
                            .height(blackKeyHeight)
                            .zIndex(2f)
                            .background(
                                if (isPressed) CyanAccent else Color(0xFF0F172A),
                                RoundedCornerShape(bottomStart = 3.dp, bottomEnd = 3.dp)
                            )
                            .border(1.dp, Color(0xFF334155), RoundedCornerShape(bottomStart = 3.dp, bottomEnd = 3.dp))
                            .clickable { onKeyTapped(midi, "$bName$currentOctave") },
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        if (isBeginnerMode && isPressed) {
                            Text(
                                text = bName,
                                color = Color.White,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun calculateWhiteKeyMidi(wIndex: Int, octave: Int): Int {
    val offsets = listOf(0, 2, 4, 5, 7, 9, 11)
    return (octave + 1) * 12 + offsets[wIndex]
}

private fun calculateBlackKeyMidi(wIndex: Int, octave: Int): Int {
    val offsets = listOf(1, 3, -1, 6, 8, 10)
    return (octave + 1) * 12 + offsets[wIndex]
}
