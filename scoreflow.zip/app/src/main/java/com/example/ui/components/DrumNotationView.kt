package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.InstrumentTrack
import com.example.model.MusicalNote
import com.example.model.SongScore
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DrumsColor
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun DrumNotationView(
    score: SongScore,
    track: InstrumentTrack,
    currentPlayheadBeat: Float,
    onDrumTapped: (MusicalNote) -> Unit,
    modifier: Modifier = Modifier
) {
    val textMeasurer = rememberTextMeasurer()
    val measureCount = maxOf(4, track.measures.size)
    val measureWidth = 260.dp
    val totalWidth = measureWidth * measureCount + 80.dp
    val scrollState = rememberScrollState()

    val drumRows = listOf("Hi-Hat (x)", "Snare (●)", "Kick (●)")

    Box(modifier = modifier.horizontalScroll(scrollState)) {
        Canvas(
            modifier = Modifier
                .width(totalWidth)
                .height(200.dp)
                .pointerInput(track) {
                    detectTapGestures { offset ->
                        val startX = 80.dp.toPx()
                        val mWidthPx = measureWidth.toPx()
                        val mIndex = ((offset.x - startX) / mWidthPx).toInt()
                        if (mIndex in track.measures.indices) {
                            val notes = track.measures[mIndex].notes
                            if (notes.isNotEmpty()) onDrumTapped(notes.first())
                        }
                    }
                }
        ) {
            val startX = 80.dp.toPx()
            val topMargin = 50.dp.toPx()
            val lineSpacing = 28.dp.toPx()
            val mWidthPx = measureWidth.toPx()

            // Header labels
            for ((idx, label) in drumRows.withIndex()) {
                val y = topMargin + idx * lineSpacing
                drawText(
                    textMeasurer = textMeasurer,
                    text = label,
                    topLeft = Offset(10.dp.toPx(), y - 8.dp.toPx()),
                    style = TextStyle(color = DrumsColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                )
                drawLine(
                    color = Color(0xFF334155),
                    start = Offset(75.dp.toPx(), y),
                    end = Offset(size.width, y),
                    strokeWidth = 1.dp.toPx()
                )
            }

            // Measures & Drum hits
            for ((mIdx, measure) in track.measures.withIndex()) {
                val mLeft = startX + mIdx * mWidthPx
                val mRight = mLeft + mWidthPx

                // Barline
                drawLine(
                    color = Color(0xFF64748B),
                    start = Offset(mRight, topMargin - 10.dp.toPx()),
                    end = Offset(mRight, topMargin + lineSpacing * 2 + 10.dp.toPx()),
                    strokeWidth = 2.dp.toPx()
                )

                // Measure number
                drawText(
                    textMeasurer = textMeasurer,
                    text = "Bar ${measure.measureNumber}",
                    topLeft = Offset(mLeft + 6.dp.toPx(), topMargin - 28.dp.toPx()),
                    style = TextStyle(color = TextSecondary, fontSize = 10.sp)
                )

                // Hits
                val notes = measure.notes
                for (note in notes) {
                    val hitX = mLeft + ((note.startBeat % 4f) / 4f) * mWidthPx + 15.dp.toPx()
                    val hitY = when (note.pitchName) {
                        "HiHat" -> topMargin
                        "Snare" -> topMargin + lineSpacing
                        else -> topMargin + lineSpacing * 2 // Kick
                    }

                    if (note.pitchName == "HiHat") {
                        // Hi-hat 'x' mark
                        val s = 6.dp.toPx()
                        drawLine(color = DrumsColor, start = Offset(hitX - s, hitY - s), end = Offset(hitX + s, hitY + s), strokeWidth = 2.dp.toPx())
                        drawLine(color = DrumsColor, start = Offset(hitX - s, hitY + s), end = Offset(hitX + s, hitY - s), strokeWidth = 2.dp.toPx())
                    } else {
                        // Solid drum hit circle
                        drawCircle(color = DrumsColor, radius = 6.dp.toPx(), center = Offset(hitX, hitY))
                    }
                }
            }

            // Real-time Playhead
            val beatsPerMeasure = score.timeSignatureNumerator.toFloat()
            val playheadX = startX + (currentPlayheadBeat / beatsPerMeasure) * mWidthPx
            if (playheadX in 0f..size.width) {
                drawLine(
                    color = CyanAccent,
                    start = Offset(playheadX, 15.dp.toPx()),
                    end = Offset(playheadX, size.height - 15.dp.toPx()),
                    strokeWidth = 3.dp.toPx()
                )
            }
        }
    }
}
