package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian & Studio Slate Dark Palette
val StudioBackground = Color(0xFF090D16)
val StudioSurface = Color(0xFF131B2E)
val StudioSurfaceVariant = Color(0xFF1E293B)
val StudioCardBorder = Color(0xFF334155)

// Accent Colors
val CyanAccent = Color(0xFF06B6D4)
val VioletAccent = Color(0xFF8B5CF6)
val EmeraldTune = Color(0xFF10B981)
val AmberWarning = Color(0xFFF59E0B)
val CoralRed = Color(0xFFEF4444)
val ElectricBlue = Color(0xFF3B82F6)

// Text Colors
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)

// Instrument Colors
val PianoColor = Color(0xFF38BDF8)
val GuitarColor = Color(0xFFA78BFA)
val BassColor = Color(0xFFF472B6)
val DrumsColor = Color(0xFFFBBF24)
val ViolinColor = Color(0xFF34D399)
val VocalColor = Color(0xFFFB7185)
