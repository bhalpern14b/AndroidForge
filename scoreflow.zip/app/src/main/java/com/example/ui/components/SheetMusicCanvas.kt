package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ClefType
import com.example.model.InstrumentTrack
import com.example.model.MusicalNote
import com.example.model.NoteDuration
import com.example.model.SongScore
import com.example.model.VocalOrnament
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.EmeraldTune
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletAccent

@Composable
fun SheetMusicCanvas(
    score: SongScore,
    track: InstrumentTrack,
    currentPlayheadBeat: Float,
    isBeginnerMode: Boolean,
    onNoteTapped: (MusicalNote) -> Unit,
    modifier: Modifier = Modifier
) {
    val textMeasurer = rememberTextMeasurer()
    val measureCount = maxOf(4, track.measures.size)
    val measureWidth = 260.dp
    val totalWidth = measureWidth * measureCount + 80.dp
    val scrollState = rememberScrollState()

    Box(modifier = modifier.horizontalScroll(scrollState)) {
        Canvas(
            modifier = Modifier
                .width(totalWidth)
                .height(300.dp)
                .pointerInput(track) {
                    detectTapGestures { offset ->
                        val startX = 60.dp.toPx()
                        val mWidthPx = measureWidth.toPx()
                        val mIndex = ((offset.x - startX) / mWidthPx).toInt()
                        if (mIndex in track.measures.indices) {
                            val notes = track.measures[mIndex].notes
                            if (notes.isNotEmpty()) {
                                onNoteTapped(notes.first())
                            }
                        }
                    }
                }
        ) {
            val staffLineSpacing = 12.dp.toPx()
            val startX = 60.dp.toPx()
            val topMargin = 70.dp.toPx()
            val mWidthPx = measureWidth.toPx()

            // Draw Staff Lines
            drawStaffLines(
                topMargin = topMargin,
                lineSpacing = staffLineSpacing,
                totalWidth = size.width,
                clef = track.clef
            )

            // Draw Clef & Key Signature Header
            drawClefHeader(
                clef = track.clef,
                topMargin = topMargin,
                lineSpacing = staffLineSpacing,
                keySignature = score.keySignature,
                textMeasurer = textMeasurer
            )

            // Draw Measures and Notes
            for ((mIdx, measure) in track.measures.withIndex()) {
                val mLeft = startX + mIdx * mWidthPx
                val mRight = mLeft + mWidthPx

                // Barline
                drawLine(
                    color = Color(0xFF64748B),
                    start = Offset(mRight, topMargin),
                    end = Offset(mRight, topMargin + staffLineSpacing * 4),
                    strokeWidth = 2.dp.toPx()
                )

                // Measure number
                drawText(
                    textMeasurer = textMeasurer,
                    text = "${measure.measureNumber}",
                    topLeft = Offset(mLeft + 6.dp.toPx(), topMargin - 28.dp.toPx()),
                    style = TextStyle(color = TextSecondary, fontSize = 11.sp)
                )

                // Chord notation above measure
                measure.chord?.let { chord ->
                    val chordColor = if (isBeginnerMode) CyanAccent else TextPrimary
                    drawText(
                        textMeasurer = textMeasurer,
                        text = if (isBeginnerMode) "${chord.chordName} (${chord.romanNumeral})" else chord.chordName,
                        topLeft = Offset(mLeft + 12.dp.toPx(), topMargin - 44.dp.toPx()),
                        style = TextStyle(
                            color = chordColor,
                            fontSize = if (isBeginnerMode) 13.sp else 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                // Dynamic markings below staff
                measure.dynamicMarking?.let { dyn ->
                    drawText(
                        textMeasurer = textMeasurer,
                        text = dyn.symbol,
                        topLeft = Offset(mLeft + 16.dp.toPx(), topMargin + staffLineSpacing * 5 + 4.dp.toPx()),
                        style = TextStyle(
                            color = VioletAccent,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif
                        )
                    )
                }

                // Render notes in this measure
                val notesInMeasure = measure.notes
                val noteSpacing = mWidthPx / (notesInMeasure.size.coerceAtLeast(1) + 1)

                for ((nIdx, note) in notesInMeasure.withIndex()) {
                    if (note.isRest) continue

                    val noteX = mLeft + (nIdx + 1) * noteSpacing
                    val noteY = calculateNoteY(
                        midi = note.midiNote,
                        topMargin = topMargin,
                        lineSpacing = staffLineSpacing,
                        clef = track.clef
                    )

                    drawMusicalNote(
                        note = note,
                        x = noteX,
                        y = noteY,
                        lineSpacing = staffLineSpacing,
                        isBeginnerMode = isBeginnerMode,
                        textMeasurer = textMeasurer
                    )
                }
            }

            // Draw Real-time Playhead
            val beatsPerMeasure = score.timeSignatureNumerator.toFloat()
            val playheadX = startX + (currentPlayheadBeat / beatsPerMeasure) * mWidthPx
            if (playheadX in 0f..size.width) {
                // Playhead line
                drawLine(
                    color = CyanAccent,
                    start = Offset(playheadX, 20.dp.toPx()),
                    end = Offset(playheadX, size.height - 20.dp.toPx()),
                    strokeWidth = 3.dp.toPx()
                )
                // Playhead pointer diamond
                val diamondPath = Path().apply {
                    moveTo(playheadX, 20.dp.toPx())
                    lineTo(playheadX - 6.dp.toPx(), 12.dp.toPx())
                    lineTo(playheadX + 6.dp.toPx(), 12.dp.toPx())
                    close()
                }
                drawPath(diamondPath, color = CyanAccent)
            }
        }
    }
}

private fun DrawScope.drawStaffLines(
    topMargin: Float,
    lineSpacing: Float,
    totalWidth: Float,
    clef: ClefType
) {
    val lineCount = if (clef == ClefType.GRAND_STAFF) 11 else 5
    for (i in 0 until 5) {
        val y = topMargin + i * lineSpacing
        drawLine(
            color = Color(0xFF475569),
            start = Offset(10f, y),
            end = Offset(totalWidth, y),
            strokeWidth = 1.5.dp.toPx()
        )
    }

    if (clef == ClefType.GRAND_STAFF) {
        val bassTop = topMargin + 7 * lineSpacing
        for (i in 0 until 5) {
            val y = bassTop + i * lineSpacing
            drawLine(
                color = Color(0xFF475569),
                start = Offset(10f, y),
                end = Offset(totalWidth, y),
                strokeWidth = 1.5.dp.toPx()
            )
        }
    }
}

private fun DrawScope.drawClefHeader(
    clef: ClefType,
    topMargin: Float,
    lineSpacing: Float,
    keySignature: String,
    textMeasurer: TextMeasurer
) {
    val symbol = when (clef) {
        ClefType.TREBLE -> "𝄞"
        ClefType.BASS -> "𝄢"
        ClefType.PERCUSSION -> "𝄥"
        ClefType.GRAND_STAFF -> "𝄞"
    }

    drawText(
        textMeasurer = textMeasurer,
        text = symbol,
        topLeft = Offset(12.dp.toPx(), topMargin - 8.dp.toPx()),
        style = TextStyle(color = TextPrimary, fontSize = 34.sp)
    )

    // Time signature (4/4)
    drawText(
        textMeasurer = textMeasurer,
        text = "4\n4",
        topLeft = Offset(42.dp.toPx(), topMargin),
        style = TextStyle(color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    )
}

private fun calculateNoteY(
    midi: Int,
    topMargin: Float,
    lineSpacing: Float,
    clef: ClefType
): Float {
    // In Treble clef:
    // F5 = line 0 (top line) = topMargin
    // E5 = space 0.5
    // D5 = line 1
    // C5 = space 1.5
    // B4 = line 2 (middle line)
    // A4 = space 2.5
    // G4 = line 3
    // F4 = space 3.5
    // E4 = line 4 (bottom line)
    // D4 = space 4.5
    // C4 (Middle C) = line 5 (ledger line)
    val semitonesFromB4 = midi - 71 // B4 is MIDI 71
    val steps = semitonesToStaffSteps(semitonesFromB4)
    val middleLineY = topMargin + 2 * lineSpacing
    return middleLineY - (steps * (lineSpacing / 2f))
}

private fun semitonesToStaffSteps(semitones: Int): Float {
    // Diatonic step approximation
    return (semitones / 1.714f)
}

private fun DrawScope.drawMusicalNote(
    note: MusicalNote,
    x: Float,
    y: Float,
    lineSpacing: Float,
    isBeginnerMode: Boolean,
    textMeasurer: TextMeasurer
) {
    val noteRadiusX = 7.dp.toPx()
    val noteRadiusY = 5.dp.toPx()
    val isOpen = note.duration == NoteDuration.WHOLE || note.duration == NoteDuration.HALF

    // Beginner color-coding (Rainbow/Boomwhacker colors for pitch identification)
    val pitchColor = if (isBeginnerMode) {
        val rootChar = note.pitchName.firstOrNull() ?: 'C'
        when (rootChar) {
            'C' -> Color(0xFFEF4444) // Red
            'D' -> Color(0xFFF97316) // Orange
            'E' -> Color(0xFFFBBF24) // Yellow
            'F' -> Color(0xFF10B981) // Green
            'G' -> Color(0xFF06B6D4) // Cyan
            'A' -> Color(0xFF6366F1) // Indigo
            'B' -> Color(0xFFA855F7) // Purple
            else -> TextPrimary
        }
    } else TextPrimary

    // Draw Notehead
    if (isOpen) {
        drawOval(
            color = pitchColor,
            topLeft = Offset(x - noteRadiusX, y - noteRadiusY),
            size = Size(noteRadiusX * 2, noteRadiusY * 2),
            style = Stroke(width = 2.5.dp.toPx())
        )
    } else {
        drawOval(
            color = pitchColor,
            topLeft = Offset(x - noteRadiusX, y - noteRadiusY),
            size = Size(noteRadiusX * 2, noteRadiusY * 2)
        )
    }

    // Beginner Mode: Letter name engraved inside/above notehead!
    if (isBeginnerMode) {
        val noteLetter = note.pitchName.filter { it.isLetter() || it == '#' }
        drawText(
            textMeasurer = textMeasurer,
            text = noteLetter,
            topLeft = Offset(x - 5.dp.toPx(), y - 16.dp.toPx()),
            style = TextStyle(
                color = pitchColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        )
    }

    // Stem (for half, quarter, eighth, sixteenth)
    if (note.duration != NoteDuration.WHOLE) {
        val stemLength = 32.dp.toPx()
        drawLine(
            color = pitchColor,
            start = Offset(x + noteRadiusX - 1.dp.toPx(), y),
            end = Offset(x + noteRadiusX - 1.dp.toPx(), y - stemLength),
            strokeWidth = 2.dp.toPx()
        )

        // Eighth / Sixteenth flag
        if (note.duration == NoteDuration.EIGHTH || note.duration == NoteDuration.SIXTEENTH) {
            val flagPath = Path().apply {
                moveTo(x + noteRadiusX - 1.dp.toPx(), y - stemLength)
                cubicTo(
                    x + noteRadiusX + 8.dp.toPx(), y - stemLength + 4.dp.toPx(),
                    x + noteRadiusX + 10.dp.toPx(), y - stemLength + 14.dp.toPx(),
                    x + noteRadiusX + 4.dp.toPx(), y - stemLength + 18.dp.toPx()
                )
            }
            drawPath(flagPath, color = pitchColor, style = Stroke(width = 2.dp.toPx()))
        }
    }

    // Vocal Nuance Engravings (Vibrato, Scoop, Glissando, Bend)
    note.vocalNuance?.let { nuance ->
        when (nuance.ornament) {
            VocalOrnament.VIBRATO -> {
                // Wavy vibrato line ~~~ above note
                val waveY = y - 36.dp.toPx()
                val wavePath = Path().apply {
                    moveTo(x - 10.dp.toPx(), waveY)
                    for (step in 0..3) {
                        relativeQuadraticTo(4.dp.toPx(), -3.dp.toPx(), 8.dp.toPx(), 0f)
                        relativeQuadraticTo(4.dp.toPx(), 3.dp.toPx(), 8.dp.toPx(), 0f)
                    }
                }
                drawPath(wavePath, color = VioletAccent, style = Stroke(width = 1.8.dp.toPx()))
                drawText(
                    textMeasurer = textMeasurer,
                    text = "vib.",
                    topLeft = Offset(x - 12.dp.toPx(), waveY - 14.dp.toPx()),
                    style = TextStyle(color = VioletAccent, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
                )
            }
            VocalOrnament.SCOOP -> {
                // Curved scoop entering notehead
                val scoopPath = Path().apply {
                    moveTo(x - 16.dp.toPx(), y + 10.dp.toPx())
                    quadraticTo(x - 8.dp.toPx(), y + 6.dp.toPx(), x - 4.dp.toPx(), y)
                }
                drawPath(scoopPath, color = CyanAccent, style = Stroke(width = 2.dp.toPx()))
            }
            VocalOrnament.FALL -> {
                // Falling slide away from notehead
                val fallPath = Path().apply {
                    moveTo(x + 10.dp.toPx(), y)
                    quadraticTo(x + 16.dp.toPx(), y + 6.dp.toPx(), x + 24.dp.toPx(), y + 12.dp.toPx())
                }
                drawPath(fallPath, color = EmeraldTune, style = Stroke(width = 2.dp.toPx()))
            }
            VocalOrnament.GLISSANDO -> {
                // Straight diagonal glissando slide
                drawLine(
                    color = VioletAccent,
                    start = Offset(x + 12.dp.toPx(), y),
                    end = Offset(x + 36.dp.toPx(), y - 10.dp.toPx()),
                    strokeWidth = 1.5.dp.toPx()
                )
                drawText(
                    textMeasurer = textMeasurer,
                    text = "gliss.",
                    topLeft = Offset(x + 14.dp.toPx(), y - 18.dp.toPx()),
                    style = TextStyle(color = VioletAccent, fontSize = 9.sp)
                )
            }
            VocalOrnament.BEND_UP -> {
                // Bend arrow
                drawText(
                    textMeasurer = textMeasurer,
                    text = "⤴",
                    topLeft = Offset(x - 4.dp.toPx(), y - 24.dp.toPx()),
                    style = TextStyle(color = CyanAccent, fontSize = 14.sp)
                )
            }
            else -> {}
        }
    }

    // Lyric syllable below staff
    note.lyricSyllable?.let { lyric ->
        drawText(
            textMeasurer = textMeasurer,
            text = lyric,
            topLeft = Offset(x - 8.dp.toPx(), y + 26.dp.toPx()),
            style = TextStyle(color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        )
    }
}
