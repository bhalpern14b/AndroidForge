package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.InstrumentTrack
import com.example.model.InstrumentType
import com.example.ui.theme.BassColor
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DrumsColor
import com.example.ui.theme.EmeraldTune
import com.example.ui.theme.GuitarColor
import com.example.ui.theme.PianoColor
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ViolinColor
import com.example.ui.theme.VocalColor

@Composable
fun MultiTrackMixer(
    tracks: List<InstrumentTrack>,
    selectedTrackId: String,
    onSelectTrack: (String) -> Unit,
    onTrackVolumeChanged: (String, Float) -> Unit,
    onToggleMute: (String) -> Unit,
    onToggleSolo: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = StudioSurface),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = "Mixer",
                        tint = CyanAccent,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Full Arrangement Stems Mixer",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Surface(
                    color = EmeraldTune.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "SIMULTANEOUS PLAYBACK",
                        color = EmeraldTune,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Stem Track Rows
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                tracks.forEach { track ->
                    TrackStemRow(
                        track = track,
                        isSelected = track.trackId == selectedTrackId,
                        onSelect = { onSelectTrack(track.trackId) },
                        onVolumeChanged = { onTrackVolumeChanged(track.trackId, it) },
                        onToggleMute = { onToggleMute(track.trackId) },
                        onToggleSolo = { onToggleSolo(track.trackId) }
                    )
                }
            }
        }
    }
}

@Composable
private fun TrackStemRow(
    track: InstrumentTrack,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onVolumeChanged: (Float) -> Unit,
    onToggleMute: () -> Unit,
    onToggleSolo: () -> Unit
) {
    val instrumentColor = when (track.instrument) {
        InstrumentType.PIANO -> PianoColor
        InstrumentType.GUITAR -> GuitarColor
        InstrumentType.BASS -> BassColor
        InstrumentType.DRUMS -> DrumsColor
        InstrumentType.VIOLIN -> ViolinColor
        InstrumentType.VOCALS -> VocalColor
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable { onSelect() },
        color = if (isSelected) StudioSurfaceVariant else Color(0xFF0F172A),
        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, instrumentColor) else null,
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Color indicator dot & Instrument Name
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .background(instrumentColor, CircleShape)
            )
            Spacer(modifier = Modifier.width(8.dp))

            Column(modifier = Modifier.width(90.dp)) {
                Text(
                    text = track.name,
                    color = if (isSelected) TextPrimary else TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    maxLines = 1
                )
                Text(
                    text = track.instrument.displayName,
                    color = instrumentColor,
                    fontSize = 10.sp
                )
            }

            // Volume Slider
            Slider(
                value = if (track.isMuted) 0f else track.volume,
                onValueChange = onVolumeChanged,
                valueRange = 0f..1f,
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 4.dp),
                colors = SliderDefaults.colors(
                    thumbColor = instrumentColor,
                    activeTrackColor = instrumentColor,
                    inactiveTrackColor = Color(0xFF334155)
                )
            )

            // MUTE Button
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (track.isMuted) Color(0xFFEF4444) else Color(0xFF1E293B))
                    .border(1.dp, Color(0xFF475569), RoundedCornerShape(6.dp))
                    .clickable { onToggleMute() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "M",
                    color = if (track.isMuted) Color.White else TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            // SOLO Button
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (track.isSolo) Color(0xFFF59E0B) else Color(0xFF1E293B))
                    .border(1.dp, Color(0xFF475569), RoundedCornerShape(6.dp))
                    .clickable { onToggleSolo() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "S",
                    color = if (track.isSolo) Color.Black else TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
