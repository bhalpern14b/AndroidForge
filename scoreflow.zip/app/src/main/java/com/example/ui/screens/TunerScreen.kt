package com.example.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MusicalNote
import com.example.model.VocalOrnament
import com.example.ui.HarmoniqViewModel
import com.example.ui.components.AudioWaveformVisualizer
import com.example.ui.components.DigitalMetronomeCard
import com.example.ui.components.TunerGauge
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.EmeraldTune
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletAccent

@Composable
fun TunerScreen(
    viewModel: HarmoniqViewModel,
    modifier: Modifier = Modifier
) {
    val tunerState by viewModel.audioRecorder.tunerState.collectAsState()
    val isRecording by viewModel.audioRecorder.isRecording.collectAsState()
    val rawWaveformPoints by viewModel.audioRecorder.rawWaveformPoints.collectAsState()
    val waveforms by viewModel.audioRecorder.waveformAmplitudes.collectAsState()
    val detectedChord by viewModel.audioRecorder.detectedChordInfo.collectAsState()
    val chordHistory by viewModel.audioRecorder.chordHistory.collectAsState()
    val capoFret by viewModel.guitarCapoFret.collectAsState()
    val liveBpmState by viewModel.audioRecorder.liveBpmState.collectAsState()
    val metronomeConfig by viewModel.digitalMetronome.config.collectAsState()

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) viewModel.audioRecorder.startListening()
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Vocal & Instrument Tuner",
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Real-time chromatic cents, waveform & chord analysis",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }

                Button(
                    onClick = {
                        if (isRecording) viewModel.audioRecorder.stopListening()
                        else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isRecording) Color(0xFFEF4444) else CyanAccent
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = if (isRecording) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = null,
                        tint = if (isRecording) Color.White else Color(0xFF090D16)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isRecording) "Stop" else "Listen",
                        color = if (isRecording) Color.White else Color(0xFF090D16),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Real-Time Audio Waveform Visualizer & Live Chord Progression & BPM Detection
        item {
            AudioWaveformVisualizer(
                isRecording = isRecording,
                rawWaveformPoints = rawWaveformPoints,
                amplitudes = waveforms,
                detectedChord = detectedChord,
                chordHistory = chordHistory,
                capoFret = capoFret,
                liveBpmState = liveBpmState,
                onApplyDetectedBpm = { bpm -> viewModel.applyDetectedBpmToScore(bpm) }
            )
        }

        // Configurable Digital Metronome
        item {
            DigitalMetronomeCard(
                metronome = viewModel.digitalMetronome,
                config = metronomeConfig,
                onBpmChanged = { bpm -> viewModel.setBpm(bpm) }
            )
        }

        // Main Tuner Gauge Card
        item {
            TunerGauge(tunerState = tunerState)
        }

        // Professional Vocal Nuance Guide Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioSurface),
                shape = RoundedCornerShape(18.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Vocal Nuance Detection Engine",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Harmoniq continuously monitors microtonal fluctuations to transcribe expressive nuances.",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    NuanceIndicatorRow(
                        title = "Vocal Vibrato (~)",
                        description = "Detected at 4.5 - 6.5 Hz oscillation. Transcribed as wavy line over noteheads.",
                        active = tunerState.activeOrnament == VocalOrnament.VIBRATO || tunerState.vibratoDepthCents > 12f,
                        color = VioletAccent
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    NuanceIndicatorRow(
                        title = "Vocal Scoop (⤴) & Fall (⤵)",
                        description = "Sliding up or down into target pitches. Transcribed as curved expression lines.",
                        active = tunerState.activeOrnament == VocalOrnament.SCOOP || tunerState.activeOrnament == VocalOrnament.FALL,
                        color = CyanAccent
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    NuanceIndicatorRow(
                        title = "Dynamic Shifts (p to ff)",
                        description = "Vocal loudness contour mapped directly to classical dynamic markings below the staff.",
                        active = tunerState.signalStrengthDb > -30f,
                        color = EmeraldTune
                    )
                }
            }
        }

        // Reference Pitch Generator (Tone Generator)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioSurface),
                shape = RoundedCornerShape(18.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.VolumeUp, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Reference Tone Generator",
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            Pair("A4 (440Hz)", 69),
                            Pair("C4 (261Hz)", 60),
                            Pair("E4 (329Hz)", 64),
                            Pair("G4 (392Hz)", 67)
                        ).forEach { (label, midi) ->
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { viewModel.previewNote(MusicalNote(pitchName = label, midiNote = midi)) },
                                color = StudioSurfaceVariant
                            ) {
                                Text(
                                    text = label,
                                    color = TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(vertical = 10.dp),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun NuanceIndicatorRow(
    title: String,
    description: String,
    active: Boolean,
    color: Color
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color(0xFF0F172A),
        shape = RoundedCornerShape(10.dp),
        border = if (active) androidx.compose.foundation.BorderStroke(1.dp, color) else null
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .background(if (active) color else Color(0xFF475569), CircleShape)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(text = title, color = if (active) color else TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(text = description, color = TextSecondary, fontSize = 11.sp)
            }
        }
    }
}
