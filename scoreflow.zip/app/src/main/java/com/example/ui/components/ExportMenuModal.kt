package com.example.ui.components

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.export.ExportManager
import com.example.model.InstrumentTrack
import com.example.model.SongScore
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.EmeraldTune
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletAccent

@Composable
fun ExportMenuModal(
    score: SongScore,
    activeTrack: InstrumentTrack,
    onDismiss: () -> Unit,
    onStatusMessage: (String) -> Unit
) {
    val context = LocalContext.current

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = StudioSurface),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, CyanAccent.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Export Composition",
                            color = TextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = score.title,
                            color = CyanAccent,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    // 1. PDF Sheet Music for Printing
                    item {
                        ExportFormatItem(
                            icon = Icons.Default.PictureAsPdf,
                            iconColor = Color(0xFFEF4444),
                            title = "Printable Sheet Music (PDF)",
                            badge = "PRINT READY",
                            badgeColor = Color(0xFFEF4444),
                            subtitle = "Full engraving with grand staff, guitar tabs, chords & lyrics",
                            actionLabel = "Print / Export PDF",
                            onClick = {
                                val pdfFile = ExportManager.exportToPdf(context, score, activeTrack)
                                ExportManager.shareFile(context, pdfFile, "application/pdf", "Print or Share Sheet Music")
                                onStatusMessage("Generated PDF Sheet Music ready for printing!")
                                onDismiss()
                            }
                        )
                    }

                    // 2. MIDI File for External DAWs
                    item {
                        ExportFormatItem(
                            icon = Icons.Default.MusicNote,
                            iconColor = CyanAccent,
                            title = "Multi-Track MIDI (.mid)",
                            badge = "DAW READY",
                            badgeColor = CyanAccent,
                            subtitle = "Ableton, Logic, FL Studio, Pro Tools, Reaper. Includes vocal pitch bends",
                            actionLabel = "Open in DAW",
                            onClick = {
                                val midiFile = ExportManager.exportToMidi(context, score)
                                ExportManager.shareFile(context, midiFile, "audio/midi", "Open MIDI in DAW")
                                onStatusMessage("Generated Multi-Track MIDI for external DAWs!")
                                onDismiss()
                            }
                        )
                    }

                    // 3. MusicXML Score
                    item {
                        ExportFormatItem(
                            icon = Icons.Default.Description,
                            iconColor = VioletAccent,
                            title = "MusicXML Score (.musicxml)",
                            badge = "NOTATION",
                            badgeColor = VioletAccent,
                            subtitle = "For MuseScore, Finale, Sibelius, and Dorico score editors",
                            actionLabel = "Export MusicXML",
                            onClick = {
                                val xmlFile = ExportManager.exportToMusicXml(context, score)
                                ExportManager.shareFile(context, xmlFile, "application/vnd.recordare.musicxml+xml", "Export MusicXML")
                                onStatusMessage("Generated MusicXML score file!")
                                onDismiss()
                            }
                        )
                    }

                    // 4. Lead Sheet / Chord Chart Text
                    item {
                        ExportFormatItem(
                            icon = Icons.Default.Print,
                            iconColor = EmeraldTune,
                            title = "Lead Sheet & Chord Chart (.txt)",
                            badge = "CHORDS",
                            badgeColor = EmeraldTune,
                            subtitle = "Formatted lyrics and chords chart for gig binders and practice",
                            actionLabel = "Export Chord Chart",
                            onClick = {
                                val txtFile = ExportManager.exportToChordPro(context, score)
                                ExportManager.shareFile(context, txtFile, "text/plain", "Export Chord Chart")
                                onStatusMessage("Generated Lead Sheet chord chart!")
                                onDismiss()
                            }
                        )
                    }

                    // 5. Cloud Collaboration Link
                    item {
                        ExportFormatItem(
                            icon = Icons.Default.Link,
                            iconColor = Color(0xFFF59E0B),
                            title = "Shareable Cloud Invite Link",
                            badge = "CLOUD",
                            badgeColor = Color(0xFFF59E0B),
                            subtitle = "Invite bandmates to view score, arrange stems & leave comments",
                            actionLabel = "Copy Link",
                            onClick = {
                                onStatusMessage("Copied shareable cloud link to clipboard!")
                                onDismiss()
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onDismiss() },
                    color = StudioSurfaceVariant
                ) {
                    Text(
                        text = "Cancel",
                        color = TextSecondary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(vertical = 10.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
private fun ExportFormatItem(
    icon: ImageVector,
    iconColor: Color,
    title: String,
    badge: String,
    badgeColor: Color,
    subtitle: String,
    actionLabel: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() },
        color = Color(0xFF0F172A),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(iconColor.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(22.dp))
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = title, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(color = badgeColor.copy(alpha = 0.15f), shape = RoundedCornerShape(4.dp)) {
                        Text(
                            text = badge,
                            color = badgeColor,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(text = subtitle, color = TextSecondary, fontSize = 11.sp, lineHeight = 15.sp)
            }

            Spacer(modifier = Modifier.width(8.dp))

            Surface(
                color = StudioSurfaceVariant,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = actionLabel,
                    color = CyanAccent,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                )
            }
        }
    }
}
