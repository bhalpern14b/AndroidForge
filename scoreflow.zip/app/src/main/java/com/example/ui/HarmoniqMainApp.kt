package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.ArrangerScreen
import com.example.ui.screens.CloudWorkspaceScreen
import com.example.ui.screens.ScoreViewerScreen
import com.example.ui.screens.StudioTranscribeScreen
import com.example.ui.screens.TunerScreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.StudioBackground
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun HarmoniqMainApp(
    viewModel: HarmoniqViewModel = viewModel()
) {
    val currentScreen by viewModel.currentScreen.collectAsState()

    // BackHandler: return to Studio if on secondary screen
    BackHandler(enabled = currentScreen != AppNavScreen.STUDIO) {
        viewModel.setScreen(AppNavScreen.STUDIO)
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        containerColor = StudioBackground,
        bottomBar = {
            NavigationBar(
                containerColor = StudioSurface,
                tonalElevation = 8.dp,
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                listOf(
                    Pair(AppNavScreen.STUDIO, Icons.Default.Mic),
                    Pair(AppNavScreen.SCORE, Icons.Default.MusicNote),
                    Pair(AppNavScreen.TUNER, Icons.Default.Tune),
                    Pair(AppNavScreen.CLOUD, Icons.Default.Cloud),
                    Pair(AppNavScreen.ARRANGER, Icons.Default.Layers)
                ).forEach { (screen, icon) ->
                    val isSelected = currentScreen == screen
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { viewModel.setScreen(screen) },
                        icon = {
                            Icon(
                                imageVector = icon,
                                contentDescription = screen.title,
                                tint = if (isSelected) Color(0xFF090D16) else TextSecondary
                            )
                        },
                        label = {
                            Text(
                                text = screen.title,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) CyanAccent else TextSecondary
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = CyanAccent,
                            selectedIconColor = Color(0xFF090D16),
                            unselectedIconColor = TextSecondary,
                            selectedTextColor = CyanAccent,
                            unselectedTextColor = TextSecondary
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(StudioBackground)
        ) {
            when (currentScreen) {
                AppNavScreen.STUDIO -> StudioTranscribeScreen(viewModel = viewModel)
                AppNavScreen.SCORE -> ScoreViewerScreen(viewModel = viewModel)
                AppNavScreen.TUNER -> TunerScreen(viewModel = viewModel)
                AppNavScreen.CLOUD -> CloudWorkspaceScreen(viewModel = viewModel)
                AppNavScreen.ARRANGER -> ArrangerScreen(viewModel = viewModel)
            }
        }
    }
}
