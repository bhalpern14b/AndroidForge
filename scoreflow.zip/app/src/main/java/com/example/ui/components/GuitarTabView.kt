package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.InstrumentTrack
import com.example.model.MusicalNote
import com.example.model.SongScore
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.GuitarColor
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun GuitarTabView(
    score: SongScore,
    track: InstrumentTrack,
    currentPlayheadBeat: Float,
    isBeginnerMode: Boolean,
    onNoteTapped: (MusicalNote) -> Unit,
    modifier: Modifier = Modifier,
    capoFret: Int = 0
) {
    val textMeasurer = rememberTextMeasurer()
    val measureCount = maxOf(4, track.measures.size)
    val measureWidth = 260.dp
    val totalWidth = measureWidth * measureCount + 80.dp
    val scrollState = rememberScrollState()

    val stringNames = listOf("e", "B", "G", "D", "A", "E") // String 1 to 6

    Box(modifier = modifier.horizontalScroll(scrollState)) {
        Canvas(
            modifier = Modifier
                .width(totalWidth)
                .height(240.dp)
                .pointerInput(track) {
                    detectTapGestures { offset ->
                        val startX = 60.dp.toPx()
                        val mWidthPx = measureWidth.toPx()
                        val mIndex = ((offset.x - startX) / mWidthPx).toInt()
                        if (mIndex in track.measures.indices) {
                            val notes = track.measures[mIndex].notes
                            if (notes.isNotEmpty()) onNoteTapped(notes.first())
                        }
                    }
                }
        ) {
            val lineSpacing = 16.dp.toPx()
            val startX = 60.dp.toPx()
            val topMargin = 60.dp.toPx()
            val mWidthPx = measureWidth.toPx()

            // Draw "TAB" Header & String labels
            drawText(
                textMeasurer = textMeasurer,
                text = if (capoFret > 0) "T\nA\nB\n\nC$capoFret" else "T\nA\nB",
                topLeft = Offset(14.dp.toPx(), topMargin + 8.dp.toPx()),
                style = TextStyle(
                    color = GuitarColor,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            )

            for (i in 0 until 6) {
                val y = topMargin + i * lineSpacing
                // String name
                drawText(
                    textMeasurer = textMeasurer,
                    text = stringNames[i],
                    topLeft = Offset(42.dp.toPx(), y - 8.dp.toPx()),
                    style = TextStyle(color = TextSecondary, fontSize = 11.sp)
                )
                // 6 horizontal string lines
                drawLine(
                    color = Color(0xFF475569),
                    start = Offset(55.dp.toPx(), y),
                    end = Offset(size.width, y),
                    strokeWidth = 1.2.dp.toPx()
                )
            }

            // Draw Measures, Barlines & Fret numbers
            for ((mIdx, measure) in track.measures.withIndex()) {
                val mLeft = startX + mIdx * mWidthPx
                val mRight = mLeft + mWidthPx

                // Barline
                drawLine(
                    color = Color(0xFF64748B),
                    start = Offset(mRight, topMargin),
                    end = Offset(mRight, topMargin + lineSpacing * 5),
                    strokeWidth = 2.dp.toPx()
                )

                // Chord name above measure
                measure.chord?.let { chord ->
                    drawText(
                        textMeasurer = textMeasurer,
                        text = if (isBeginnerMode) "${chord.chordName} (${chord.romanNumeral})" else chord.chordName,
                        topLeft = Offset(mLeft + 12.dp.toPx(), topMargin - 32.dp.toPx()),
                        style = TextStyle(
                            color = GuitarColor,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )

                    // Beginner chord fingering box hint
                    if (isBeginnerMode) {
                        val fretsText = chord.guitarFrets.joinToString("-") { if (it == -1) "x" else it.toString() }
                        drawText(
                            textMeasurer = textMeasurer,
                            text = "Frets: $fretsText",
                            topLeft = Offset(mLeft + 12.dp.toPx(), topMargin - 16.dp.toPx()),
                            style = TextStyle(color = TextSecondary, fontSize = 10.sp)
                        )
                    }
                }

                // Notes as fret numbers on strings
                val notesInMeasure = measure.notes
                val noteSpacing = mWidthPx / (notesInMeasure.size.coerceAtLeast(1) + 1)

                for ((nIdx, note) in notesInMeasure.withIndex()) {
                    if (note.isRest) continue
                    val noteX = mLeft + (nIdx + 1) * noteSpacing
                    val stringIdx = (note.stringNumber - 1).coerceIn(0, 5)
                    val noteY = topMargin + stringIdx * lineSpacing

                    // Small background circle to clear the line
                    drawCircle(
                        color = Color(0xFF131B2E),
                        radius = 8.dp.toPx(),
                        center = Offset(noteX, noteY)
                    )

                    // Draw Fret Number
                    val fretStr = note.fretNumber.toString()
                    drawText(
                        textMeasurer = textMeasurer,
                        text = fretStr,
                        topLeft = Offset(noteX - 4.dp.toPx(), noteY - 8.dp.toPx()),
                        style = TextStyle(
                            color = if (isBeginnerMode) CyanAccent else TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }

            // Real-time Playhead
            val beatsPerMeasure = score.timeSignatureNumerator.toFloat()
            val playheadX = startX + (currentPlayheadBeat / beatsPerMeasure) * mWidthPx
            if (playheadX in 0f..size.width) {
                drawLine(
                    color = CyanAccent,
                    start = Offset(playheadX, 15.dp.toPx()),
                    end = Offset(playheadX, size.height - 15.dp.toPx()),
                    strokeWidth = 3.dp.toPx()
                )
            }
        }
    }
}
