package com.example.ui.screens

import android.Manifest
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.HarmoniqViewModel
import com.example.ui.components.AudioWaveformVisualizer
import com.example.ui.components.DigitalMetronomeCard
import com.example.ui.components.GuitarCapoController
import com.example.ui.components.TunerGauge
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.EmeraldTune
import com.example.ui.theme.GuitarColor
import com.example.ui.theme.PianoColor
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletAccent

@Composable
fun StudioTranscribeScreen(
    viewModel: HarmoniqViewModel,
    modifier: Modifier = Modifier
) {
    val isRecording by viewModel.audioRecorder.isRecording.collectAsState()
    val tunerState by viewModel.audioRecorder.tunerState.collectAsState()
    val waveforms by viewModel.audioRecorder.waveformAmplitudes.collectAsState()
    val rawWaveformPoints by viewModel.audioRecorder.rawWaveformPoints.collectAsState()
    val detectedChord by viewModel.audioRecorder.detectedChordInfo.collectAsState()
    val chordHistory by viewModel.audioRecorder.chordHistory.collectAsState()
    val capoFret by viewModel.guitarCapoFret.collectAsState()
    val liveBpmState by viewModel.audioRecorder.liveBpmState.collectAsState()
    val metronomeConfig by viewModel.digitalMetronome.config.collectAsState()

    var selectedAudioUri by remember { mutableStateOf<Uri?>(null) }
    var uploadStatusMessage by remember { mutableStateOf<String?>(null) }

    // Audio file picker launcher
    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedAudioUri = uri
            uploadStatusMessage = "Analyzing audio stems & vocal pitch contour..."
            // Transcribe uploaded audio
            viewModel.loadPreloadedScore(0)
        }
    }

    // Permission launcher for RECORD_AUDIO
    val recordPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.startLiveRecording()
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            // Studio Hero Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = StudioSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Harmoniq Studio",
                                color = TextPrimary,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Sing, play or upload to generate sheet music & chords",
                                color = TextSecondary,
                                fontSize = 13.sp
                            )
                        }

                        Surface(
                            color = CyanAccent.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "MULTI-INSTRUMENT",
                                color = CyanAccent,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Live Recording Action Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF0F172A))
                            .border(1.dp, if (isRecording) Color(0xFFEF4444) else Color(0xFF334155), RoundedCornerShape(16.dp))
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            // Live Audio Waveform Animation
                            if (isRecording) {
                                Canvas(modifier = Modifier.fillMaxWidth().height(48.dp)) {
                                    val barWidth = size.width / (waveforms.size.coerceAtLeast(1) + 1)
                                    waveforms.forEachIndexed { idx, amp ->
                                        val x = idx * barWidth + barWidth / 2
                                        val h = (amp * size.height).coerceIn(4.dp.toPx(), size.height)
                                        drawLine(
                                            color = CyanAccent,
                                            start = Offset(x, (size.height - h) / 2),
                                            end = Offset(x, (size.height + h) / 2),
                                            strokeWidth = 3.dp.toPx()
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Text(
                                    text = if (tunerState.detectedNote != "--") "Pitch: ${tunerState.detectedNote}${tunerState.octave} (${tunerState.centsDeviation.toInt()}¢)" else "Listening for melody...",
                                    color = EmeraldTune,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                Button(
                                    onClick = { viewModel.stopLiveRecordingAndTranscribe() },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Stop, contentDescription = "Stop", tint = Color.White)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Stop & Transcribe All Instruments", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            } else {
                                // Start Recording Button
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Button(
                                        onClick = { recordPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(containerColor = CyanAccent),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Mic, contentDescription = "Mic", tint = Color(0xFF090D16))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Sing or Play", color = Color(0xFF090D16), fontWeight = FontWeight.Bold)
                                    }

                                    Button(
                                        onClick = { audioPickerLauncher.launch("audio/*") },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(containerColor = StudioSurfaceVariant),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.UploadFile, contentDescription = "Upload", tint = TextPrimary)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Upload Song", color = TextPrimary, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    uploadStatusMessage?.let { status ->
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(text = "✓ $status", color = EmeraldTune, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }

        // Real-Time Audio Waveform Visualizer & Live Chord Progression Label Analysis & BPM Detection
        item {
            AudioWaveformVisualizer(
                isRecording = isRecording,
                rawWaveformPoints = rawWaveformPoints,
                amplitudes = waveforms,
                detectedChord = detectedChord,
                chordHistory = chordHistory,
                capoFret = capoFret,
                liveBpmState = liveBpmState,
                onApplyDetectedBpm = { bpm -> viewModel.applyDetectedBpmToScore(bpm) }
            )
        }

        // Configurable Digital Metronome Card for Studio Practice & Recording Timing
        item {
            DigitalMetronomeCard(
                metronome = viewModel.digitalMetronome,
                config = metronomeConfig,
                onBpmChanged = { bpm -> viewModel.setBpm(bpm) }
            )
        }

        // Live Tuner & Vocal Nuance Monitor Widget
        item {
            TunerGauge(tunerState = tunerState)
        }

        // Guitar Capo & Dynamic Chord Setup Controller
        item {
            GuitarCapoController(
                currentCapoFret = capoFret,
                onCapoChanged = { viewModel.setCapo(it) },
                onPreviewSoundingChord = { viewModel.previewChords(it) }
            )
        }

        // Preloaded Demo Songs Header
        item {
            Text(
                text = "Instant Demo Master Compositions",
                color = TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Tap any song to immediately view sheet music, tabs & play simultaneous instruments",
                color = TextSecondary,
                fontSize = 12.sp
            )
        }

        // Preloaded Demo 1: Moonlight Acoustic Harmony
        item {
            DemoTrackCard(
                title = "Moonlight Acoustic Harmony",
                genre = "Acoustic Pop Ballad • 108 BPM",
                instruments = "Piano, Guitar Tabs, Bass, Drums, Violin, Vocals",
                color = GuitarColor,
                onSelect = { viewModel.loadPreloadedScore(0) }
            )
        }

        // Preloaded Demo 2: Autumn Leaves Vocal Ballad
        item {
            DemoTrackCard(
                title = "Autumn Leaves Vocal Ballad",
                genre = "Jazz / Neo-Soul • 92 BPM",
                instruments = "Grand Piano, Nuanced Vocals, Walking Bass, Violin",
                color = PianoColor,
                onSelect = { viewModel.loadPreloadedScore(1) }
            )
        }

        // Preloaded Demo 3: Neon Skyline Rock Anthem
        item {
            DemoTrackCard(
                title = "Neon Skyline Rock Anthem",
                genre = "Indie Rock • 132 BPM",
                instruments = "Distorted Tabs, Driving Bassline, Full Drum Kit",
                color = VioletAccent,
                onSelect = { viewModel.loadPreloadedScore(2) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}

@Composable
private fun DemoTrackCard(
    title: String,
    genre: String,
    instruments: String,
    color: Color,
    onSelect: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onSelect() },
        color = StudioSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155)),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(color.copy(alpha = 0.2f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = Icons.Default.Audiotrack, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(text = genre, color = color, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                Text(text = instruments, color = TextSecondary, fontSize = 11.sp, maxLines = 1)
            }

            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Play", tint = CyanAccent, modifier = Modifier.size(28.dp))
        }
    }
}
