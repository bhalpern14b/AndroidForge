package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.DetectedChordInfo
import com.example.model.LiveAudioBpmState
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.EmeraldTune
import com.example.ui.theme.GuitarColor
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletAccent

@Composable
fun AudioWaveformVisualizer(
    isRecording: Boolean,
    rawWaveformPoints: List<Float>,
    amplitudes: List<Float>,
    detectedChord: DetectedChordInfo,
    chordHistory: List<String>,
    capoFret: Int,
    liveBpmState: LiveAudioBpmState = LiveAudioBpmState(),
    onApplyDetectedBpm: ((Int) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = StudioSurface),
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (isRecording) CyanAccent.copy(alpha = 0.6f) else Color(0xFF334155))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = "Visualizer",
                        tint = if (isRecording) CyanAccent else TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Real-Time Audio Analysis & Chords",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Surface(
                    color = if (isRecording) Color(0xFFEF4444).copy(alpha = 0.2f) else StudioSurfaceVariant,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(if (isRecording) Color(0xFFEF4444) else TextSecondary, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isRecording) "LIVE INPUT ACTIVE" else "STANDBY",
                            color = if (isRecording) Color(0xFFEF4444) else TextSecondary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Real-Time Oscilloscope / Waveform Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(80.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF090D16))
                    .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(14.dp))
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Canvas(modifier = Modifier.matchParentSize()) {
                    val centerY = size.height / 2f
                    val w = size.width

                    // Center line guide
                    drawLine(
                        color = Color(0xFF1E293B),
                        start = Offset(0f, centerY),
                        end = Offset(w, centerY),
                        strokeWidth = 1.dp.toPx()
                    )

                    if (isRecording && rawWaveformPoints.isNotEmpty()) {
                        val path = Path()
                        val stepX = w / (rawWaveformPoints.size.coerceAtLeast(1) - 1).toFloat()

                        for ((index, value) in rawWaveformPoints.withIndex()) {
                            val x = index * stepX
                            val ampScale = (value * (centerY * 0.9f)).coerceIn(-centerY, centerY)
                            val y = centerY + ampScale

                            if (index == 0) path.moveTo(x, y)
                            else path.lineTo(x, y)
                        }

                        // Gradient wave stroke
                        drawPath(
                            path = path,
                            brush = Brush.horizontalGradient(
                                listOf(CyanAccent, VioletAccent, EmeraldTune)
                            ),
                            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                        )

                        // Amplitude bars on bottom
                        val barCount = amplitudes.size.coerceAtMost(30)
                        if (barCount > 0) {
                            val barW = w / (barCount * 2f)
                            for (i in 0 until barCount) {
                                val bAmp = amplitudes[i] * (size.height * 0.45f)
                                val bx = i * (barW * 2f) + barW
                                drawLine(
                                    color = CyanAccent.copy(alpha = 0.35f),
                                    start = Offset(bx, size.height),
                                    end = Offset(bx, size.height - bAmp),
                                    strokeWidth = barW,
                                    cap = StrokeCap.Round
                                )
                            }
                        }
                    } else {
                        // Subtle idle wave line
                        drawLine(
                            color = CyanAccent.copy(alpha = 0.3f),
                            start = Offset(0f, centerY),
                            end = Offset(w, centerY),
                            strokeWidth = 1.5.dp.toPx()
                        )
                    }
                }

                if (!isRecording) {
                    Text(
                        text = "Sing, hum, or play instrument to analyze notes & chords",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Real-time Detected Chord Progression Label Display
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFF0F172A),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyanAccent.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "ESTIMATED CHORD PROGRESSION",
                                color = TextSecondary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = detectedChord.chordName,
                                    color = CyanAccent,
                                    fontSize = 26.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Surface(
                                    color = StudioSurfaceVariant,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = detectedChord.romanNumeral,
                                        color = EmeraldTune,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        // Capo indicator
                        Surface(
                            color = if (capoFret > 0) GuitarColor.copy(alpha = 0.15f) else StudioSurfaceVariant,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalAlignment = Alignment.End
                            ) {
                                Text(
                                    text = if (capoFret > 0) "CAPO FRET $capoFret" else "STANDARD TUNING",
                                    color = if (capoFret > 0) GuitarColor else TextSecondary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (capoFret > 0) detectedChord.capoShapeName else detectedChord.theoryRole,
                                    color = TextPrimary,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Real-time Detected BPM Indicator & Tempo Sync
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF090D16))
                            .border(1.dp, if (liveBpmState.isBeatFlashing) CyanAccent else Color(0xFF1E293B), RoundedCornerShape(10.dp))
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .background(
                                        if (liveBpmState.isBeatFlashing) Color(0xFFEF4444)
                                        else if (liveBpmState.detectedBpm > 0) EmeraldTune
                                        else TextSecondary,
                                        CircleShape
                                    )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = if (liveBpmState.detectedBpm > 0) "${liveBpmState.detectedBpm} BPM" else "Detecting Tempo...",
                                        color = if (liveBpmState.detectedBpm > 0) CyanAccent else TextSecondary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (liveBpmState.confidencePercent > 0) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "(${liveBpmState.confidencePercent}% match)",
                                            color = EmeraldTune,
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                                Text(
                                    text = liveBpmState.tempoLabel,
                                    color = TextSecondary,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        if (liveBpmState.detectedBpm > 0 && onApplyDetectedBpm != null) {
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { onApplyDetectedBpm(liveBpmState.detectedBpm) },
                                color = CyanAccent
                            ) {
                                Text(
                                    text = "SYNC TO METRONOME",
                                    color = Color(0xFF090D16),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Live Chord History Ribbon
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Progression: ",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                        chordHistory.take(4).forEachIndexed { idx, ch ->
                            Surface(
                                color = if (idx == 0) CyanAccent.copy(alpha = 0.2f) else Color(0xFF1E293B),
                                shape = RoundedCornerShape(6.dp),
                                border = if (idx == 0) androidx.compose.foundation.BorderStroke(1.dp, CyanAccent) else null
                            ) {
                                Text(
                                    text = ch,
                                    color = if (idx == 0) CyanAccent else TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                            if (idx < 3 && idx < chordHistory.size - 1) {
                                Text("➔", color = TextSecondary, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
