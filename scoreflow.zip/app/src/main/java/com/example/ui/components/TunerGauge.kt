package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TunerState
import com.example.model.VocalOrnament
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.EmeraldTune
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletAccent
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun TunerGauge(
    tunerState: TunerState,
    modifier: Modifier = Modifier
) {
    val animatedCents by animateFloatAsState(
        targetValue = tunerState.centsDeviation,
        animationSpec = spring(),
        label = "cents"
    )

    val gaugeColor by animateColorAsState(
        targetValue = if (tunerState.isInTune) EmeraldTune else if (kotlin.math.abs(tunerState.centsDeviation) < 15) CyanAccent else AmberWarning,
        label = "gaugeColor"
    )

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = StudioSurface),
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155))
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Precision Tuner & Vocal Analyzer",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Surface(
                    color = if (tunerState.isInTune) EmeraldTune.copy(alpha = 0.2f) else StudioSurfaceVariant,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = if (tunerState.isInTune) "● IN TUNE (±5¢)" else "${if (tunerState.centsDeviation > 0) "+" else ""}${tunerState.centsDeviation.toInt()}¢",
                        color = gaugeColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Chromatic Dial & Needle
            Box(
                modifier = Modifier
                    .size(200.dp, 120.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.size(200.dp, 120.dp)) {
                    val center = Offset(size.width / 2, size.height - 10.dp.toPx())
                    val radius = size.width * 0.42f

                    // Background arc (-50 to +50 cents = -60 to +60 degrees)
                    drawArc(
                        color = Color(0xFF1E293B),
                        startAngle = 210f,
                        sweepAngle = 120f,
                        useCenter = false,
                        topLeft = Offset(center.x - radius, center.y - radius),
                        size = androidx.compose.ui.geometry.Size(radius * 2, radius * 2),
                        style = Stroke(width = 14.dp.toPx(), cap = StrokeCap.Round)
                    )

                    // In-Tune center sweet spot
                    drawArc(
                        color = EmeraldTune.copy(alpha = 0.4f),
                        startAngle = 264f,
                        sweepAngle = 12f,
                        useCenter = false,
                        topLeft = Offset(center.x - radius, center.y - radius),
                        size = androidx.compose.ui.geometry.Size(radius * 2, radius * 2),
                        style = Stroke(width = 14.dp.toPx())
                    )

                    // Needle
                    // Map cents (-50 to +50) to angle (-60 to +60 degrees from 270)
                    val needleAngleDeg = 270f + (animatedCents / 50f) * 60f
                    val needleAngleRad = (needleAngleDeg * PI / 180f).toFloat()
                    val needleLength = radius * 0.88f
                    val needleEnd = Offset(
                        center.x + needleLength * cos(needleAngleRad),
                        center.y + needleLength * sin(needleAngleRad)
                    )

                    drawLine(
                        color = gaugeColor,
                        start = center,
                        end = needleEnd,
                        strokeWidth = 3.5.dp.toPx(),
                        cap = StrokeCap.Round
                    )

                    // Center pivot dot
                    drawCircle(color = gaugeColor, radius = 6.dp.toPx(), center = center)
                }

                // Center Note & Octave Display
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(top = 10.dp)
                ) {
                    Text(
                        text = if (tunerState.detectedNote != "--") "${tunerState.detectedNote}${tunerState.octave}" else "--",
                        color = TextPrimary,
                        fontSize = 38.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = if (tunerState.detectedFrequencyHz > 0) String.format("%.1f Hz", tunerState.detectedFrequencyHz) else "Listening...",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Vocal Nuance Telemetry Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Intonation Stability
                Surface(
                    modifier = Modifier.weight(1f),
                    color = Color(0xFF0F172A),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("Stability", color = TextSecondary, fontSize = 10.sp)
                        Text("${tunerState.pitchStabilityPercent}%", color = CyanAccent, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { tunerState.pitchStabilityPercent / 100f },
                            modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                            color = CyanAccent,
                            trackColor = Color(0xFF334155)
                        )
                    }
                }

                // Vibrato Rate & Depth
                Surface(
                    modifier = Modifier.weight(1f),
                    color = Color(0xFF0F172A),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("Vibrato", color = TextSecondary, fontSize = 10.sp)
                        Text("${String.format("%.1f", tunerState.vibratoRateHz)} Hz", color = VioletAccent, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text("±${tunerState.vibratoDepthCents.toInt()}¢ depth", color = TextSecondary, fontSize = 10.sp)
                    }
                }

                // Vocal Dynamic Level
                Surface(
                    modifier = Modifier.weight(1f),
                    color = Color(0xFF0F172A),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("Expression", color = TextSecondary, fontSize = 10.sp)
                        Text(
                            text = when (tunerState.activeOrnament) {
                                VocalOrnament.VIBRATO -> "Vibrato ~"
                                VocalOrnament.SCOOP -> "Scoop ⤴"
                                VocalOrnament.FALL -> "Fall ⤵"
                                VocalOrnament.GLISSANDO -> "Gliss."
                                else -> "True Tone"
                            },
                            color = EmeraldTune,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(tunerState.dynamicMarking.symbol, color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
