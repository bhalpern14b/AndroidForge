package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.GeminiTranscriber
import com.example.audio.AudioRecordManager
import com.example.audio.AudioSynthesizer
import com.example.data.AppDatabase
import com.example.data.ScoreRepository
import com.example.model.AudioPitchFrame
import com.example.model.CloudProject
import com.example.model.InstrumentTrack
import com.example.model.InstrumentType
import com.example.model.MusicalNote
import com.example.model.SongScore
import com.example.model.TheoryTutorial
import com.example.model.TunerState
import com.example.transcription.TranscriptionEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class AppNavScreen(val title: String, val icon: String) {
    STUDIO("Studio", "mic"),
    SCORE("Sheet & Tabs", "music_note"),
    TUNER("Tuner & Voice", "tune"),
    CLOUD("Cloud Workspace", "cloud"),
    ARRANGER("Arranger", "layers")
}

class HarmoniqViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val repository = ScoreRepository(database.scoreDao())

    val audioSynthesizer = AudioSynthesizer(viewModelScope)
    val audioRecorder = AudioRecordManager(viewModelScope)
    val digitalMetronome = com.example.audio.DigitalMetronome(viewModelScope)

    // Current navigation tab
    private val _currentScreen = MutableStateFlow(AppNavScreen.STUDIO)
    val currentScreen: StateFlow<AppNavScreen> = _currentScreen.asStateFlow()

    // Current active score arrangement
    private val _currentScore = MutableStateFlow(TranscriptionEngine.getPreloadedDemoScore(0))
    val currentScore: StateFlow<SongScore> = _currentScore.asStateFlow()

    // Active track to display in sheet music canvas / tabs
    private val _selectedTrackId = MutableStateFlow("")
    val selectedTrackId: StateFlow<String> = _selectedTrackId.asStateFlow()

    // Beginner Mode Toggle
    private val _isBeginnerMode = MutableStateFlow(true)
    val isBeginnerMode: StateFlow<Boolean> = _isBeginnerMode.asStateFlow()

    // Show Beginner Theory Tutorial Modal
    private val _showTutorialModal = MutableStateFlow(false)
    val showTutorialModal: StateFlow<Boolean> = _showTutorialModal.asStateFlow()

    // Theory Tutorials
    val theoryTutorials: List<TheoryTutorial> = TranscriptionEngine.getBeginnerTheoryTutorials()

    // Captured pitch frames during recording
    private val recordedFrames = mutableListOf<AudioPitchFrame>()

    // Transposition and Capo
    private val _transposeSemitones = MutableStateFlow(0)
    val transposeSemitones: StateFlow<Int> = _transposeSemitones.asStateFlow()

    private val _guitarCapoFret = MutableStateFlow(0)
    val guitarCapoFret: StateFlow<Int> = _guitarCapoFret.asStateFlow()

    // Cloud workspace projects
    val cloudProjects: StateFlow<List<CloudProject>> = repository.cloudProjects

    // Active MIDI notes for Piano Roll lighting
    private val _activePianoKeys = MutableStateFlow<List<Int>>(emptyList())
    val activePianoKeys: StateFlow<List<Int>> = _activePianoKeys.asStateFlow()

    // AI Reharmonization loading indicator
    private val _isAiProcessing = MutableStateFlow(false)
    val isAiProcessing: StateFlow<Boolean> = _isAiProcessing.asStateFlow()

    init {
        // Default selected track is Piano or Vocals
        val firstTrack = _currentScore.value.tracks.firstOrNull { it.instrument == InstrumentType.PIANO }
            ?: _currentScore.value.tracks.firstOrNull()
        _selectedTrackId.value = firstTrack?.trackId ?: ""

        // Listen for real-time pitch frames to build transcription and light up piano roll
        viewModelScope.launch {
            audioRecorder.pitchFrames.collect { frame ->
                if (audioRecorder.isRecording.value) {
                    recordedFrames.add(frame)
                    _activePianoKeys.value = listOf(frame.midiPitch)
                }
            }
        }

        // Keep piano roll highlighted in sync with synthesizer playhead
        viewModelScope.launch {
            audioSynthesizer.currentPlayheadBeat.collect { beat ->
                val score = _currentScore.value
                val activeNotes = mutableListOf<Int>()
                for (track in score.tracks.filter { !it.isMuted }) {
                    for (measure in track.measures) {
                        for (note in measure.notes) {
                            if (!note.isRest && beat >= note.startBeat && beat < (note.startBeat + note.duration.beats)) {
                                activeNotes.add(note.midiNote)
                            }
                        }
                    }
                }
                _activePianoKeys.value = activeNotes.distinct()
            }
        }
    }

    fun setScreen(screen: AppNavScreen) {
        _currentScreen.value = screen
    }

    fun setSelectedTrack(trackId: String) {
        _selectedTrackId.value = trackId
    }

    fun toggleBeginnerMode() {
        val newMode = !_isBeginnerMode.value
        _isBeginnerMode.value = newMode
        _currentScore.value = _currentScore.value.copy(isBeginnerMode = newMode)
    }

    fun setShowTutorialModal(show: Boolean) {
        _showTutorialModal.value = show
    }

    fun startLiveRecording() {
        recordedFrames.clear()
        audioSynthesizer.stopPlayback()
        audioRecorder.startListening()
    }

    fun stopLiveRecordingAndTranscribe() {
        audioRecorder.stopListening()
        val transcribed = TranscriptionEngine.transcribeFromPitchFrames(
            frames = recordedFrames.toList(),
            title = "My Live Sung/Played Arrangement",
            bpm = _currentScore.value.bpm,
            isBeginnerMode = _isBeginnerMode.value
        )
        _currentScore.value = transcribed
        _selectedTrackId.value = transcribed.tracks.firstOrNull()?.trackId ?: ""
        viewModelScope.launch {
            repository.saveScore(transcribed)
            repository.addCloudProject(transcribed, "Live Recorded Session")
        }
        _currentScreen.value = AppNavScreen.SCORE
    }

    fun loadPreloadedScore(index: Int) {
        audioSynthesizer.stopPlayback()
        val score = TranscriptionEngine.getPreloadedDemoScore(index, _isBeginnerMode.value)
        _currentScore.value = score
        _selectedTrackId.value = score.tracks.firstOrNull { it.instrument == InstrumentType.PIANO }?.trackId
            ?: score.tracks.first().trackId
    }

    fun loadCloudProject(project: CloudProject) {
        audioSynthesizer.stopPlayback()
        _currentScore.value = project.score
        _selectedTrackId.value = project.score.tracks.firstOrNull()?.trackId ?: ""
        _currentScreen.value = AppNavScreen.SCORE
    }

    fun startPlayback() {
        audioSynthesizer.startPlayback(_currentScore.value)
    }

    fun pausePlayback() {
        audioSynthesizer.pausePlayback()
    }

    fun stopPlayback() {
        audioSynthesizer.stopPlayback()
    }

    fun previewNote(note: MusicalNote, instrument: InstrumentType = InstrumentType.PIANO) {
        audioSynthesizer.previewNote(note, instrument)
        _activePianoKeys.value = listOf(note.midiNote)
    }

    fun previewPianoKey(midi: Int, name: String) {
        val note = MusicalNote(pitchName = name, midiNote = midi)
        audioSynthesizer.previewNote(note, InstrumentType.PIANO)
        _activePianoKeys.value = listOf(midi)
    }

    fun previewChords(midiKeys: List<Int>) {
        audioSynthesizer.previewChord(midiKeys, InstrumentType.GUITAR)
    }

    fun updateTrackVolume(trackId: String, volume: Float) {
        val updatedTracks = _currentScore.value.tracks.map {
            if (it.trackId == trackId) it.copy(volume = volume) else it
        }
        _currentScore.value = _currentScore.value.copy(tracks = updatedTracks)
    }

    fun toggleTrackMute(trackId: String) {
        val updatedTracks = _currentScore.value.tracks.map {
            if (it.trackId == trackId) it.copy(isMuted = !it.isMuted) else it
        }
        _currentScore.value = _currentScore.value.copy(tracks = updatedTracks)
    }

    fun toggleTrackSolo(trackId: String) {
        val updatedTracks = _currentScore.value.tracks.map {
            if (it.trackId == trackId) it.copy(isSolo = !it.isSolo) else it
        }
        _currentScore.value = _currentScore.value.copy(tracks = updatedTracks)
    }

    fun setBpm(newBpm: Int) {
        val clamped = newBpm.coerceIn(40, 240)
        _currentScore.value = _currentScore.value.copy(bpm = clamped)
        digitalMetronome.setBpm(clamped)
    }

    fun applyDetectedBpmToScore(detectedBpm: Int) {
        if (detectedBpm in 40..240) {
            setBpm(detectedBpm)
        }
    }

    fun transpose(semitones: Int) {
        _transposeSemitones.value = _transposeSemitones.value + semitones
        // Transpose all notes and chords
        val updatedTracks = _currentScore.value.tracks.map { track ->
            val updatedMeasures = track.measures.map { measure ->
                val newNotes = measure.notes.map { note ->
                    if (note.isRest || track.instrument.isPercussion) note
                    else {
                        val newMidi = note.midiNote + semitones
                        note.copy(
                            midiNote = newMidi,
                            pitchName = note.pitchName // Diatonic update
                        )
                    }
                }
                measure.copy(notes = newNotes)
            }
            track.copy(measures = updatedMeasures)
        }
        _currentScore.value = _currentScore.value.copy(tracks = updatedTracks)
    }

    fun setCapo(fret: Int) {
        val clamped = fret.coerceIn(0, 10)
        _guitarCapoFret.value = clamped
        audioRecorder.setCapoFret(clamped)
    }

    fun addCommentToActiveProject(text: String, timecode: String, measure: Int) {
        val projId = _currentScore.value.cloudProjectId ?: "proj-1"
        repository.addCommentToProject(projId, "You (Collaborator)", text, timecode, measure)
    }

    fun applyAiReharmonization(style: String = "Jazz Neo-Soul") {
        viewModelScope.launch {
            _isAiProcessing.value = true
            val chords = _currentScore.value.chords.map { it.chordName }
            val reharmonized = GeminiTranscriber.analyzeAndReharmonize(_currentScore.value.keySignature, style, chords)
            _currentScore.value = _currentScore.value.copy(chords = reharmonized)
            _isAiProcessing.value = false
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioSynthesizer.release()
        audioRecorder.stopListening()
        digitalMetronome.release()
    }
}
