package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ChordDiagramInfo
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.EmeraldTune
import com.example.ui.theme.GuitarColor
import com.example.ui.theme.PianoColor
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletAccent

@Composable
fun ChordDiagramBox(
    chord: ChordDiagramInfo,
    capoFret: Int = 0,
    onPlayGuitarStrum: () -> Unit,
    onPlayPianoChord: () -> Unit,
    modifier: Modifier = Modifier
) {
    val textMeasurer = rememberTextMeasurer()

    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = StudioSurface),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Chord Title & Quality
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = chord.chordName,
                        color = CyanAccent,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = chord.quality,
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                if (capoFret > 0) {
                    Surface(
                        color = GuitarColor.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "Capo $capoFret",
                            color = GuitarColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 6-String Guitar Chord Box Canvas
            Canvas(modifier = Modifier.size(150.dp, 160.dp)) {
                val boxWidth = 110.dp.toPx()
                val boxHeight = 110.dp.toPx()
                val startX = 22.dp.toPx()
                val topY = 32.dp.toPx()
                val stringSpacing = boxWidth / 5f
                val fretSpacing = boxHeight / 4f

                val isNut = chord.baseFret <= 1
                val nutThickness = if (isNut) 5.dp.toPx() else 1.5.dp.toPx()

                // Nut or top fret bar
                drawLine(
                    color = if (isNut) Color(0xFFE2E8F0) else Color(0xFF64748B),
                    start = Offset(startX, topY),
                    end = Offset(startX + boxWidth, topY),
                    strokeWidth = nutThickness,
                    cap = StrokeCap.Square
                )

                // Base fret label (e.g. "3fr") if not at nut
                if (!isNut) {
                    drawText(
                        textMeasurer = textMeasurer,
                        text = "${chord.baseFret}fr",
                        topLeft = Offset(startX - 18.dp.toPx(), topY + 4.dp.toPx()),
                        style = TextStyle(color = TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    )
                }

                // 4 Horizontal Frets
                for (f in 1..4) {
                    val y = topY + f * fretSpacing
                    drawLine(
                        color = Color(0xFF475569),
                        start = Offset(startX, y),
                        end = Offset(startX + boxWidth, y),
                        strokeWidth = 1.2.dp.toPx()
                    )
                }

                // 6 Vertical Strings (0 = Low E ... 5 = High e)
                for (s in 0..5) {
                    val x = startX + s * stringSpacing
                    drawLine(
                        color = Color(0xFF64748B),
                        start = Offset(x, topY),
                        end = Offset(x, topY + boxHeight),
                        strokeWidth = if (s == 0) 2.dp.toPx() else 1.2.dp.toPx()
                    )

                    // String header marks: X (mute) or O (open) above nut
                    val fret = chord.guitarFrets.getOrNull(s)
                    if (fret == -1) {
                        // 'X'
                        drawText(
                            textMeasurer = textMeasurer,
                            text = "X",
                            topLeft = Offset(x - 4.dp.toPx(), topY - 20.dp.toPx()),
                            style = TextStyle(color = Color(0xFFEF4444), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        )
                    } else if (fret == 0) {
                        // 'O'
                        drawText(
                            textMeasurer = textMeasurer,
                            text = "O",
                            topLeft = Offset(x - 4.dp.toPx(), topY - 20.dp.toPx()),
                            style = TextStyle(color = EmeraldTune, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        )
                    }
                }

                // Barre Chord Bracket / Bar
                chord.barreFret?.let { bFret ->
                    val relativeFret = bFret - chord.baseFret + 1
                    if (relativeFret in 1..4) {
                        val barreY = topY + (relativeFret - 0.5f) * fretSpacing
                        drawRoundRect(
                            color = GuitarColor.copy(alpha = 0.85f),
                            topLeft = Offset(startX - 2.dp.toPx(), barreY - 5.dp.toPx()),
                            size = Size(boxWidth + 4.dp.toPx(), 10.dp.toPx()),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(5.dp.toPx(), 5.dp.toPx())
                        )
                    }
                }

                // Finger dots on the fretboard
                for (s in 0..5) {
                    val fret = chord.guitarFrets.getOrNull(s) ?: continue
                    if (fret > 0) {
                        val relativeFret = fret - chord.baseFret + 1
                        if (relativeFret in 1..4) {
                            val dotX = startX + s * stringSpacing
                            val dotY = topY + (relativeFret - 0.5f) * fretSpacing
                            val finger = chord.fingerNumbers.getOrNull(s)

                            // Finger dot circle
                            drawCircle(
                                color = if (s == 1 || s == 0) CyanAccent else GuitarColor,
                                radius = 7.dp.toPx(),
                                center = Offset(dotX, dotY)
                            )

                            // Finger number text inside dot
                            if (finger != null) {
                                drawText(
                                    textMeasurer = textMeasurer,
                                    text = "$finger",
                                    topLeft = Offset(dotX - 3.5.dp.toPx(), dotY - 6.dp.toPx()),
                                    style = TextStyle(color = Color(0xFF090D16), fontSize = 9.sp, fontWeight = FontWeight.Black)
                                )
                            }
                        }
                    }
                }
            }

            // String notes label below
            Row(
                modifier = Modifier.width(130.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                listOf("E", "A", "D", "G", "B", "e").forEach { str ->
                    Text(text = str, color = TextSecondary, fontSize = 9.sp)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Mini Piano Keyboard Diagram
            MiniPianoChordView(midiKeys = chord.pianoMidis)

            Spacer(modifier = Modifier.height(10.dp))

            // Audition Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onPlayGuitarStrum() },
                    color = GuitarColor.copy(alpha = 0.18f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GuitarColor.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(imageVector = Icons.Default.VolumeUp, contentDescription = null, tint = GuitarColor, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Strum Guitar", color = GuitarColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onPlayPianoChord() },
                    color = PianoColor.copy(alpha = 0.18f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, PianoColor.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = PianoColor, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Piano Voicing", color = PianoColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

/**
 * 1-Octave Mini Piano Chord Diagram highlighting the chord keys.
 */
@Composable
fun MiniPianoChordView(midiKeys: List<Int>) {
    val whiteNotes = listOf("C", "D", "E", "F", "G", "A", "B")
    val whiteMidiOffsets = listOf(0, 2, 4, 5, 7, 9, 11)
    val blackMidiOffsets = mapOf(0 to 1, 1 to 3, 3 to 6, 4 to 8, 5 to 10) // C#, D#, F#, G#, A#

    // Normalize keys into pitch class 0..11
    val pitchClasses = midiKeys.map { it % 12 }

    Box(
        modifier = Modifier
            .width(130.dp)
            .height(44.dp)
            .background(Color(0xFF0F172A), RoundedCornerShape(6.dp))
            .border(1.dp, Color(0xFF334155), RoundedCornerShape(6.dp))
            .padding(2.dp)
    ) {
        val wKeyWidth = (126.dp / 7f)
        val bKeyWidth = wKeyWidth * 0.65f
        val bKeyHeight = 24.dp

        // White Keys
        Row {
            whiteMidiOffsets.forEach { semitone ->
                val isPressed = pitchClasses.contains(semitone)
                Box(
                    modifier = Modifier
                        .width(wKeyWidth)
                        .height(40.dp)
                        .background(
                            if (isPressed) CyanAccent else Color.White,
                            RoundedCornerShape(bottomStart = 2.dp, bottomEnd = 2.dp)
                        )
                        .border(0.5.dp, Color(0xFF64748B), RoundedCornerShape(bottomStart = 2.dp, bottomEnd = 2.dp))
                )
            }
        }

        // Black Keys
        blackMidiOffsets.forEach { (wIdx, semitone) ->
            val isPressed = pitchClasses.contains(semitone)
            val leftOffset = (wIdx * 18).dp + 12.dp
            Box(
                modifier = Modifier
                    .padding(start = leftOffset)
                    .width(bKeyWidth)
                    .height(bKeyHeight)
                    .background(
                        if (isPressed) VioletAccent else Color(0xFF0F172A),
                        RoundedCornerShape(bottomStart = 2.dp, bottomEnd = 2.dp)
                    )
                    .border(0.5.dp, Color(0xFF334155), RoundedCornerShape(bottomStart = 2.dp, bottomEnd = 2.dp))
            )
        }
    }
}
