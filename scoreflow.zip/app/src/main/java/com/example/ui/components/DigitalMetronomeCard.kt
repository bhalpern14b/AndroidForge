package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.BpmDetector
import com.example.audio.DigitalMetronome
import com.example.model.MetronomeConfig
import com.example.model.MetronomeSoundType
import com.example.model.MetronomeSubdivision
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.EmeraldTune
import com.example.ui.theme.GuitarColor
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletAccent
import kotlin.math.cos
import kotlin.math.sin

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DigitalMetronomeCard(
    metronome: DigitalMetronome,
    config: MetronomeConfig,
    onBpmChanged: (Int) -> Unit = {},
    modifier: Modifier = Modifier
) {
    var showAdvancedSettings by remember { mutableStateOf(false) }

    // Tap tempo feedback animation
    var tapCounter by remember { mutableStateOf(0) }
    var lastTapLabel by remember { mutableStateOf<String?>(null) }

    // Pendulum arm animation angle (-28 to +28 degrees)
    val pendulumAngle = remember { Animatable(0f) }
    LaunchedEffect(config.isRunning, config.bpm) {
        if (config.isRunning) {
            val beatPeriodMs = (60000 / config.bpm).toInt()
            pendulumAngle.animateTo(
                targetValue = 26f,
                animationSpec = infiniteRepeatable(
                    animation = tween(beatPeriodMs / 2, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                )
            )
        } else {
            pendulumAngle.snapTo(0f)
        }
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = StudioSurface),
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(
            width = if (config.isRunning) 1.5.dp else 1.dp,
            color = if (config.isRunning) CyanAccent else Color(0xFF334155)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header with Play/Stop status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(
                                if (config.isRunning) CyanAccent.copy(alpha = 0.2f) else StudioSurfaceVariant,
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = "Metronome",
                            tint = if (config.isRunning) CyanAccent else TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Configurable Metronome",
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${BpmDetector.getTempoMarking(config.bpm)} • ${config.beatsPerBar}/4 Time",
                            color = if (config.isRunning) CyanAccent else TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // Play / Pause Master Button
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { metronome.toggle() },
                    color = if (config.isRunning) Color(0xFFEF4444) else CyanAccent
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (config.isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (config.isRunning) "Stop" else "Start",
                            tint = if (config.isRunning) Color.White else Color(0xFF090D16),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (config.isRunning) "STOP" else "START",
                            color = if (config.isRunning) Color.White else Color(0xFF090D16),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Main Display Area: Pendulum + Big BPM Indicator + Beat Dots
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF090D16))
                    .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(16.dp))
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Interactive Visual Pendulum Needle
                Box(
                    modifier = Modifier
                        .size(68.dp, 80.dp),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    Canvas(modifier = Modifier.fillMaxWidth().height(80.dp)) {
                        val pivot = Offset(size.width / 2f, size.height - 8.dp.toPx())
                        val length = size.height - 18.dp.toPx()
                        val rad = Math.toRadians((pendulumAngle.value).toDouble()).toFloat()

                        val endX = pivot.x + length * sin(rad)
                        val endY = pivot.y - length * cos(rad)

                        // Track line arc background
                        drawLine(
                            color = Color(0xFF1E293B),
                            start = Offset(pivot.x - 22.dp.toPx(), 14.dp.toPx()),
                            end = Offset(pivot.x + 22.dp.toPx(), 14.dp.toPx()),
                            strokeWidth = 2.dp.toPx(),
                            cap = StrokeCap.Round
                        )

                        // Pendulum stick
                        drawLine(
                            color = if (config.isRunning) CyanAccent else TextSecondary,
                            start = pivot,
                            end = Offset(endX, endY),
                            strokeWidth = 3.dp.toPx(),
                            cap = StrokeCap.Round
                        )

                        // Weight / Bob
                        val weightOffset = Offset(
                            pivot.x + (length * 0.65f) * sin(rad),
                            pivot.y - (length * 0.65f) * cos(rad)
                        )
                        drawCircle(
                            color = if (config.isRunning) VioletAccent else Color(0xFF475569),
                            radius = 6.dp.toPx(),
                            center = weightOffset
                        )

                        // Pivot point
                        drawCircle(
                            color = Color(0xFF334155),
                            radius = 4.dp.toPx(),
                            center = pivot
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Big BPM Numbers & Increment / Decrement
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        IconButton(
                            onClick = {
                                metronome.adjustBpm(-1)
                                onBpmChanged(config.bpm - 1)
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.Remove, contentDescription = "-1", tint = TextPrimary)
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${config.bpm}",
                                color = TextPrimary,
                                fontSize = 34.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "BPM",
                                color = CyanAccent,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        IconButton(
                            onClick = {
                                metronome.adjustBpm(1)
                                onBpmChanged(config.bpm + 1)
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "+1", tint = TextPrimary)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Beat Dot Indicators (e.g. 1 2 3 4)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (beat in 1..config.beatsPerBar) {
                            val isCurrentBeat = config.isRunning && config.currentBeat == beat
                            val isAccentBeat = beat == 1 && config.isAccentFirstBeat

                            val dotColor by animateColorAsState(
                                targetValue = when {
                                    isCurrentBeat && isAccentBeat -> Color(0xFFEF4444) // Red accent on beat 1
                                    isCurrentBeat -> CyanAccent                         // Bright cyan on subdivisions
                                    isAccentBeat -> Color(0xFFEF4444).copy(alpha = 0.35f)
                                    else -> Color(0xFF334155)
                                },
                                label = "dotColor"
                            )

                            Box(
                                modifier = Modifier
                                    .size(if (isCurrentBeat) 16.dp else 12.dp)
                                    .background(dotColor, CircleShape)
                                    .border(
                                        width = 1.dp,
                                        color = if (isCurrentBeat) Color.White else Color.Transparent,
                                        shape = CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isCurrentBeat) {
                                    Text(
                                        text = "$beat",
                                        color = Color.Black,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Tap Tempo Button
                Surface(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .clickable {
                            val newBpm = metronome.tapTempo()
                            onBpmChanged(newBpm)
                            tapCounter++
                            lastTapLabel = "$newBpm"
                        },
                    color = VioletAccent.copy(alpha = 0.2f),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, VioletAccent.copy(alpha = 0.7f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.TouchApp,
                            contentDescription = "Tap",
                            tint = VioletAccent,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "TAP",
                            color = VioletAccent,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "TEMPO",
                            color = TextSecondary,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Fast Slider for Tempo Adjustment (30 to 250 BPM)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "40", color = TextSecondary, fontSize = 10.sp)
                Spacer(modifier = Modifier.width(6.dp))
                Slider(
                    value = config.bpm.toFloat(),
                    onValueChange = {
                        val bpmVal = it.toInt()
                        metronome.setBpm(bpmVal)
                        onBpmChanged(bpmVal)
                    },
                    valueRange = 40f..240f,
                    steps = 199,
                    modifier = Modifier.weight(1f),
                    colors = SliderDefaults.colors(
                        thumbColor = CyanAccent,
                        activeTrackColor = CyanAccent,
                        inactiveTrackColor = Color(0xFF1E293B)
                    )
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "240", color = TextSecondary, fontSize = 10.sp)
            }

            // Quick Tempo Presets (-5, -1, +1, +5, common presets 60, 90, 120, 140)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    Pair("-5", -5),
                    Pair("+5", 5),
                    Pair("60", 60),
                    Pair("80", 80),
                    Pair("100", 100),
                    Pair("120", 120),
                    Pair("140", 140),
                    Pair("160", 160)
                ).forEach { (label, value) ->
                    val isDelta = label.startsWith("-") || label.startsWith("+")
                    val isCurrentPreset = !isDelta && config.bpm == value

                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable {
                                if (isDelta) {
                                    metronome.adjustBpm(value)
                                    onBpmChanged(config.bpm + value)
                                } else {
                                    metronome.setBpm(value)
                                    onBpmChanged(value)
                                }
                            },
                        color = if (isCurrentPreset) CyanAccent else StudioSurfaceVariant,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = label,
                            color = if (isCurrentPreset) Color(0xFF090D16) else TextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Time Signature & Sound Type Selectors
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Time Signature (2/4, 3/4, 4/4, 6/8)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Time:",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    listOf(2, 3, 4, 6).forEach { beats ->
                        val isSelected = config.beatsPerBar == beats
                        Surface(
                            modifier = Modifier
                                .padding(end = 4.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .clickable { metronome.setBeatsPerBar(beats) },
                            color = if (isSelected) EmeraldTune else StudioSurfaceVariant,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = if (beats == 6) "6/8" else "$beats/4",
                                color = if (isSelected) Color(0xFF090D16) else TextPrimary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                // Sound Selector & Toggle Controls
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Mute / Sound Toggle
                    IconButton(
                        onClick = { metronome.toggleMute() },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (config.isMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                            contentDescription = "Mute",
                            tint = if (config.isMuted) Color(0xFFEF4444) else CyanAccent,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Accent Beat 1 Toggle
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable { metronome.toggleAccentFirstBeat() },
                        color = if (config.isAccentFirstBeat) Color(0xFFEF4444).copy(alpha = 0.2f) else StudioSurfaceVariant,
                        border = if (config.isAccentFirstBeat) androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEF4444)) else null,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (config.isAccentFirstBeat) "ACCENT 1" else "NO ACCENT",
                                color = if (config.isAccentFirstBeat) Color(0xFFEF4444) else TextSecondary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Sound Timber / Instrument selector
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "Sound:", color = TextSecondary, fontSize = 11.sp)
                MetronomeSoundType.values().forEach { sound ->
                    val isSelected = config.soundType == sound
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { metronome.setSoundType(sound) },
                        color = if (isSelected) VioletAccent else StudioSurfaceVariant,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = sound.displayName,
                            color = if (isSelected) Color.White else TextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Subdivisions (1/4, 1/8, 1/8T, 1/16)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "Subdiv:", color = TextSecondary, fontSize = 11.sp)
                MetronomeSubdivision.values().forEach { sub ->
                    val isSelected = config.subdivision == sub
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { metronome.setSubdivision(sub) },
                        color = if (isSelected) GuitarColor else StudioSurfaceVariant,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = sub.displayName,
                            color = if (isSelected) Color(0xFF090D16) else TextPrimary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}
