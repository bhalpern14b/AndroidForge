package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_scores")
data class ScoreEntity(
    @PrimaryKey val id: String,
    val title: String,
    val artist: String,
    val bpm: Int,
    val keySignature: String,
    val timeSignature: String,
    val isBeginnerMode: Boolean,
    val isCloudSynced: Boolean,
    val cloudProjectId: String?,
    val timestamp: Long = System.currentTimeMillis()
)
