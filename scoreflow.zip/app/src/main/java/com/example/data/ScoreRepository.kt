package com.example.data

import com.example.model.CloudProject
import com.example.model.Collaborator
import com.example.model.CommentItem
import com.example.model.SongScore
import com.example.transcription.TranscriptionEngine
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class ScoreRepository(private val scoreDao: ScoreDao) {

    val savedScores: Flow<List<ScoreEntity>> = scoreDao.getAllScores()

    // In-memory active cloud projects with rich collaborative data
    private val _cloudProjects = MutableStateFlow<List<CloudProject>>(emptyList())
    val cloudProjects: StateFlow<List<CloudProject>> = _cloudProjects.asStateFlow()

    init {
        // Pre-populate realistic cloud projects with multi-musician collaboration
        val project1Score = TranscriptionEngine.getPreloadedDemoScore(0)
        val project2Score = TranscriptionEngine.getPreloadedDemoScore(1)
        val project3Score = TranscriptionEngine.getPreloadedDemoScore(2)

        _cloudProjects.value = listOf(
            CloudProject(
                id = "proj-1",
                title = "Moonlight Acoustic Harmony",
                genre = "Acoustic Pop / Ballad",
                ownerName = "Alex Rivera (Lead Vocals)",
                lastUpdated = "10 mins ago",
                bpm = 108,
                versionsCount = 4,
                collaborators = listOf(
                    Collaborator("u1", "Alex Rivera", "Vocals & Songwriter", 0xFF06B6D4),
                    Collaborator("u2", "Elena Rostova", "Violin Soloist", 0xFF8B5CF6),
                    Collaborator("u3", "Marcus Vance", "Arranger / Bass", 0xFF10B981)
                ),
                comments = listOf(
                    CommentItem("c1", "Elena Rostova", "The transition in Measure 3 feels lovely with the violin countermelody!", "0:09", 3, "25m ago"),
                    CommentItem("c2", "Marcus Vance", "Added a walking bassline in Measure 2 on the G chord.", "0:04", 2, "1h ago"),
                    CommentItem("c3", "Alex Rivera", "Love this! Let's export the lead sheet for guitar practice.", "0:12", 4, "2h ago")
                ),
                score = project1Score
            ),
            CloudProject(
                id = "proj-2",
                title = "Autumn Leaves Vocal Ballad",
                genre = "Jazz / Neo-Soul",
                ownerName = "Sarah Chen (Piano)",
                lastUpdated = "2 hours ago",
                bpm = 92,
                versionsCount = 2,
                collaborators = listOf(
                    Collaborator("u4", "Sarah Chen", "Piano & Producer", 0xFFF59E0B),
                    Collaborator("u5", "Leo Kim", "Guitarist", 0xFFEC4899)
                ),
                comments = listOf(
                    CommentItem("c4", "Leo Kim", "Try using an Em9 instead of regular Em for more color in measure 4.", "0:15", 4, "3h ago")
                ),
                score = project2Score
            ),
            CloudProject(
                id = "proj-3",
                title = "Neon Skyline Rock Arrangement",
                genre = "Indie Rock / Anthem",
                ownerName = "David Hall (Drums)",
                lastUpdated = "Yesterday",
                bpm = 132,
                versionsCount = 5,
                collaborators = listOf(
                    Collaborator("u6", "David Hall", "Drummer & Mix Engineer", 0xFFF43F5E),
                    Collaborator("u7", "Zoe Taylor", "Bassist", 0xFF3B82F6)
                ),
                comments = listOf(
                    CommentItem("c5", "Zoe Taylor", "Tightened up the drum fill heading into bar 3.", "0:08", 2, "1d ago")
                ),
                score = project3Score
            )
        )
    }

    suspend fun saveScore(score: SongScore) {
        val entity = ScoreEntity(
            id = score.id,
            title = score.title,
            artist = score.artist,
            bpm = score.bpm,
            keySignature = score.keySignature,
            timeSignature = "${score.timeSignatureNumerator}/${score.timeSignatureDenominator}",
            isBeginnerMode = score.isBeginnerMode,
            isCloudSynced = score.isCloudSynced,
            cloudProjectId = score.cloudProjectId
        )
        scoreDao.insertScore(entity)
    }

    fun addCommentToProject(projectId: String, author: String, text: String, timecode: String, measure: Int) {
        val current = _cloudProjects.value.toMutableList()
        val index = current.indexOfFirst { it.id == projectId }
        if (index != -1) {
            val proj = current[index]
            val newComment = CommentItem(
                id = UUID.randomUUID().toString(),
                author = author,
                text = text,
                timecodeFormatted = timecode,
                measureTarget = measure,
                timestamp = "Just now"
            )
            val updated = proj.copy(comments = listOf(newComment) + proj.comments)
            current[index] = updated
            _cloudProjects.value = current
        }
    }

    fun addCloudProject(score: SongScore, genre: String = "Custom Transcription"): CloudProject {
        val newProj = CloudProject(
            id = "proj-" + UUID.randomUUID().toString().take(6),
            title = score.title,
            genre = genre,
            ownerName = "You (Bandleader)",
            lastUpdated = "Just now",
            bpm = score.bpm,
            collaborators = listOf(
                Collaborator("u-me", "You", "Arranger / Transcriber", 0xFF06B6D4)
            ),
            comments = emptyList(),
            score = score
        )
        _cloudProjects.value = listOf(newProj) + _cloudProjects.value
        return newProj
    }
}
