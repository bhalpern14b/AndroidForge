package com.example.model

enum class MetronomeSoundType(val displayName: String) {
    WOODBLOCK("Woodblock"),
    DIGITAL_BEEP("Digital Beep"),
    CLICK("Classic Click"),
    COWBELL("Cowbell")
}

enum class MetronomeSubdivision(val displayName: String, val multiplier: Int) {
    QUARTER("Quarter Notes (1/4)", 1),
    EIGHTH("Eighth Notes (1/8)", 2),
    TRIPLET("Triplets (1/8T)", 3),
    SIXTEENTH("Sixteenth Notes (1/16)", 4)
}

data class MetronomeConfig(
    val isRunning: Boolean = false,
    val bpm: Int = 120,
    val beatsPerBar: Int = 4, // 2/4, 3/4, 4/4, 6/8
    val currentBeat: Int = 1, // 1..beatsPerBar
    val isAccentFirstBeat: Boolean = true,
    val soundType: MetronomeSoundType = MetronomeSoundType.WOODBLOCK,
    val subdivision: MetronomeSubdivision = MetronomeSubdivision.QUARTER,
    val volume: Float = 0.85f,
    val isMuted: Boolean = false,
    val isVisualFlashOnly: Boolean = false
)

data class LiveAudioBpmState(
    val detectedBpm: Int = 0,
    val confidencePercent: Int = 0,
    val tempoLabel: String = "Standby",
    val isBeatFlashing: Boolean = false,
    val energyFlux: Float = 0f
)
