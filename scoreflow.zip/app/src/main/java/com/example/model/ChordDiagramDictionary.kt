package com.example.model

data class ChordDiagramInfo(
    val chordName: String,
    val rootNote: String,
    val quality: String, // Major, Minor, 7th, maj7, min7, sus4, add9
    val guitarFrets: List<Int?>, // 6 strings: Low E (6), A (5), D (4), G (3), B (2), High e (1). -1=mute, 0=open
    val fingerNumbers: List<Int?>, // 1=index, 2=middle, 3=ring, 4=pinky, null=open/mute
    val baseFret: Int = 1, // 1=nut, >1=fret offset
    val barreFret: Int? = null,
    val pianoMidis: List<Int>,
    val chordFormula: String,
    val notesInChord: List<String>,
    val playingTip: String
)

object ChordDiagramDictionary {

    val ALL_CHORDS: Map<String, ChordDiagramInfo> = mapOf(
        // C Major
        "C" to ChordDiagramInfo(
            chordName = "C",
            rootNote = "C",
            quality = "Major",
            guitarFrets = listOf(-1, 3, 2, 0, 1, 0),
            fingerNumbers = listOf(null, 3, 2, null, 1, null),
            pianoMidis = listOf(60, 64, 67),
            chordFormula = "1 - 3 - 5 (Root - Major 3rd - Perfect 5th)",
            notesInChord = listOf("C", "E", "G"),
            playingTip = "Mute the low E string with the tip of your 3rd finger. Arch fingers so the open G and high E ring clearly."
        ),
        // G Major
        "G" to ChordDiagramInfo(
            chordName = "G",
            rootNote = "G",
            quality = "Major",
            guitarFrets = listOf(3, 2, 0, 0, 0, 3),
            fingerNumbers = listOf(3, 2, null, null, null, 4),
            pianoMidis = listOf(55, 59, 62),
            chordFormula = "1 - 3 - 5 (G - B - D)",
            notesInChord = listOf("G", "B", "D"),
            playingTip = "Use your pinky (4) on the high E string and ring finger (3) on low E for easy transitions to C and Em."
        ),
        // A Minor
        "Am" to ChordDiagramInfo(
            chordName = "Am",
            rootNote = "A",
            quality = "Minor",
            guitarFrets = listOf(-1, 0, 2, 2, 1, 0),
            fingerNumbers = listOf(null, null, 2, 3, 1, null),
            pianoMidis = listOf(57, 60, 64),
            chordFormula = "1 - b3 - 5 (A - C - E)",
            notesInChord = listOf("A", "C", "E"),
            playingTip = "Strum from the open 5th string (A). Finger shape is identical to E Major shifted down one string."
        ),
        // F Major
        "F" to ChordDiagramInfo(
            chordName = "F",
            rootNote = "F",
            quality = "Major",
            guitarFrets = listOf(1, 3, 3, 2, 1, 1),
            fingerNumbers = listOf(1, 3, 4, 2, 1, 1),
            baseFret = 1,
            barreFret = 1,
            pianoMidis = listOf(53, 57, 60),
            chordFormula = "1 - 3 - 5 (F - A - C)",
            notesInChord = listOf("F", "A", "C"),
            playingTip = "Full barre chord on 1st fret. Keep index finger straight and close to the fret wire for clean tone."
        ),
        // D Major
        "D" to ChordDiagramInfo(
            chordName = "D",
            rootNote = "D",
            quality = "Major",
            guitarFrets = listOf(-1, -1, 0, 2, 3, 2),
            fingerNumbers = listOf(null, null, null, 1, 3, 2),
            pianoMidis = listOf(62, 66, 69),
            chordFormula = "1 - 3 - 5 (D - F# - A)",
            notesInChord = listOf("D", "F#", "A"),
            playingTip = "Only strum top 4 strings starting from open D (4th string). Keep index and middle fingers arched."
        ),
        // D Minor
        "Dm" to ChordDiagramInfo(
            chordName = "Dm",
            rootNote = "D",
            quality = "Minor",
            guitarFrets = listOf(-1, -1, 0, 2, 3, 1),
            fingerNumbers = listOf(null, null, null, 2, 3, 1),
            pianoMidis = listOf(62, 65, 69),
            chordFormula = "1 - b3 - 5 (D - F - A)",
            notesInChord = listOf("D", "F", "A"),
            playingTip = "Place index finger right on the 1st fret of high E. Strum 4th string downward."
        ),
        // E Minor
        "Em" to ChordDiagramInfo(
            chordName = "Em",
            rootNote = "E",
            quality = "Minor",
            guitarFrets = listOf(0, 2, 2, 0, 0, 0),
            fingerNumbers = listOf(null, 2, 3, null, null, null),
            pianoMidis = listOf(52, 55, 59),
            chordFormula = "1 - b3 - 5 (E - G - B)",
            notesInChord = listOf("E", "G", "B"),
            playingTip = "One of the easiest chords: all 6 strings ring open except 5th and 4th strings pressed with fingers 2 & 3."
        ),
        // E Major
        "E" to ChordDiagramInfo(
            chordName = "E",
            rootNote = "E",
            quality = "Major",
            guitarFrets = listOf(0, 2, 2, 1, 0, 0),
            fingerNumbers = listOf(null, 2, 3, 1, null, null),
            pianoMidis = listOf(52, 56, 59),
            chordFormula = "1 - 3 - 5 (E - G# - B)",
            notesInChord = listOf("E", "G#", "B"),
            playingTip = "Strum all 6 strings with full force. Index finger sits on 1st fret of G string."
        ),
        // A Major
        "A" to ChordDiagramInfo(
            chordName = "A",
            rootNote = "A",
            quality = "Major",
            guitarFrets = listOf(-1, 0, 2, 2, 2, 0),
            fingerNumbers = listOf(null, null, 1, 2, 3, null),
            pianoMidis = listOf(57, 61, 64),
            chordFormula = "1 - 3 - 5 (A - C# - E)",
            notesInChord = listOf("A", "C#", "E"),
            playingTip = "Squeeze fingers 1, 2, and 3 closely together inside the 2nd fret, or use an index finger mini-barre."
        ),
        // B Minor (Bm)
        "Bm" to ChordDiagramInfo(
            chordName = "Bm",
            rootNote = "B",
            quality = "Minor",
            guitarFrets = listOf(-1, 2, 4, 4, 3, 2),
            fingerNumbers = listOf(null, 1, 3, 4, 2, 1),
            baseFret = 2,
            barreFret = 2,
            pianoMidis = listOf(59, 62, 66),
            chordFormula = "1 - b3 - 5 (B - D - F#)",
            notesInChord = listOf("B", "D", "F#"),
            playingTip = "Barre 5 strings at the 2nd fret. Your 3rd and 4th fingers form an Am shape on the 4th fret."
        ),
        // G7
        "G7" to ChordDiagramInfo(
            chordName = "G7",
            rootNote = "G",
            quality = "7th",
            guitarFrets = listOf(3, 2, 0, 0, 0, 1),
            fingerNumbers = listOf(3, 2, null, null, null, 1),
            pianoMidis = listOf(55, 59, 62, 65),
            chordFormula = "1 - 3 - 5 - b7 (G - B - D - F)",
            notesInChord = listOf("G", "B", "D", "F"),
            playingTip = "Dominant 7th chord. Stretch index finger to 1st fret of high E while ring finger anchors low E."
        ),
        // Cmaj7
        "Cmaj7" to ChordDiagramInfo(
            chordName = "Cmaj7",
            rootNote = "C",
            quality = "maj7",
            guitarFrets = listOf(-1, 3, 2, 0, 0, 0),
            fingerNumbers = listOf(null, 3, 2, null, null, null),
            pianoMidis = listOf(60, 64, 67, 71),
            chordFormula = "1 - 3 - 5 - 7 (C - E - G - B)",
            notesInChord = listOf("C", "E", "G", "B"),
            playingTip = "Dreamy jazz voicing. Simply take your index finger off regular C Major to let open B ring."
        ),
        // Cadd9
        "Cadd9" to ChordDiagramInfo(
            chordName = "Cadd9",
            rootNote = "C",
            quality = "add9",
            guitarFrets = listOf(-1, 3, 2, 0, 3, 0),
            fingerNumbers = listOf(null, 2, 1, null, 3, null),
            pianoMidis = listOf(60, 62, 64, 67),
            chordFormula = "1 - 3 - 5 - 9 (C - E - G - D)",
            notesInChord = listOf("C", "E", "G", "D"),
            playingTip = "Very popular modern acoustic pop chord. Keep ring finger locked on 3rd fret of B string."
        ),
        // Fmaj7
        "Fmaj7" to ChordDiagramInfo(
            chordName = "Fmaj7",
            rootNote = "F",
            quality = "maj7",
            guitarFrets = listOf(-1, -1, 3, 2, 1, 0),
            fingerNumbers = listOf(null, null, 3, 2, 1, null),
            pianoMidis = listOf(53, 57, 60, 64),
            chordFormula = "1 - 3 - 5 - 7 (F - A - C - E)",
            notesInChord = listOf("F", "A", "C", "E"),
            playingTip = "Beginner-friendly F shape without needing a barre! Let the high E string ring completely open."
        ),
        // Dsus4
        "Dsus4" to ChordDiagramInfo(
            chordName = "Dsus4",
            rootNote = "D",
            quality = "sus4",
            guitarFrets = listOf(-1, -1, 0, 2, 3, 3),
            fingerNumbers = listOf(null, null, null, 1, 2, 4),
            pianoMidis = listOf(62, 67, 69),
            chordFormula = "1 - 4 - 5 (D - G - A)",
            notesInChord = listOf("D", "G", "A"),
            playingTip = "Add your pinky on 3rd fret of high E while holding regular D Major."
        )
    )

    fun getChord(name: String): ChordDiagramInfo {
        // Clean up input name (e.g. "C (I)" -> "C", "Am/C" -> "Am")
        val clean = name.substringBefore("(").substringBefore("/").trim()
        return ALL_CHORDS[clean] ?: ALL_CHORDS["C"]!!
    }
}
