package com.example.model

enum class NoteDuration(val beats: Float, val label: String) {
    WHOLE(4.0f, "Whole"),
    HALF(2.0f, "Half"),
    DOTTED_HALF(3.0f, "Dotted Half"),
    QUARTER(1.0f, "Quarter"),
    DOTTED_QUARTER(1.5f, "Dotted Quarter"),
    EIGHTH(0.5f, "Eighth"),
    SIXTEENTH(0.25f, "Sixteenth")
}

enum class Accidental {
    NONE, SHARP, FLAT, NATURAL
}

enum class VocalOrnament {
    NONE,
    VIBRATO,         // Wavy oscillation line ~~~
    SCOOP,           // Rising slide into note ⤴
    FALL,            // Falling slide off note ⤵
    GLISSANDO,       // Continuous slide between notes
    GRACE_NOTE,      // Quick micro-note ornament
    BEND_UP,         // Pitch bend up
    BEND_DOWN,       // Pitch bend down
    MELISMA          // Single syllable spread across multiple pitches
}

enum class DynamicMarking(val symbol: String, val label: String) {
    PP("pp", "Pianissimo"),
    P("p", "Piano"),
    MP("mp", "Mezzo-Piano"),
    MF("mf", "Mezzo-Forte"),
    F("f", "Forte"),
    FF("ff", "Fortissimo"),
    CRESCENDO("<", "Crescendo"),
    DECRESCENDO(">", "Decrescendo")
}

data class VocalNuance(
    val ornament: VocalOrnament = VocalOrnament.NONE,
    val vibratoRateHz: Float = 5.2f,       // Typical expressive vocal vibrato 4.5-6.5 Hz
    val vibratoDepthCents: Float = 16.0f,   // Microtonal excursion (+/- cents)
    val pitchBendCents: Float = 0.0f,      // Microtonal pitch bend (-100 to +100 cents)
    val glissandoTargetMidi: Int? = null,  // Target note for portamento/glissando
    val dynamicMarking: DynamicMarking = DynamicMarking.MF,
    val breathMarkBefore: Boolean = false,
    val expressionLabel: String? = null    // e.g. "legato", "espr.", "portamento"
)

data class MusicalNote(
    val pitchName: String, // e.g. "C4", "G#4", "REST"
    val midiNote: Int = 60, // 60 = C4
    val frequencyHz: Float = 261.63f,
    val duration: NoteDuration = NoteDuration.QUARTER,
    val startBeat: Float = 0f,
    val velocity: Int = 85,
    val isRest: Boolean = false,
    val stringNumber: Int = 1, // Guitar string 1-6 (1 = high E)
    val fretNumber: Int = 0,    // Guitar fret 0-24
    val fingerHint: Int? = null, // 1=index, 2=middle, 3=ring, 4=pinky
    val accidental: Accidental = Accidental.NONE,
    val lyricSyllable: String? = null,
    val vocalBendCents: Float = 0f, // microtonal nuance
    val vocalNuance: VocalNuance? = null
)

data class ChordNotation(
    val chordName: String, // e.g. "C", "Am", "G7", "Fmaj7", "Em"
    val rootNote: String = "C",
    val quality: String = "Major", // Major, Minor, 7th, maj7, min7, dim, sus4
    val startBeat: Float = 0f,
    val durationBeats: Float = 4.0f,
    val guitarFrets: List<Int?> = listOf(-1, 3, 2, 0, 1, 0), // e.g. C major x-3-2-0-1-0 (-1 is mute)
    val pianoMidiKeys: List<Int> = listOf(60, 64, 67), // C4, E4, G4
    val romanNumeral: String = "I",
    val bassNote: String? = null,
    val theoryExplanation: String? = null // For Beginner Practice Mode
)

data class Measure(
    val measureNumber: Int,
    val notes: List<MusicalNote> = emptyList(),
    val chord: ChordNotation? = null,
    val dynamicMarking: DynamicMarking? = null
)

enum class InstrumentType(
    val displayName: String,
    val defaultClef: ClefType,
    val iconName: String,
    val isPercussion: Boolean = false
) {
    PIANO("Piano", ClefType.GRAND_STAFF, "piano"),
    GUITAR("Acoustic Guitar", ClefType.TREBLE, "guitar"),
    BASS("Electric Bass", ClefType.BASS, "bass"),
    DRUMS("Drum Kit", ClefType.PERCUSSION, "drums", isPercussion = true),
    VIOLIN("Violin", ClefType.TREBLE, "violin"),
    VOCALS("Lead Vocals", ClefType.TREBLE, "mic")
}

enum class ClefType {
    TREBLE, BASS, GRAND_STAFF, PERCUSSION
}

data class InstrumentTrack(
    val trackId: String,
    val instrument: InstrumentType,
    val name: String,
    val clef: ClefType = instrument.defaultClef,
    val measures: List<Measure> = emptyList(),
    val volume: Float = 0.8f,
    val isMuted: Boolean = false,
    val isSolo: Boolean = false,
    val pan: Float = 0.0f
)

data class SongScore(
    val id: String,
    val title: String,
    val artist: String = "Harmoniq Studio",
    val keySignature: String = "C Major",
    val timeSignatureNumerator: Int = 4,
    val timeSignatureDenominator: Int = 4,
    val bpm: Int = 120,
    val tracks: List<InstrumentTrack> = emptyList(),
    val chords: List<ChordNotation> = emptyList(),
    val audioDurationMs: Long = 16000L,
    val isBeginnerMode: Boolean = false,
    val isCloudSynced: Boolean = true,
    val cloudProjectId: String? = null,
    val scaleName: String = "C Major (Ionian)",
    val scaleNotes: List<String> = listOf("C", "D", "E", "F", "G", "A", "B")
) {
    val totalBeats: Float
        get() {
            val maxMeasure = tracks.maxOfOrNull { it.measures.size } ?: 4
            return maxMeasure * timeSignatureNumerator.toFloat()
        }
}

data class TunerState(
    val detectedNote: String = "--",
    val octave: Int = 4,
    val targetFrequencyHz: Float = 440.0f,
    val detectedFrequencyHz: Float = 0.0f,
    val centsDeviation: Float = 0.0f, // -50 to +50
    val isInTune: Boolean = false,
    val signalStrengthDb: Float = -60.0f,
    val pitchStabilityPercent: Int = 85,
    val vibratoRateHz: Float = 5.2f, // vocal vibrato rate
    val vibratoDepthCents: Float = 14.0f, // vocal vibrato depth
    val activeOrnament: VocalOrnament = VocalOrnament.NONE,
    val dynamicMarking: DynamicMarking = DynamicMarking.MF,
    val pitchContourHistory: List<Float> = emptyList(), // real-time pitch points for nuance display
    val isListening: Boolean = false
)

data class AudioPitchFrame(
    val timestampMs: Long,
    val frequencyHz: Float,
    val noteName: String,
    val midiPitch: Int,
    val cents: Float,
    val amplitudeDb: Float,
    val isInTune: Boolean,
    val vibratoDetected: Boolean = false,
    val pitchBendDetected: Boolean = false
)

data class Collaborator(
    val id: String,
    val name: String,
    val role: String,
    val avatarColor: Long = 0xFF06B6D4,
    val isOnline: Boolean = true
)

data class CommentItem(
    val id: String,
    val author: String,
    val text: String,
    val timecodeFormatted: String = "0:12",
    val measureTarget: Int = 2,
    val timestamp: String = "10m ago"
)

data class CloudProject(
    val id: String,
    val title: String,
    val genre: String,
    val ownerName: String,
    val lastUpdated: String,
    val collaborators: List<Collaborator>,
    val comments: List<CommentItem>,
    val versionsCount: Int = 3,
    val bpm: Int = 120,
    val score: SongScore
)

// Beginner Practice Mode Music Theory Tutorial Module
data class TheoryTutorial(
    val id: String,
    val title: String,
    val category: String, // "Progression", "Scales", "Rhythm", "Nuance"
    val summary: String,
    val detailedExplanation: String,
    val exampleChordsOrNotes: List<String>,
    val audioDemoMidi: List<Int>,
    val badgeColor: Long
)
