package com.example.export

import android.content.Context
import android.content.Intent
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.model.InstrumentTrack
import com.example.model.InstrumentType
import com.example.model.MusicalNote
import com.example.model.SongScore
import com.example.model.VocalOrnament
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.roundToInt

object ExportManager {

    /**
     * Generates a real printable PDF document of the score sheet music and guitar tablature.
     */
    fun exportToPdf(context: Context, score: SongScore, track: InstrumentTrack): File {
        val document = PdfDocument()
        val cleanTitle = score.title.replace(Regex("[^a-zA-Z0-9]"), "_")
        val file = File(context.cacheDir, "${cleanTitle}_Sheet_Music.pdf")

        try {
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // Standard A4 page
            val page = document.startPage(pageInfo)
            val canvas = page.canvas

            val titlePaint = Paint().apply {
                color = AndroidColor.BLACK
                textSize = 20f
                typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
                isAntiAlias = true
            }

            val subtitlePaint = Paint().apply {
                color = AndroidColor.DKGRAY
                textSize = 11f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
                isAntiAlias = true
            }

            val staffPaint = Paint().apply {
                color = AndroidColor.BLACK
                strokeWidth = 1.2f
                style = Paint.Style.STROKE
                isAntiAlias = true
            }

            val barlinePaint = Paint().apply {
                color = AndroidColor.BLACK
                strokeWidth = 1.8f
                style = Paint.Style.STROKE
            }

            val notePaint = Paint().apply {
                color = AndroidColor.BLACK
                style = Paint.Style.FILL
                isAntiAlias = true
            }

            val textNotePaint = Paint().apply {
                color = AndroidColor.BLACK
                textSize = 10f
                typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
                isAntiAlias = true
            }

            val chordPaint = Paint().apply {
                color = AndroidColor.rgb(16, 80, 160)
                textSize = 13f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                isAntiAlias = true
            }

            // 1. Header
            canvas.drawText(score.title, 40f, 50f, titlePaint)
            canvas.drawText(
                "Track: ${track.name} (${track.instrument.displayName})  •  Key: ${score.keySignature}  •  Tempo: ${score.bpm} BPM",
                40f,
                70f,
                subtitlePaint
            )
            canvas.drawText("Harmoniq Studio Arrangement  •  ${if (score.isBeginnerMode) "Beginner Practice Mode" else "Professional Engraving"}", 40f, 85f, subtitlePaint)

            // 2. Systems and Staff Lines
            val startX = 40f
            val systemWidth = 515f
            var currentY = 130f
            val lineSpacing = 10f
            val measuresPerSystem = 2
            val measureWidth = systemWidth / measuresPerSystem

            val measures = track.measures
            val totalSystems = (measures.size + measuresPerSystem - 1) / measuresPerSystem

            for (sys in 0 until totalSystems) {
                val isGuitar = track.instrument == InstrumentType.GUITAR
                val numLines = if (isGuitar) 6 else 5

                // Draw Staff lines
                for (line in 0 until numLines) {
                    val y = currentY + line * lineSpacing
                    canvas.drawLine(startX, y, startX + systemWidth, y, staffPaint)
                }

                // Left edge barline
                canvas.drawLine(startX, currentY, startX, currentY + (numLines - 1) * lineSpacing, barlinePaint)

                // Clef symbol text
                val clefSymbol = if (isGuitar) "TAB" else "𝄞"
                val clefPaint = Paint().apply {
                    color = AndroidColor.BLACK
                    textSize = if (isGuitar) 14f else 28f
                    typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
                }
                canvas.drawText(clefSymbol, startX + 4f, currentY + 22f, clefPaint)

                // Draw Measures on this system
                for (mInSys in 0 until measuresPerSystem) {
                    val mIndex = sys * measuresPerSystem + mInSys
                    if (mIndex >= measures.size) break
                    val measure = measures[mIndex]
                    val mLeft = startX + 35f + mInSys * (measureWidth - 18f)
                    val mRight = mLeft + (measureWidth - 18f)

                    // Barline
                    canvas.drawLine(mRight, currentY, mRight, currentY + (numLines - 1) * lineSpacing, barlinePaint)

                    // Measure number
                    canvas.drawText("${measure.measureNumber}", mLeft + 4f, currentY - 18f, subtitlePaint)

                    // Chord name above measure
                    measure.chord?.let { chord ->
                        canvas.drawText(
                            "${chord.chordName} (${chord.romanNumeral})",
                            mLeft + 16f,
                            currentY - 6f,
                            chordPaint
                        )
                    }

                    // Notes
                    val notes = measure.notes
                    val spacing = (mRight - mLeft) / (notes.size.coerceAtLeast(1) + 1)
                    for ((nIdx, note) in notes.withIndex()) {
                        if (note.isRest) continue
                        val noteX = mLeft + (nIdx + 1) * spacing

                        if (isGuitar) {
                            // Draw fret number on string line
                            val stringIdx = (note.stringNumber - 1).coerceIn(0, 5)
                            val noteY = currentY + stringIdx * lineSpacing
                            val bgPaint = Paint().apply { color = AndroidColor.WHITE; style = Paint.Style.FILL }
                            canvas.drawRect(noteX - 4f, noteY - 6f, noteX + 12f, noteY + 6f, bgPaint)
                            canvas.drawText("${note.fretNumber}", noteX, noteY + 4f, textNotePaint)
                        } else {
                            // Standard notehead on staff
                            val semitones = note.midiNote - 71 // B4
                            val noteY = currentY + 2 * lineSpacing - (semitones / 1.714f) * (lineSpacing / 2f)
                            canvas.drawOval(
                                noteX - 5f,
                                noteY - 3.5f,
                                noteX + 5f,
                                noteY + 3.5f,
                                notePaint
                            )
                            // Stem
                            canvas.drawLine(noteX + 4f, noteY, noteX + 4f, noteY - 24f, staffPaint)

                            // If Beginner Mode, letter name next to notehead
                            if (score.isBeginnerMode) {
                                val letter = note.pitchName.filter { it.isLetter() || it == '#' }
                                canvas.drawText(letter, noteX - 3f, noteY - 6f, subtitlePaint)
                            }

                            // Vocal vibrato marking
                            if (note.vocalNuance?.ornament == VocalOrnament.VIBRATO) {
                                canvas.drawText("~vib~", noteX - 8f, noteY - 28f, subtitlePaint)
                            }

                            // Lyric syllable
                            note.lyricSyllable?.let { lyr ->
                                canvas.drawText(lyr, noteX - 6f, currentY + (numLines - 1) * lineSpacing + 16f, subtitlePaint)
                            }
                        }
                    }
                }

                currentY += (numLines * lineSpacing) + 65f
                if (currentY > 740f) break
            }

            // Footer
            canvas.drawText("Generated by Harmoniq • Sheet Music & Multi-Instrument Transcription Engine", 40f, 810f, subtitlePaint)

            document.finishPage(page)

            FileOutputStream(file).use { out ->
                document.writeTo(out)
            }
        } finally {
            document.close()
        }
        return file
    }

    /**
     * Generates a standard multi-track MIDI file (.mid, Type 1) with separate tracks for
     * Piano, Guitar, Bass, Drums, Violin, and Vocals, including pitch bend telemetry for vocal nuances.
     */
    fun exportToMidi(context: Context, score: SongScore): File {
        val bos = ByteArrayOutputStream()

        val ticksPerBeat = 480
        val bpm = score.bpm.coerceIn(40, 240)
        val usPerBeat = (60_000_000 / bpm) // Microseconds per quarter note

        // 1. Header Chunk: "MThd", length=6, format=1, tracks=score.tracks.size + 1, division=480
        val numTracks = score.tracks.size + 1
        bos.write("MThd".toByteArray(Charsets.US_ASCII))
        writeUint32(bos, 6)
        writeUint16(bos, 1)          // Format 1 (multi-track)
        writeUint16(bos, numTracks)  // Number of tracks
        writeUint16(bos, ticksPerBeat) // Division (480 ticks/beat)

        // 2. Track 0: Conductor / Tempo Track
        val track0 = ByteArrayOutputStream()
        // Track Name
        writeMetaEvent(track0, 0x03, "Harmoniq Master Conductor".toByteArray(Charsets.US_ASCII))
        // Time Signature: 4/4
        track0.write(byteArrayOf(0x00.toByte(), 0xFF.toByte(), 0x58.toByte(), 0x04.toByte(), 0x04.toByte(), 0x02.toByte(), 0x18.toByte(), 0x08.toByte()))
        // Set Tempo
        val tempoBytes = byteArrayOf(
            ((usPerBeat shr 16) and 0xFF).toByte(),
            ((usPerBeat shr 8) and 0xFF).toByte(),
            (usPerBeat and 0xFF).toByte()
        )
        writeMetaEvent(track0, 0x51, tempoBytes)
        // End of Track
        track0.write(byteArrayOf(0x00.toByte(), 0xFF.toByte(), 0x2F.toByte(), 0x00.toByte()))

        bos.write("MTrk".toByteArray(Charsets.US_ASCII))
        writeUint32(bos, track0.size().toLong())
        bos.write(track0.toByteArray())

        // 3. Instrument Tracks 1..N
        for ((idx, track) in score.tracks.withIndex()) {
            val trackBytes = ByteArrayOutputStream()
            val channel = if (track.instrument == InstrumentType.DRUMS) 9 else (idx % 16).let { if (it == 9) 10 else it }

            // Track name
            writeMetaEvent(trackBytes, 0x03, track.name.toByteArray(Charsets.US_ASCII))

            // Program Change (Instrument patch)
            val patch = when (track.instrument) {
                InstrumentType.PIANO -> 0    // Acoustic Grand Piano
                InstrumentType.GUITAR -> 24  // Acoustic Guitar (nylon)
                InstrumentType.BASS -> 33    // Electric Bass (finger)
                InstrumentType.VIOLIN -> 40  // Violin
                InstrumentType.VOCALS -> 54  // Voice Oohs
                InstrumentType.DRUMS -> 0    // Standard Drum Kit (Channel 10)
            }
            writeVarLen(trackBytes, 0)
            trackBytes.write(0xC0 or (channel and 0x0F))
            trackBytes.write(patch and 0x7F)

            // Gather all note events and sort by tick time
            data class MidiEvent(val tick: Long, val type: Int, val note: Int, val velocity: Int, val pitchBend: Int = 8192)

            val events = mutableListOf<MidiEvent>()
            for (measure in track.measures) {
                for (note in measure.notes) {
                    if (note.isRest) continue
                    val startTick = (note.startBeat * ticksPerBeat).toLong()
                    val durationTicks = (note.duration.beats * ticksPerBeat).toLong()
                    val endTick = startTick + durationTicks

                    val midiPitch = if (track.instrument == InstrumentType.DRUMS) {
                        when (note.pitchName) {
                            "Kick" -> 36
                            "Snare" -> 38
                            else -> 42 // Hi-Hat
                        }
                    } else note.midiNote.coerceIn(12, 110)

                    // Note On
                    events.add(MidiEvent(startTick, 0x90, midiPitch, note.velocity))

                    // Vocal Nuance Pitch Bend event for vibrato or scoop
                    if (note.vocalNuance?.ornament == VocalOrnament.VIBRATO || note.vocalNuance?.ornament == VocalOrnament.BEND_UP) {
                        val bendTick = startTick + (durationTicks / 2)
                        val bendVal = (8192 + (note.vocalNuance.pitchBendCents * 40).toInt()).coerceIn(0, 16383)
                        events.add(MidiEvent(bendTick, 0xE0, 0, 0, pitchBend = bendVal))
                        // Reset bend back to center
                        events.add(MidiEvent(endTick - 10, 0xE0, 0, 0, pitchBend = 8192))
                    }

                    // Note Off
                    events.add(MidiEvent(endTick, 0x80, midiPitch, 0))
                }
            }

            events.sortBy { it.tick }

            var lastTick = 0L
            for (ev in events) {
                val delta = (ev.tick - lastTick).coerceAtLeast(0)
                writeVarLen(trackBytes, delta)

                when (ev.type) {
                    0x90 -> {
                        trackBytes.write(0x90 or (channel and 0x0F))
                        trackBytes.write(ev.note and 0x7F)
                        trackBytes.write(ev.velocity and 0x7F)
                    }
                    0x80 -> {
                        trackBytes.write(0x80 or (channel and 0x0F))
                        trackBytes.write(ev.note and 0x7F)
                        trackBytes.write(0x00)
                    }
                    0xE0 -> {
                        trackBytes.write(0xE0 or (channel and 0x0F))
                        trackBytes.write(ev.pitchBend and 0x7F)        // LSB
                        trackBytes.write((ev.pitchBend shr 7) and 0x7F) // MSB
                    }
                }
                lastTick = ev.tick
            }

            // End of Track
            writeVarLen(trackBytes, 0)
            trackBytes.write(byteArrayOf(0xFF.toByte(), 0x2F.toByte(), 0x00.toByte()))

            bos.write("MTrk".toByteArray(Charsets.US_ASCII))
            writeUint32(bos, trackBytes.size().toLong())
            bos.write(trackBytes.toByteArray())
        }

        val cleanTitle = score.title.replace(Regex("[^a-zA-Z0-9]"), "_")
        val file = File(context.cacheDir, "${cleanTitle}_Arrangement.mid")
        FileOutputStream(file).use { it.write(bos.toByteArray()) }
        return file
    }

    /**
     * Exports score in standard MusicXML notation format.
     */
    fun exportToMusicXml(context: Context, score: SongScore): File {
        val xml = buildString {
            append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n")
            append("<!DOCTYPE score-partwise PUBLIC \"-//Recordare//DTD MusicXML 3.0 Partwise//EN\" \"http://www.musicxml.org/dtds/partwise.dtd\">\n")
            append("<score-partwise version=\"3.0\">\n")
            append("  <work><work-title>${score.title}</work-title></work>\n")
            append("  <identification><creator type=\"composer\">Harmoniq Studio</creator></identification>\n")
            append("  <part-list>\n")
            for (track in score.tracks) {
                append("    <score-part id=\"P_${track.trackId}\"><part-name>${track.name}</part-name></score-part>\n")
            }
            append("  </part-list>\n")
            for (track in score.tracks) {
                append("  <part id=\"P_${track.trackId}\">\n")
                for (measure in track.measures) {
                    append("    <measure number=\"${measure.measureNumber}\">\n")
                    if (measure.measureNumber == 1) {
                        append("      <attributes>\n")
                        append("        <divisions>4</divisions>\n")
                        append("        <key><fifths>0</fifths></key>\n")
                        append("        <time><beats>4</beats><beat-type>4</beat-type></time>\n")
                        append("        <clef><sign>G</sign><line>2</line></clef>\n")
                        append("      </attributes>\n")
                    }
                    for (note in measure.notes) {
                        append("      <note>\n")
                        if (note.isRest) {
                            append("        <rest/>\n")
                        } else {
                            val step = note.pitchName.firstOrNull() ?: 'C'
                            val octave = note.pitchName.lastOrNull()?.toString()?.toIntOrNull() ?: 4
                            append("        <pitch><step>$step</step><octave>$octave</octave></pitch>\n")
                        }
                        append("        <duration>${(note.duration.beats * 4).toInt()}</duration>\n")
                        append("        <type>${note.duration.name.lowercase()}</type>\n")
                        if (note.vocalNuance?.ornament == VocalOrnament.VIBRATO) {
                            append("        <notations><ornaments><wavy-line type=\"start\"/></ornaments></notations>\n")
                        }
                        append("      </note>\n")
                    }
                    append("    </measure>\n")
                }
                append("  </part>\n")
            }
            append("</score-partwise>\n")
        }

        val cleanTitle = score.title.replace(Regex("[^a-zA-Z0-9]"), "_")
        val file = File(context.cacheDir, "${cleanTitle}_Score.musicxml")
        file.writeText(xml)
        return file
    }

    /**
     * Exports a Lead Sheet Chord Chart in text/ChordPro format.
     */
    fun exportToChordPro(context: Context, score: SongScore): File {
        val text = buildString {
            append("{title: ${score.title}}\n")
            append("{key: ${score.keySignature}}\n")
            append("{tempo: ${score.bpm}}\n\n")

            for (measure in score.tracks.firstOrNull()?.measures ?: emptyList()) {
                measure.chord?.let { ch ->
                    append("[${ch.chordName}] ")
                }
                val lyrics = measure.notes.mapNotNull { it.lyricSyllable }.joinToString(" ")
                if (lyrics.isNotBlank()) append(lyrics)
                append(" | ")
            }
            append("\n\n-- Arranged with Harmoniq Studio --\n")
        }

        val cleanTitle = score.title.replace(Regex("[^a-zA-Z0-9]"), "_")
        val file = File(context.cacheDir, "${cleanTitle}_LeadSheet.txt")
        file.writeText(text)
        return file
    }

    /**
     * Shares a generated file using the Android system share sheet.
     */
    fun shareFile(context: Context, file: File, mimeType: String, chooserTitle: String = "Export Composition") {
        try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, file.name)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, chooserTitle).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Helper functions for MIDI binary generation
    private fun writeUint32(out: ByteArrayOutputStream, value: Long) {
        out.write(((value shr 24) and 0xFF).toInt())
        out.write(((value shr 16) and 0xFF).toInt())
        out.write(((value shr 8) and 0xFF).toInt())
        out.write((value and 0xFF).toInt())
    }

    private fun writeUint16(out: ByteArrayOutputStream, value: Int) {
        out.write((value shr 8) and 0xFF)
        out.write(value and 0xFF)
    }

    private fun writeVarLen(out: ByteArrayOutputStream, value: Long) {
        var v = value
        val buf = ByteArray(4)
        var i = 3
        buf[i] = (v and 0x7F).toByte()
        while ((v shr 7) > 0) {
            v = v shr 7
            i--
            buf[i] = ((v and 0x7F) or 0x80).toByte()
        }
        out.write(buf, i, 4 - i)
    }

    private fun writeMetaEvent(out: ByteArrayOutputStream, type: Int, data: ByteArray) {
        writeVarLen(out, 0)
        out.write(0xFF)
        out.write(type and 0xFF)
        writeVarLen(out, data.size.toLong())
        out.write(data)
    }
}
