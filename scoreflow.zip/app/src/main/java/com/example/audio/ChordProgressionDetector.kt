package com.example.audio

import com.example.model.ChordNotation

data class DetectedChordInfo(
    val chordName: String = "C",
    val quality: String = "Major",
    val romanNumeral: String = "I",
    val confidencePercent: Int = 90,
    val notesHeard: List<String> = listOf("C", "E", "G"),
    val soundingWithCapo: String = "C",
    val capoShapeName: String = "C Shape",
    val theoryRole: String = "Tonic Home"
)

object ChordProgressionDetector {

    private val NOTE_NAMES = listOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

    // Triad definitions (semitone offsets from root)
    private val MAJOR_INTERVALS = listOf(0, 4, 7)
    private val MINOR_INTERVALS = listOf(0, 3, 7)
    private val SEVENTH_INTERVALS = listOf(0, 4, 7, 10)
    private val MAJ7_INTERVALS = listOf(0, 4, 7, 11)

    // Common Roman numerals in key of C
    private val C_MAJOR_ROMAN = mapOf(
        "C" to Pair("I", "Tonic (Home)"),
        "Dm" to Pair("ii", "Supertonic"),
        "Em" to Pair("iii", "Mediant"),
        "F" to Pair("IV", "Subdominant (Lift)"),
        "G" to Pair("V", "Dominant (Tension)"),
        "G7" to Pair("V7", "Dominant 7th"),
        "Am" to Pair("vi", "Submediant (Relative Minor)"),
        "Bdim" to Pair("vii°", "Leading Tone")
    )

    /**
     * Estimates the chord from a collection of recently sung or played note pitch names.
     */
    fun estimateChord(
        recentNotes: List<String>,
        capoFret: Int = 0
    ): DetectedChordInfo {
        if (recentNotes.isEmpty()) {
            return calculateCapoTransposition("C", "Major", "I", "Tonic (Home)", listOf("C", "E", "G"), capoFret)
        }

        // Extract pitch classes (remove octave numbers like C4 -> C)
        val pitchClasses = recentNotes.map { note ->
            note.filter { it.isLetter() || it == '#' }.uppercase()
        }.distinct()

        var bestChord = "C"
        var bestQuality = "Major"
        var bestScore = -1

        // Test each root note
        for (rootIdx in 0 until 12) {
            val rootName = NOTE_NAMES[rootIdx]

            // Test Major
            val majPitchClasses = MAJOR_INTERVALS.map { NOTE_NAMES[(rootIdx + it) % 12] }
            val majScore = pitchClasses.count { majPitchClasses.contains(it) } * 3 -
                    pitchClasses.count { !majPitchClasses.contains(it) }

            if (majScore > bestScore) {
                bestScore = majScore
                bestChord = rootName
                bestQuality = "Major"
            }

            // Test Minor
            val minPitchClasses = MINOR_INTERVALS.map { NOTE_NAMES[(rootIdx + it) % 12] }
            val minScore = pitchClasses.count { minPitchClasses.contains(it) } * 3 -
                    pitchClasses.count { !minPitchClasses.contains(it) }

            if (minScore > bestScore) {
                bestScore = minScore
                bestChord = "${rootName}m"
                bestQuality = "Minor"
            }
        }

        val romanPair = C_MAJOR_ROMAN[bestChord] ?: Pair(
            if (bestQuality == "Minor") "i" else "I",
            if (bestQuality == "Minor") "Minor Chord" else "Major Chord"
        )

        val confidence = ((bestScore + 2) * 20).coerceIn(60, 98)

        return calculateCapoTransposition(
            baseChordName = bestChord,
            quality = bestQuality,
            romanNumeral = romanPair.first,
            theoryRole = romanPair.second,
            heard = pitchClasses,
            capoFret = capoFret
        )
    }

    /**
     * Calculates sounding chord and guitar finger shape when playing with Capo.
     * E.g. Capo 2:
     * - If you finger a "C Shape", it sounds as "D Major" (C + 2 semitones = D).
     * - If sounding pitch is D Major, Capo shape is "C Shape".
     */
    fun calculateCapoTransposition(
        baseChordName: String,
        quality: String,
        romanNumeral: String,
        theoryRole: String,
        heard: List<String>,
        capoFret: Int
    ): DetectedChordInfo {
        if (capoFret == 0) {
            return DetectedChordInfo(
                chordName = baseChordName,
                quality = quality,
                romanNumeral = romanNumeral,
                confidencePercent = 92,
                notesHeard = heard,
                soundingWithCapo = baseChordName,
                capoShapeName = "Standard Open Tuning (No Capo)",
                theoryRole = theoryRole
            )
        }

        // Root note index
        val rootPart = baseChordName.filter { it.isLetter() || it == '#' }.removeSuffix("m")
        val rootIdx = NOTE_NAMES.indexOfFirst { it.equals(rootPart, ignoreCase = true) }.let { if (it >= 0) it else 0 }

        // Sounding chord = Root + capoFret semitones
        val soundingRootIdx = (rootIdx + capoFret) % 12
        val soundingRoot = NOTE_NAMES[soundingRootIdx]
        val soundingChord = if (quality == "Minor") "${soundingRoot}m" else soundingRoot

        // Shape played on fretboard
        val shapeName = "Play: $baseChordName Shape (Fret $capoFret)"

        return DetectedChordInfo(
            chordName = soundingChord,
            quality = quality,
            romanNumeral = romanNumeral,
            confidencePercent = 95,
            notesHeard = heard,
            soundingWithCapo = soundingChord,
            capoShapeName = "$shapeName ➔ Sounds: $soundingChord",
            theoryRole = "$theoryRole (Capo Fret $capoFret)"
        )
    }

    /**
     * Transposes guitar chords and tab frets for a specific capo setting.
     */
    fun getCapoGuitarFrets(standardFrets: List<Int?>, capoFret: Int): List<Int?> {
        if (capoFret == 0) return standardFrets
        return standardFrets.map { fret ->
            if (fret == null || fret == -1) -1
            else if (fret == 0) capoFret
            else fret + capoFret
        }
    }
}
