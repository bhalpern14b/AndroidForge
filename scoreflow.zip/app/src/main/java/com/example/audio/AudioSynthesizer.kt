package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.example.model.InstrumentTrack
import com.example.model.InstrumentType
import com.example.model.MusicalNote
import com.example.model.SongScore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

class AudioSynthesizer(private val scope: CoroutineScope) {

    private val sampleRate = 44100
    private var playbackJob: Job? = null

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPlayheadBeat = MutableStateFlow(0.0f)
    val currentPlayheadBeat: StateFlow<Float> = _currentPlayheadBeat.asStateFlow()

    private var audioTrack: AudioTrack? = null

    init {
        try {
            val minBufferSize = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(minBufferSize * 4)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            audioTrack?.play()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Plays a single note immediately on a selected instrument (e.g. when tapping a piano key or guitar string).
     */
    fun previewNote(note: MusicalNote, instrument: InstrumentType = InstrumentType.PIANO) {
        scope.launch(Dispatchers.Default) {
            val durationSec = 0.6f
            val samples = (sampleRate * durationSec).toInt()
            val pcm = ShortArray(samples)
            renderInstrumentSample(pcm, 0, samples, note.midiNote, instrument, 1.0f)
            audioTrack?.write(pcm, 0, samples)
        }
    }

    /**
     * Plays a chord preview (multiple MIDI notes) on the instrument.
     */
    fun previewChord(midiNotes: List<Int>, instrument: InstrumentType = InstrumentType.GUITAR) {
        scope.launch(Dispatchers.Default) {
            val durationSec = 1.0f
            val samples = (sampleRate * durationSec).toInt()
            val pcm = ShortArray(samples)
            val noteVol = (1.0f / midiNotes.size.coerceAtLeast(1).toFloat()).coerceAtLeast(0.4f)
            for ((index, midi) in midiNotes.withIndex()) {
                // Slight strum delay for guitar realism
                val delaySamples = if (instrument == InstrumentType.GUITAR) index * (sampleRate / 40) else 0
                val activeSamples = (samples - delaySamples).coerceAtLeast(0)
                if (activeSamples > 0) {
                    renderInstrumentSample(pcm, delaySamples, activeSamples, midi, instrument, noteVol)
                }
            }
            audioTrack?.write(pcm, 0, samples)
        }
    }

    /**
     * Plays the full song arrangement with all enabled tracks simultaneously!
     */
    fun startPlayback(score: SongScore, fromBeat: Float = 0f) {
        stopPlayback()
        _isPlaying.value = true

        playbackJob = scope.launch(Dispatchers.Default) {
            val bpm = score.bpm.coerceIn(40, 240)
            val beatDurationSec = 60.0f / bpm
            val totalBeats = score.totalBeats
            var currentBeat = fromBeat

            val stepBeats = 0.25f // 16th note granularity
            val stepSamples = (stepBeats * beatDurationSec * sampleRate).toInt()
            val buffer = ShortArray(stepSamples)

            // Any solo track takes precedence
            val hasSolo = score.tracks.any { it.isSolo }
            val activeTracks = score.tracks.filter { track ->
                if (hasSolo) track.isSolo else !track.isMuted
            }

            while (isActive && currentBeat < totalBeats) {
                buffer.fill(0)

                for (track in activeTracks) {
                    val trackVol = track.volume
                    for (measure in track.measures) {
                        for (note in measure.notes) {
                            if (note.isRest) continue
                            val noteEnd = note.startBeat + note.duration.beats
                            if (currentBeat >= note.startBeat && currentBeat < noteEnd) {
                                val offsetInNoteBeats = currentBeat - note.startBeat
                                val offsetSeconds = offsetInNoteBeats * beatDurationSec
                                renderInstrumentSlice(
                                    buffer = buffer,
                                    midi = note.midiNote,
                                    instrument = track.instrument,
                                    volume = trackVol,
                                    offsetSec = offsetSeconds,
                                    totalNoteSec = note.duration.beats * beatDurationSec
                                )
                            }
                        }
                    }
                }

                audioTrack?.write(buffer, 0, stepSamples)
                _currentPlayheadBeat.value = currentBeat
                currentBeat += stepBeats
                delay((stepBeats * beatDurationSec * 1000).toLong())
            }

            _isPlaying.value = false
            _currentPlayheadBeat.value = 0f
        }
    }

    fun stopPlayback() {
        playbackJob?.cancel()
        playbackJob = null
        _isPlaying.value = false
        _currentPlayheadBeat.value = 0f
    }

    fun pausePlayback() {
        playbackJob?.cancel()
        playbackJob = null
        _isPlaying.value = false
    }

    private fun renderInstrumentSample(
        buffer: ShortArray,
        startIndex: Int,
        numSamples: Int,
        midi: Int,
        instrument: InstrumentType,
        volMultiplier: Float
    ) {
        val freq = PitchDetector.midiToFrequency(midi)
        for (i in 0 until numSamples) {
            val t = i.toFloat() / sampleRate
            val sampleVal = generateInstrumentWave(t, freq, instrument, 1.0f)
            val mixed = (buffer[startIndex + i] + (sampleVal * 16000 * volMultiplier).toInt()).coerceIn(-32767, 32767)
            buffer[startIndex + i] = mixed.toShort()
        }
    }

    private fun renderInstrumentSlice(
        buffer: ShortArray,
        midi: Int,
        instrument: InstrumentType,
        volume: Float,
        offsetSec: Float,
        totalNoteSec: Float
    ) {
        val freq = PitchDetector.midiToFrequency(midi)
        val sliceDuration = buffer.size.toFloat() / sampleRate

        for (i in buffer.indices) {
            val t = offsetSec + (i.toFloat() / buffer.size) * sliceDuration
            if (t > totalNoteSec) break
            val sampleVal = generateInstrumentWave(t, freq, instrument, totalNoteSec)
            val mixed = (buffer[i] + (sampleVal * 12000 * volume).toInt()).coerceIn(-32767, 32767)
            buffer[i] = mixed.toShort()
        }
    }

    private fun generateInstrumentWave(
        t: Float,
        freq: Float,
        instrument: InstrumentType,
        noteLengthSec: Float
    ): Float {
        return when (instrument) {
            InstrumentType.PIANO -> {
                // Harmonic additive synthesis with hammer strike & exponential decay
                val env = exp(-3.5f * t)
                val fundamental = sin(2 * PI * freq * t).toFloat()
                val h2 = 0.5f * sin(4 * PI * freq * t).toFloat()
                val h3 = 0.25f * sin(6 * PI * freq * t).toFloat()
                val h4 = 0.12f * sin(8 * PI * freq * t).toFloat()
                (fundamental + h2 + h3 + h4) * env
            }
            InstrumentType.GUITAR -> {
                // Plucked string envelope with bright upper harmonics
                val env = exp(-4.2f * t)
                val fundamental = sin(2 * PI * freq * t).toFloat()
                val h2 = 0.65f * sin(4 * PI * freq * t).toFloat()
                val h3 = 0.35f * sin(6 * PI * freq * t).toFloat()
                val h4 = 0.2f * sin(8 * PI * freq * t).toFloat()
                (fundamental + h2 + h3 + h4) * env
            }
            InstrumentType.BASS -> {
                // Deep fundamental with punchy round envelope
                val env = exp(-2.5f * t)
                val fundamental = sin(2 * PI * (freq * 0.5f) * t).toFloat()
                val h2 = 0.4f * sin(2 * PI * freq * t).toFloat()
                (fundamental + h2) * env
            }
            InstrumentType.VIOLIN -> {
                // Bowed string: rich sawtooth-like harmonics + gentle expressive vibrato
                val vibrato = 1.0f + 0.015f * sin(2 * PI * 5.5f * t).toFloat()
                val vFreq = freq * vibrato
                val attack = (t / 0.08f).coerceAtMost(1.0f)
                val release = if (t > noteLengthSec - 0.05f) {
                    ((noteLengthSec - t) / 0.05f).coerceIn(0f, 1f)
                } else 1.0f
                val env = attack * release
                val s1 = sin(2 * PI * vFreq * t).toFloat()
                val s2 = 0.6f * sin(4 * PI * vFreq * t).toFloat()
                val s3 = 0.4f * sin(6 * PI * vFreq * t).toFloat()
                val s4 = 0.25f * sin(8 * PI * vFreq * t).toFloat()
                (s1 + s2 + s3 + s4) * 0.6f * env
            }
            InstrumentType.DRUMS -> {
                // Synthetic drum hits based on frequency / pitch
                if (freq < 150f) {
                    // Kick drum: rapid pitch drop
                    val kickFreq = 140f * exp(-28f * t) + 45f
                    val kickEnv = exp(-12f * t)
                    sin(2 * PI * kickFreq * t).toFloat() * kickEnv
                } else if (freq < 300f) {
                    // Snare drum: tone + noise burst
                    val snareTone = sin(2 * PI * 180f * t).toFloat() * exp(-15f * t)
                    val noise = (Random.nextFloat() * 2f - 1f) * exp(-18f * t)
                    (snareTone * 0.5f + noise * 0.7f)
                } else {
                    // Hi-Hat / Cymbals: metallic noise
                    val hatNoise = (Random.nextFloat() * 2f - 1f) * exp(-35f * t)
                    hatNoise * 0.6f
                }
            }
            InstrumentType.VOCALS -> {
                // Formant-filtered vocal tone with natural vibrato
                val vibrato = 1.0f + 0.012f * sin(2 * PI * 5.2f * t).toFloat()
                val vFreq = freq * vibrato
                val env = exp(-2.0f * t)
                val fund = sin(2 * PI * vFreq * t).toFloat()
                val form = 0.5f * sin(4 * PI * vFreq * t).toFloat()
                (fund + form) * env
            }
        }
    }

    fun release() {
        stopPlayback()
        try {
            audioTrack?.stop()
            audioTrack?.release()
            audioTrack = null
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
