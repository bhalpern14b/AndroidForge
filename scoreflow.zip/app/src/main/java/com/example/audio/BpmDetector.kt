package com.example.audio

import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Real-time BPM and Beat detector analyzing incoming PCM audio streams.
 * Utilizes spectral flux energy and onset autocorrelation across sliding windows.
 */
object BpmDetector {

    private const val MIN_BPM = 50
    private const val MAX_BPM = 220

    // History of audio energy onsets and timestamps for BPM estimation
    private val onsetTimestamps = mutableListOf<Long>()
    private val onsetEnergies = mutableListOf<Float>()
    private var previousEnergy = 0f

    // Estimated BPM smoothing history
    private val bpmEstimates = mutableListOf<Int>()
    private var lastBeatTimestamp = 0L

    data class BpmAnalysisResult(
        val detectedBpm: Int,
        val confidencePercent: Int, // 0 - 100%
        val isBeatOnset: Boolean,
        val tempoLabel: String,      // e.g., "Andante", "Moderato", "Allegro"
        val energyFlux: Float
    )

    /**
     * Processes a chunk of 16-bit PCM buffer and updates onset tracking.
     */
    @Synchronized
    fun processPcmBuffer(buffer: ShortArray, readSize: Int, sampleRate: Int = 44100): BpmAnalysisResult {
        if (readSize <= 0) {
            return BpmAnalysisResult(
                detectedBpm = 0,
                confidencePercent = 0,
                isBeatOnset = false,
                tempoLabel = "Idle",
                energyFlux = 0f
            )
        }

        val currentTime = System.currentTimeMillis()

        // 1. Calculate instant RMS energy with low-frequency emphasis (kick/percussive bass band)
        var sumEnergy = 0.0
        // Focus on onset transients by checking absolute peak and RMS
        var maxPeak = 0
        for (i in 0 until readSize) {
            val sample = buffer[i].toInt()
            sumEnergy += sample * sample
            val absSample = abs(sample)
            if (absSample > maxPeak) maxPeak = absSample
        }
        val rms = sqrt(sumEnergy / readSize).toFloat()
        val currentEnergy = (rms / 32768f).coerceIn(0f, 1f)

        // 2. Spectral energy flux (half-wave rectified difference)
        val flux = (currentEnergy - previousEnergy).coerceAtLeast(0f)
        previousEnergy = currentEnergy * 0.85f + 0.15f * previousEnergy // leaky integrator

        // 3. Dynamic adaptive threshold for onset detection
        val recentAvgEnergy = if (onsetEnergies.isNotEmpty()) onsetEnergies.average().toFloat() else 0.05f
        val dynamicThreshold = (recentAvgEnergy * 1.6f).coerceIn(0.04f, 0.45f)

        var isOnset = false
        val minIntervalMs = 60000L / MAX_BPM // ~272 ms for 220 BPM

        if (flux > dynamicThreshold && (currentTime - lastBeatTimestamp) >= minIntervalMs) {
            isOnset = true
            lastBeatTimestamp = currentTime
            onsetTimestamps.add(currentTime)
            onsetEnergies.add(flux)

            // Keep sliding window of last 16 onsets (~4-8 bars)
            if (onsetTimestamps.size > 20) {
                onsetTimestamps.removeAt(0)
                onsetEnergies.removeAt(0)
            }
        }

        // Clean up stale timestamps older than 6 seconds
        val staleThreshold = currentTime - 6000L
        while (onsetTimestamps.isNotEmpty() && onsetTimestamps.first() < staleThreshold) {
            onsetTimestamps.removeAt(0)
            if (onsetEnergies.isNotEmpty()) onsetEnergies.removeAt(0)
        }

        // 4. Calculate BPM if we have sufficient onsets (at least 3 onsets)
        val calculatedBpm = calculateBpmFromOnsets()
        if (calculatedBpm in MIN_BPM..MAX_BPM) {
            bpmEstimates.add(calculatedBpm)
            if (bpmEstimates.size > 8) bpmEstimates.removeAt(0)
        }

        val smoothedBpm = if (bpmEstimates.isNotEmpty()) {
            val medianBpm = bpmEstimates.sorted()[bpmEstimates.size / 2]
            medianBpm
        } else {
            0
        }

        val confidence = calculateConfidence(smoothedBpm)
        val label = getTempoMarking(smoothedBpm)

        return BpmAnalysisResult(
            detectedBpm = smoothedBpm,
            confidencePercent = confidence,
            isBeatOnset = isOnset,
            tempoLabel = label,
            energyFlux = flux
        )
    }

    private fun calculateBpmFromOnsets(): Int {
        if (onsetTimestamps.size < 3) return 0

        val intervals = mutableListOf<Long>()
        for (i in 1 until onsetTimestamps.size) {
            val interval = onsetTimestamps[i] - onsetTimestamps[i - 1]
            if (interval in 200..1600) { // between 37.5 BPM and 300 BPM
                intervals.add(interval)
            }
        }

        if (intervals.isEmpty()) return 0

        // Cluster intervals to find dominant beat duration
        val avgInterval = intervals.average()
        if (avgInterval <= 0) return 0

        var rawBpm = (60000.0 / avgInterval).roundToInt()

        // Normalize if octave doubling or halving occurs (e.g. 8th notes vs quarter notes)
        while (rawBpm < MIN_BPM && rawBpm > 0) {
            rawBpm *= 2
        }
        while (rawBpm > MAX_BPM) {
            rawBpm /= 2
        }

        return rawBpm
    }

    private fun calculateConfidence(bpm: Int): Int {
        if (bpm == 0 || onsetTimestamps.size < 3) return 0
        val consistencyFactor = (onsetTimestamps.size * 6).coerceAtMost(60)
        val countFactor = if (bpmEstimates.size >= 4) {
            val variance = bpmEstimates.map { abs(it - bpm) }.average()
            val stability = (40 - variance * 3).toInt().coerceIn(10, 40)
            stability
        } else 15
        return (consistencyFactor + countFactor).coerceIn(20, 98)
    }

    fun getTempoMarking(bpm: Int): String {
        return when {
            bpm == 0 -> "Detecting..."
            bpm < 60 -> "Largo (Slow)"
            bpm < 76 -> "Adagio (Slow & Stately)"
            bpm < 108 -> "Andante (Walking Pace)"
            bpm < 120 -> "Moderato (Moderate)"
            bpm < 156 -> "Allegro (Fast & Lively)"
            bpm < 176 -> "Vivace (Very Fast)"
            else -> "Presto (Extremely Fast)"
        }
    }

    @Synchronized
    fun reset() {
        onsetTimestamps.clear()
        onsetEnergies.clear()
        bpmEstimates.clear()
        previousEnergy = 0f
        lastBeatTimestamp = 0L
    }
}
