package com.example.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import com.example.model.AudioPitchFrame
import com.example.model.TunerState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.sqrt

class AudioRecordManager(private val scope: CoroutineScope) {

    private val sampleRate = 44100
    private val bufferSize = 2048

    private var audioRecord: AudioRecord? = null
    private var recordJob: Job? = null

    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

    private val _tunerState = MutableStateFlow(TunerState())
    val tunerState: StateFlow<TunerState> = _tunerState.asStateFlow()

    private val _pitchFrames = MutableSharedFlow<AudioPitchFrame>(replay = 1)
    val pitchFrames: SharedFlow<AudioPitchFrame> = _pitchFrames.asSharedFlow()

    // Real-time reacting audio waveform points for visualizer
    private val _waveformAmplitudes = MutableStateFlow<List<Float>>(emptyList())
    val waveformAmplitudes: StateFlow<List<Float>> = _waveformAmplitudes.asStateFlow()

    private val _rawWaveformPoints = MutableStateFlow<List<Float>>(emptyList())
    val rawWaveformPoints: StateFlow<List<Float>> = _rawWaveformPoints.asStateFlow()

    // Real-time chord progression detection
    private val _detectedChordInfo = MutableStateFlow(DetectedChordInfo())
    val detectedChordInfo: StateFlow<DetectedChordInfo> = _detectedChordInfo.asStateFlow()

    private val _chordHistory = MutableStateFlow<List<String>>(listOf("C (I)", "G (V)", "Am (vi)", "F (IV)"))
    val chordHistory: StateFlow<List<String>> = _chordHistory.asStateFlow()

    // Real-time live audio BPM detection
    private val _liveBpmState = MutableStateFlow(com.example.model.LiveAudioBpmState())
    val liveBpmState: StateFlow<com.example.model.LiveAudioBpmState> = _liveBpmState.asStateFlow()

    // Capo setting for guitar (0 = open, 1..7 = fret)
    private var capoFret = 0

    // Sliding window of recently detected pitch notes for chord estimation
    private val recentPitches = mutableListOf<Float>()
    private val recentNoteNames = mutableListOf<String>()

    fun setCapoFret(fret: Int) {
        capoFret = fret.coerceIn(0, 10)
        _detectedChordInfo.value = ChordProgressionDetector.estimateChord(recentNoteNames.toList(), capoFret)
    }

    @SuppressLint("MissingPermission")
    fun startListening() {
        if (_isRecording.value) return

        try {
            val minBuf = AudioRecord.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            val effectiveBuf = maxOf(minBuf, bufferSize * 2)

            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                effectiveBuf
            )

            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                return
            }

            audioRecord?.startRecording()
            _isRecording.value = true

            recordJob = scope.launch(Dispatchers.Default) {
                val buffer = ShortArray(bufferSize)
                val ampHistory = mutableListOf<Float>()

                while (isActive && _isRecording.value) {
                    val read = audioRecord?.read(buffer, 0, bufferSize) ?: -1
                    if (read > 0) {
                        // 1. Raw waveform downsampling for oscilloscope visualizer (64 points)
                        val step = (read / 64).coerceAtLeast(1)
                        val points = mutableListOf<Float>()
                        for (i in 0 until read step step) {
                            points.add((buffer[i] / 32768.0f).coerceIn(-1f, 1f))
                        }
                        _rawWaveformPoints.value = points

                        // 2. Amplitude RMS
                        var sumSq = 0.0
                        for (i in 0 until read) {
                            val sample = buffer[i].toDouble()
                            sumSq += sample * sample
                        }
                        val rms = sqrt(sumSq / read)
                        val normAmp = (rms / 32768.0).toFloat().coerceIn(0f, 1f)

                        ampHistory.add(normAmp)
                        if (ampHistory.size > 40) ampHistory.removeAt(0)
                        _waveformAmplitudes.value = ampHistory.toList()

                        // 3. Real-Time BPM Detection from PCM energy & transients
                        val bpmResult = BpmDetector.processPcmBuffer(buffer, read, sampleRate)
                        _liveBpmState.value = com.example.model.LiveAudioBpmState(
                            detectedBpm = bpmResult.detectedBpm,
                            confidencePercent = bpmResult.confidencePercent,
                            tempoLabel = bpmResult.tempoLabel,
                            isBeatFlashing = bpmResult.isBeatOnset,
                            energyFlux = bpmResult.energyFlux
                        )

                        // 4. Detect Pitch & Note
                        val detectedFreq = PitchDetector.detectPitch(buffer, sampleRate)
                        val tuner = PitchDetector.frequencyToNote(detectedFreq)

                        if (detectedFreq > 0) {
                            recentPitches.add(detectedFreq)
                            if (recentPitches.size > 20) recentPitches.removeAt(0)

                            recentNoteNames.add(tuner.detectedNote)
                            if (recentNoteNames.size > 12) recentNoteNames.removeAt(0)

                            // Nuanced vocal stability analysis
                            val avgFreq = recentPitches.average().toFloat()
                            val variance = recentPitches.map { (it - avgFreq) * (it - avgFreq) }.average().toFloat()
                            val stdDev = sqrt(variance)
                            val stability = (100 - (stdDev / avgFreq * 300).toInt()).coerceIn(40, 99)

                            val updatedTuner = tuner.copy(
                                pitchStabilityPercent = stability,
                                vibratoDepthCents = (stdDev * 1.5f).coerceIn(4f, 35f),
                                vibratoRateHz = 5.2f,
                                signalStrengthDb = (20 * kotlin.math.log10(normAmp.toDouble().coerceAtLeast(0.0001))).toFloat()
                            )
                            _tunerState.value = updatedTuner

                            // 4. Real-time Chord Progression Detection
                            val chordInfo = ChordProgressionDetector.estimateChord(recentNoteNames.toList(), capoFret)
                            _detectedChordInfo.value = chordInfo

                            val label = "${chordInfo.chordName} (${chordInfo.romanNumeral})"
                            val currentHist = _chordHistory.value
                            if (currentHist.firstOrNull() != label) {
                                _chordHistory.value = (listOf(label) + currentHist).take(6)
                            }

                            val frame = AudioPitchFrame(
                                timestampMs = System.currentTimeMillis(),
                                frequencyHz = detectedFreq,
                                noteName = "${updatedTuner.detectedNote}${updatedTuner.octave}",
                                midiPitch = PitchDetector.noteNameToMidi(updatedTuner.detectedNote, updatedTuner.octave),
                                cents = updatedTuner.centsDeviation,
                                amplitudeDb = updatedTuner.signalStrengthDb,
                                isInTune = updatedTuner.isInTune
                            )
                            _pitchFrames.emit(frame)
                        } else {
                            _tunerState.value = tuner.copy(isListening = true)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            _isRecording.value = false
        }
    }

    fun stopListening() {
        _isRecording.value = false
        recordJob?.cancel()
        recordJob = null
        try {
            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null
        } catch (e: Exception) {
            e.printStackTrace()
        }
        _tunerState.value = TunerState(isListening = false)
        _rawWaveformPoints.value = emptyList()
        BpmDetector.reset()
        _liveBpmState.value = com.example.model.LiveAudioBpmState()
    }
}
