package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.example.model.MetronomeConfig
import com.example.model.MetronomeSoundType
import com.example.model.MetronomeSubdivision
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

/**
 * High-precision digital metronome with synthesized acoustic ticks:
 * Woodblock, Digital Beep, Classic Click, Cowbell,
 * configurable time signatures (2/4, 3/4, 4/4, 6/8), accents, subdivisions,
 * and tap-tempo calculation.
 */
class DigitalMetronome(private val scope: CoroutineScope) {

    private val sampleRate = 44100
    private var audioTrack: AudioTrack? = null
    private var metronomeJob: Job? = null

    private val _config = MutableStateFlow(MetronomeConfig())
    val config: StateFlow<MetronomeConfig> = _config.asStateFlow()

    // Tap tempo timestamp history
    private val tapTimestamps = mutableListOf<Long>()

    init {
        try {
            val minBufferSize = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(minBufferSize * 4)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            audioTrack?.play()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun start() {
        if (_config.value.isRunning) return
        _config.value = _config.value.copy(isRunning = true, currentBeat = 1)

        metronomeJob = scope.launch(Dispatchers.Default) {
            var beatIndex = 0

            while (isActive && _config.value.isRunning) {
                val currentConf = _config.value
                val beatsPerBar = currentConf.beatsPerBar
                val subdivisions = currentConf.subdivision.multiplier
                val bpm = currentConf.bpm.coerceIn(30, 300)

                // Interval per subdivision tick in ms
                val tickIntervalMs = (60000.0 / (bpm * subdivisions)).toLong()

                val isMainBeat = (beatIndex % subdivisions) == 0
                val mainBeatNumber = (beatIndex / subdivisions % beatsPerBar) + 1
                val isAccent = isMainBeat && mainBeatNumber == 1 && currentConf.isAccentFirstBeat

                _config.value = _config.value.copy(currentBeat = mainBeatNumber)

                // Synthesize & play click sound unless muted or visual-only
                if (!currentConf.isMuted && !currentConf.isVisualFlashOnly) {
                    playTick(
                        isAccent = isAccent,
                        isSubdivision = !isMainBeat,
                        soundType = currentConf.soundType,
                        volume = currentConf.volume
                    )
                }

                beatIndex = (beatIndex + 1) % (beatsPerBar * subdivisions)
                delay(tickIntervalMs)
            }
        }
    }

    fun stop() {
        metronomeJob?.cancel()
        metronomeJob = null
        _config.value = _config.value.copy(isRunning = false, currentBeat = 1)
    }

    fun toggle() {
        if (_config.value.isRunning) stop() else start()
    }

    fun setBpm(bpm: Int) {
        val clamped = bpm.coerceIn(30, 300)
        _config.value = _config.value.copy(bpm = clamped)
    }

    fun adjustBpm(delta: Int) {
        setBpm(_config.value.bpm + delta)
    }

    fun setBeatsPerBar(beats: Int) {
        val clamped = beats.coerceIn(1, 12)
        _config.value = _config.value.copy(beatsPerBar = clamped, currentBeat = 1)
    }

    fun setSoundType(type: MetronomeSoundType) {
        _config.value = _config.value.copy(soundType = type)
    }

    fun setSubdivision(subdivision: MetronomeSubdivision) {
        _config.value = _config.value.copy(subdivision = subdivision)
    }

    fun setVolume(volume: Float) {
        _config.value = _config.value.copy(volume = volume.coerceIn(0f, 1f))
    }

    fun toggleMute() {
        _config.value = _config.value.copy(isMuted = !_config.value.isMuted)
    }

    fun toggleAccentFirstBeat() {
        _config.value = _config.value.copy(isAccentFirstBeat = !_config.value.isAccentFirstBeat)
    }

    /**
     * Tap Tempo feature: Call on each tap button press to detect tempo.
     */
    fun tapTempo(): Int {
        val now = System.currentTimeMillis()
        // Reset if last tap was more than 2.5 seconds ago
        if (tapTimestamps.isNotEmpty() && (now - tapTimestamps.last()) > 2500) {
            tapTimestamps.clear()
        }

        tapTimestamps.add(now)
        if (tapTimestamps.size > 5) {
            tapTimestamps.removeAt(0)
        }

        if (tapTimestamps.size >= 2) {
            val intervals = mutableListOf<Long>()
            for (i in 1 until tapTimestamps.size) {
                intervals.add(tapTimestamps[i] - tapTimestamps[i - 1])
            }
            val avgInterval = intervals.average()
            if (avgInterval > 0) {
                val calculatedBpm = (60000.0 / avgInterval).toInt().coerceIn(30, 300)
                setBpm(calculatedBpm)
                return calculatedBpm
            }
        }
        return _config.value.bpm
    }

    private fun playTick(
        isAccent: Boolean,
        isSubdivision: Boolean,
        soundType: MetronomeSoundType,
        volume: Float
    ) {
        val durationSec = 0.045f // 45ms per click
        val samples = (sampleRate * durationSec).toInt()
        val pcm = ShortArray(samples)

        val freq = when (soundType) {
            MetronomeSoundType.WOODBLOCK -> if (isAccent) 1200f else if (isSubdivision) 700f else 900f
            MetronomeSoundType.DIGITAL_BEEP -> if (isAccent) 1760f else if (isSubdivision) 880f else 1174f
            MetronomeSoundType.CLICK -> if (isAccent) 2400f else if (isSubdivision) 1200f else 1800f
            MetronomeSoundType.COWBELL -> if (isAccent) 800f else if (isSubdivision) 540f else 620f
        }

        val baseVol = when {
            isAccent -> 1.0f
            isSubdivision -> 0.45f
            else -> 0.8f
        } * volume

        for (i in 0 until samples) {
            val t = i.toFloat() / sampleRate
            val sampleVal: Float = when (soundType) {
                MetronomeSoundType.WOODBLOCK -> {
                    // Wood resonance: fundamental sine + short rapid exponential decay
                    val decay = exp(-75f * t)
                    val s1 = sin(2 * PI * freq * t).toFloat()
                    val s2 = 0.4f * sin(4 * PI * freq * t).toFloat()
                    (s1 + s2) * decay
                }
                MetronomeSoundType.DIGITAL_BEEP -> {
                    // Crisp electronic beep with square-edged envelope
                    val env = (1f - (t / durationSec)).coerceIn(0f, 1f)
                    sin(2 * PI * freq * t).toFloat() * env
                }
                MetronomeSoundType.CLICK -> {
                    // Acoustic impulse click: burst of filtered noise + high pop
                    val decay = exp(-120f * t)
                    val pop = sin(2 * PI * freq * t).toFloat()
                    val noise = (Random.nextFloat() * 2f - 1f) * 0.4f
                    (pop + noise) * decay
                }
                MetronomeSoundType.COWBELL -> {
                    // Metallic dual-tone ring
                    val decay = exp(-50f * t)
                    val f1 = sin(2 * PI * freq * t).toFloat()
                    val f2 = 0.7f * sin(2 * PI * (freq * 1.48f) * t).toFloat()
                    (f1 + f2) * decay
                }
            }

            val pcmVal = (sampleVal * 28000 * baseVol).toInt().coerceIn(-32767, 32767)
            pcm[i] = pcmVal.toShort()
        }

        audioTrack?.write(pcm, 0, samples)
    }

    fun release() {
        stop()
        try {
            audioTrack?.stop()
            audioTrack?.release()
            audioTrack = null
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
